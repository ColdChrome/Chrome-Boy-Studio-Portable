// Chrome Boy FM: loads FM1_ChromeBoy.fwsc into the emulator by itself on every visit (so a newer build always replaces the copy kept in this browser).  Then click Start.
(async () => {
  await new Promise(r => setTimeout(r, 2500));
  const b = await (await fetch('FM1_ChromeBoy.fwsc')).arrayBuffer();
  const dt = new DataTransfer(); dt.items.add(new File([b], 'ChromeBoy.fwsc'));
  document.querySelector('.stage').dispatchEvent(new DragEvent('drop', { dataTransfer: dt, bubbles: true, cancelable: true }));
})();
