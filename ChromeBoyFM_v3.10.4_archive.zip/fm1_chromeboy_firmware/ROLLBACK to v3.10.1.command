#!/bin/bash
# Same flasher, but loaded with the previous firmware (Chrome Boy v3.10.1). Use this if v3.10.1 misbehaves on the FM1.
cd "$(dirname "$0")"
cp -f previous/v3.10.1/FM1_ChromeBoy_v3.10.1.fwsc flasher/firmware.fwsc; cp -f previous/v3.10.1/build-identity.json flasher/
lsof -ti tcp:8733 | xargs kill 2>/dev/null
python3 -I -m http.server 8733 --bind 127.0.0.1 --directory flasher >/dev/null 2>&1 &
sleep 1
open -a "Google Chrome" "http://127.0.0.1:8733/index.html"
echo "ROLLBACK flasher (v3.10.1) running at http://127.0.0.1:8733 - close this window when finished."
wait
