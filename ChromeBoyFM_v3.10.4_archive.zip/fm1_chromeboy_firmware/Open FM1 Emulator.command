#!/bin/bash
# Serves the emulator (with Chrome Boy FM already loaded) on this Mac only and opens it in Chrome.  Close this window when done.
cd "$(dirname "$0")/emulator"
cp -f ../FM1_ChromeBoy_v*.fwsc /tmp/_cb_latest.fwsc 2>/dev/null; cp -f "$(ls ../FM1_ChromeBoy_v*.fwsc | sort -V | tail -1)" FM1_ChromeBoy.fwsc
lsof -ti tcp:8734 | xargs kill 2>/dev/null
python3 -I -m http.server 8734 --bind 127.0.0.1 >/dev/null 2>&1 &
sleep 1
open -a "Google Chrome" "http://127.0.0.1:8734/index.html"
echo "FM1 emulator running at http://127.0.0.1:8734 - click START in the page.  Close this window when finished."
wait
