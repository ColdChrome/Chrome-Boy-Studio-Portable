# Chrome Boy FM - diagnosis + spec for the next update (v3.10)

Based on the v3.9.0 source (`source/app/cb/*`) and M-VAVE's SDK. Nothing is changed yet.
Your brief uses buttons that don't exist on the FM1 (REC/ENTER, STOP/BACK, ENC, CC Assignment, Pattern Select). On this unit the real controls are: **SAVE** writes, **PLAY** cancels, **K1-K4** scroll/edit, **SELECT / PRESETS / ALGORITHM** are the three encoders. I use those names throughout.

---

## 1. Stem export writes ~20 steps instead of 16 - root cause (confirmed in code)

`main.cpp:59` (`exPass`):

    xdur = loops * len * 16 * (15000 / bpm) + 1500        // wall-clock milliseconds

1. **The stop is a timer, not a step.** The pass ends after a fixed time, not when the sequencer reaches step 16.
2. **A fixed 1.5 s "tail" is added, and the sequencer keeps looping during it.** The pattern wraps back to step 1 and plays its first steps again. 1.5 s = 12 steps at 120 BPM and about 20 steps at 200 BPM. The "extra steps" you hear are the start of the pattern replaying. That's the bug, not just a quiet tail.
3. **Count-in:** if GLO > COUNT-IN is on, the pass also records the count-in bar (up to 16 extra steps).
4. **MIDI start latency** (the 0xFA start message) adds a few ms of start offset that differs from track to track.

**Fix:**
- Stop the transport exactly when the playhead reaches step 16 of the last loop (watch `play_step`), instead of using a timer.
- Switch the count-in off for the export and restore it afterwards.
- Ring-out belongs in the silent gap *after* the stop, so nothing replays. The sound engine must keep releasing notes after STOP. I'll verify that on the emulator before relying on it.
- Add a TAIL setting for the export: **RING** (stop at the barline, let notes ring out in the gap, default) or **CUT** (stop and kill all notes at the barline, so each stem is exactly N bars of sound).
- All stems then have identical length by construction.
- **Limit:** the FM1 cannot cut the audio file in your DAW. It can only control when it plays and stops, so "sample-accurate" means identical play time per stem. Sample 0 of your recording is wherever you pressed record, plus the 4 s lead-in.

## 2. CC 909 sounds like CC 808 - what's really going on

- v3.9.0 changes only 24 parameters (tone, decay, tune, attack, snap), mostly by small amounts. That is the kind of difference you hear as "same kit".
- The FM1's drum engine is M-VAVE's closed 808 model. **I can't rewrite its DSP** (no new oscillators, no 6-oscillator hat matrix inside it).
- **It does have levers I haven't used.** Every drum has a **Distortion type** with: DIODE, CLIP, SAT, BFZ, PDIST, FOLD, **CRUSH**. CRUSH is a bit-crusher, which is exactly the 909 hats' 6-bit grit. The toms also have a CONGA / TOM switch, the rim has RIM / CLAVE, and the clap has CLAP / MARAC.
- **Plan for 909:**
  - **Kick:** CLIP distortion with more drive, very short decay, high attack and tone, and a higher tune for the click and fast pitch drop.
  - **Snare:** high snappy and tone, short decay, SAT distortion.
  - **Clap:** short attack and MARAC mode (the burst character), CRUSH.
  - **Rim:** CLAVE sound (shorter and harder).
  - **Closed and open hats and cymbal:** CRUSH distortion, with tune raised to move the energy up, 909-style.
  - **Toms:** TOM mode, shorter decay, higher tune.
- **How I'd prove it:** in the emulator, trigger the same hit on 808 and 909 and compare level, decay time and spectral centroid. The two must differ clearly for every drum, or I retune. I can't judge taste, so I report numbers and you judge by ear.
- **Cost:** about 100-150 bytes of table.

## 3. Silent preset - audit result and what I still need

- **Static audit, done now:** all 128 factory voices and my 20 custom voices checked for no carrier output, all carrier levels at 0, and unreachable envelopes. **No voice is silent on paper.** Two voices are very percussive/short: VOICE 4 and TAMBOURINE. Both are by design.
- **A real problem found:** the custom voices are **not volume-matched.** Summed carrier level: LOW TOM 139, bells ~180, leads ~170-185, E-pianos 184-274, **DRAWBAR 452, CHURCH ORGAN 478**. The organs are about 2.5x louder than the other voices, which can sound like a jump or even clip. I'll normalize them by scaling the carrier levels, which costs no flash.
- **Why there could still be silence on your unit:** the sound engine can reject a voice import, or a track might not be an FM voice (a 303, PSG or pluck track ignores FM voices). Static analysis can't see either of those.
- **How I'll find it:** an emulator sweep that plays every voice on every track and measures loudness, listing any that read as silent.
- **I need from you:** which preset (name and track) was silent, if you remember. Even "the third E.PNO voice" helps.

## 4. Tracks with only one preset - cause

On a track that isn't an FM voice (303, PSG, pluck, sampler), the PRESETS knob has nothing to list, because my lists only exist for FM voices. That's why "multiple tracks only have the default preset."

**Fix, without changing your project's engines:** give each engine real presets made of its own tone parameters.
- **303 bass** (12 parameters: Cutoff, Reso, EnvMod, Decay, Accent, Wave, Tune, Volume, Drive, DrvTyp, Slide, AccDec): 12-16 presets such as Acid squelch, Reese-style saw drive, Sub, Pluck, Rubber, Wobble-ish, Square lead, Dub.
- **Pluck** (4 parameters: Decay, Bright, Tune, Release): about 12 presets such as Nylon, Harp, Marimba, Koto, Steel string, Muted, Bell-ish, Bass pluck.
- **PSG** (4 parameters): about 8-12 presets once I've read its parameter names off your unit. The names are in M-VAVE's closed library, so I'll read them in the emulator first.
- **Sampler:** nothing to add, since its sounds come from the sample bank.
- **Cost:** about 500-900 bytes. All presets get their level matched.

## 5. Generator: complexity across the ALGORITHM knob

**Today:** ALGORITHM picks one of 999 seeds. Neighbouring seeds have no musical relationship, so turning it feels random.

**New design:** the ALGORITHM encoder moves through **128 positions**. Position 0-127 sets a complexity tier, and each position within a tier is a different seed of that tier's vocabulary:

| Range | Tier | Harmony | Rhythm and melody |
|---|---|---|---|
| 0-31 | Foundational | triads, diatonic roots, I-V-vi-IV and plain cadences | straight rhythm, few off-beats, chord tones |
| 32-63 | Colour | 7ths, sus2/sus4, secondary dominants, ii-V-I | gentle syncopation, held notes |
| 64-95 | Complex / modal | 9ths and 11ths, borrowed chords (modal interchange: Dorian, Mixolydian, Aeolian), Andalusian and minor plagal cadences, passing tones | polyrhythmic accents, ties and dotted lengths |
| 96-127 | Experimental | tritone substitutions, altered dominants, chromatic voice leading | micro-timing, wide leaps, velocity shaping |

- Voice leading: each chord moves to the nearest inversion (minimal pitch distance).
- Euclidean rhythms already exist and become tier-dependent in density and rotation.
- Every note stays checked against the active key. The "in key" test runs on the Mac across all four tiers before anything ships.
- **Trade-off:** 128 positions instead of 999 seeds. The same position always gives the same pattern. The SEQ-page knobs (DENS, CHAOS, HOLD, SYNC, LEAP, VOICE, PROG, OCT) still steer details.
- **Cost:** about 900-1,300 bytes.

## 6. On-screen button cues

- **Naming screen:** already shows `K1 CHAR K2 MOVE SAVE`. I'll add `PLAY = CANCEL`, a character counter `3/6`, and flash the cursor.
- **Add a one-line cue in every modal state:** EXPORT ask and progress, CLEAR PROJECT confirm, SAVE list (slot actions), the step-edit and piano-roll footer, PRESETS page, SEQ page.
- Wherever a value readout would be hidden, the cue replaces nothing and shares the bottom line.
- **Cost:** about 250-350 bytes.

---

## Byte budget (v3.9.0 has 25 free of 453,921)

| Item | Estimated size |
|---|---|
| Export fix + TAIL setting | 150-250 |
| 909 parameter upgrade | 100-150 |
| Voice normalization (data only) | ~0 |
| 303 + pluck presets | 500-900 (PSG +200 later) |
| Generator tiers | 900-1,300 |
| Cue lines | 250-350 |
| **Total** | **about 1,900-3,000** |

## What could pay for that (you choose)

| Option | Frees | What you lose |
|---|---|---|
| Boot splash to one text line | ~400 | the animated title |
| 9 built-in T06 percussion voices to 5 | ~220 | 4 synth percussion sounds (the 10 real percussion voices stay) |
| Drum/percussion grooves 9 to 5 | ~300 | 4 groove patterns |
| SEQ page third knob set (HUMAN, SWING, BANK, NEW PRG) | ~250 | those 4 knobs |
| Water/column art back to simple | ~1,500 | the animation you asked me to restore |
| Piano-roll command row down to 3 (CPY, PST, DEL) | ~100 | S:A/S:B, OUT |

## How I'll verify this time
1. Native Mac tests: generator in key across all 4 tiers and all 128 positions; table range checks.
2. **Emulator** (needs your OK to download its files again, ~3 MB): export length measured to the step, 808 vs 909 numbers, a sweep of every preset on every track for silence and loudness, and tests with LOCAL OFF and changed MIDI channels.
3. A short checklist for your FM1.
4. A full report that says what was verified on what.
