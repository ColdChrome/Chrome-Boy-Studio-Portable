# Chrome Boy FM v3.9.0 - spec for approval

Scope you approved: **generator rewrite + A1, A2, A3, A4, A5, A6, A7, A7+, A8, A8+.**
Each item says what you press, what you see and what you hear. Anything marked **(check)** is something I verify while building before I rely on it.

---

## G. Generator v3: one music-theory engine instead of 16 recipes

- **Press:** ALGORITHM (turn), any key on HOME, keys 1-15 on the SEQ page, key 16 on the SEQ page for a new progression. Same controls as today.
- **Hear:** a new pattern built from rules every time:
  - **Role from the track:** BASS = roots, 5ths and octaves. LEAD = melody. E.PNO / BELL / PAD = chords. ORGAN = chords or arpeggio. DRUMS and PERC keep their groove engine.
  - **Harmony:** the shared chord progression (unchanged generator). Chords are stacked thirds inside the key, with 7ths, 9ths and sus chosen by tension.
  - **Rhythm:** Euclidean (k hits spread over 16 steps), rotated, with accents, ties and holds.
  - **Melody and bass:** a weighted random walk over chord tones and scale notes. Small steps by default, leaps via LEAP. A chord tone on beats 1 and 3, the last note resolves home, and the phrase follows an A A' B A'' motif.
  - **Arpeggio:** order, direction and octave span all come from the same genes.
- **Knobs** steer the genes: DENS = Euclidean hits, CHAOS = walk step size and randomness, HOLD = note length and ties, SYNC = rotation and off-beats, LEAP = jump size, VOICE = chord spread, PROG = progression family, OCT = register.
- **ALGORITHM knob** = seed number 1-999. Turning back returns the exact pattern (the same seed gives the same result).
- **See:** a generated name, for example `E5/16 MIN9 DRIFT`, `BASS R-5 E7/16`, `LEAD CLIMB SYNC`, plus the chord readout as today.
- **Verified by:** a native Mac test of millions of notes (0 out of key allowed, variety measured), then the emulator and a flash-size measurement before anything else is traded.

## A1. Piano-roll sound fix (LOCAL)
- **Cause:** the global LOCAL setting is OFF on your unit, so the engine never receives key presses. The sequencer is unaffected, which is why patterns still play.
- **Boot:** if LOCAL is OFF, the firmware turns it ON once and shows `LOCAL WAS OFF: NOW ON`.
- **Hear:** EDIT, then any key, gives sound immediately, with REC off or on and the sequencer stopped or playing. OCT-/OCT+ shift the octave live.
- **Test:** emulator with LOCAL OFF, plus a changed input channel, plus the role check.

## A2. CC 909 actually selects
- **Press:** PRESETS on T01 toggles CC 808 / CC 909. **See** which kit is active on the PRESETS page and the HOME track line.
- The chosen kit is stored, not guessed from the kick's tune. If T01 is on another engine, it switches to the 808 engine first and applies the 909 settings on the next frames, once the engine is ready.
- **Sound:** the 808 engine retuned (punchy, clicky kick with drive, snappy snare, higher toms, crisp short hats). The engine itself cannot be rewritten (M-VAVE library), so this is the deepest 909 possible.

## A3. Mixer meters
- **See:** bars on a dB scale (-48 to 0 dB). Normal playback fills about 40-75% of the strip, with yellow near the top and red at clipping. A 2-pixel peak marker holds about 300 ms and then falls smoothly.

## A4. Encoder acceleration (K1-K4, SELECT, PRESETS, ALGORITHM)
- **Feel:** slow turns move 1 step per click. A fast spin (about 10 clicks within 150 ms) ramps to 4x, 8x, then 16x per click. It stops cleanly at the minimum and maximum, without wrapping or jitter.
- SELECT, PRESETS and ALGORITHM accelerate less (at most 2x), so you don't skip past tracks or presets.

## A5. Automation recording (HOME + FX)
- **Likely cause:** if you press REC while stopped, the firmware enters step-record and automation never arms. Pressing PLAY then starts without REC. **(Please confirm this is how you do it.)**
- **Fix:** REC while stopped arms both. PLAY then starts recording knob moves, so HOME K1-K4 and FX-page knobs are written per step.
- **See:** the automation lane numbers change live while recording and moving when played back. The REC LED stays lit while armed.
- **Limits:**
  - The SDK holds 16 parameter locks per project (HOME knobs), and only some parameters can be locked. Other knobs show `NO AUTO`.
  - FX-page automation lives in RAM and is not saved with the project (an SDK limit).

## A6. Clear Current Project (SYSTEM NAV row 9)
- **Press:** hold HOME for the menu, then key 9 (or SELECT to row 9 and key 16). The screen asks `CLEAR PROJECT? KEY 9 AGAIN`, and a second press within 3.5 s clears.
- **Clears:** all patterns on all tracks, mute and solo, and the project name (back to `UNTITLED`). **Keeps:** the sounds on each track and all 16 saved slots.
- FX settings: reset to new-project defaults if the SDK exposes them **(check)**. If not, they are kept, and I'll tell you.
- **Undo:** OCT- (in step mode or on HOME) brings the whole project back. Through the SDK's own undo if available **(check)**, otherwise through a 4 KB snapshot in RAM.

## A7 / A7+. 6-character project names
- **Press:** SAVE, pick a slot, key 1. The naming screen opens:
  - K1 changes the character at the cursor (A-Z, 0-9, `- _ / !`, space, and the icons).
  - K2 moves the cursor (1-6).
  - SAVE writes the project with that name. PLAY cancels.
- **See:** the 6 characters large, with a cursor. Slot lists show the names.
- **Icons (A7+):** ♪ ♥ ★ and a pad icon, drawn by Chrome Boy. They are stored as `{ } | ~` because the SDK only allows plain text, so M-VAVE's own tools would show those characters.
- Flash is written once, on SAVE, exactly as today.

## A8 / A8+. New FM presets
- **A8**, 10 voices: 2 ACID 303-style bass (BASS), 2 leads (LEAD), 2 E-pianos (E.PNO), 2 bells (BELL), 2 organs (ORGAN).
  - They appear first in each track's PRESETS list, before the factory voices, like the PERC voices on T06.
  - Each is a full 6-operator patch: ratios, feedback, attack, decay, sustain and release, and velocity response.
- **A8+:** as many extra voices as fit after measuring, about 2 more per category, aiming for 10 more.
- **303 acid patch idea:**
  - Algorithm 5 style: a modulator stack into one carrier.
  - The carrier is a 1:1 saw-like tone from operator feedback 6-7.
  - Modulators at 1:1 and 2:1 with fast decaying envelopes, for the "filter sweep".
  - High velocity sensitivity on the modulators, so harder notes bite more ("accent").
  - Short decay and no sustain on the carrier, for staccato 16ths.
  - This is FM; a real resonant filter is not possible on the FM engine.

---

## Not possible on this hardware (from your directive)
- **Master limiter, new 909 sound code:** both are inside M-VAVE's closed engine library, so I can only use its parameters.
- **Multichannel USB stems:** the FM1 already works as a stereo USB audio input ("USB-Audio" on macOS). More channels would need new USB code in the closed SDK. EXPORT TO DAW remains the stem method.
- **"Remove dead code":** the build already strips unused code.

## Order of work and checks
1. Generator v3, native test, then a size measurement. **If it saves less than expected, I stop and tell you before trading anything.**
2. A1, A2, A5 (fixes), then A3, A4, then A6, A7, then A8 / A8+ to fill the remaining space.
3. Emulator test under your conditions: LOCAL OFF, changed MIDI channels, T01 on the sampler, existing patterns.
4. A 5-minute checklist for you to run on the FM1.
