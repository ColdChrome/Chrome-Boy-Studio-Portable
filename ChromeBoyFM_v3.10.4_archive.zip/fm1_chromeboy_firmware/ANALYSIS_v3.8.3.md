# Chrome Boy FM v3.8.3 - source review before the final beta

Written 2026-10-29 after reading `source/app/cb/*` against M-VAVE's SDK (`fm1_open-main`).
Nothing here is changed yet. This is the list of what to fix and how to build the next update better.

---

## 1. Why the piano-roll keyboard is silent on your FM1 (but worked in the emulator)

**Root cause (high confidence):** my code sends every live note on the wrong MIDI channel.

- All live notes go through `groove_midi_local()`. The SDK routes a note to every track whose **MIDI input channel** matches the note's channel, and drops it silently if no track matches (`midi_router.c:275`).
- M-VAVE's own panel code sends on `groove_midi_input_channel(track)` (`screen.c:2540`).
- My code sends on `groove_channel(track)`, which is just the track number (drums = 9). See `main.cpp` lines 75-79, 192, 198, 350: keyboard play, release, preview, panic.
- In the emulator's fresh project the input channel equals the track number, so it works. In your saved project the channels can differ, for example after a change on GLO > PROJECT > IN CH, an older project, or a factory default. Then the keys either play another track or play nothing.
- The same mistake can also explain some earlier "no sound" reports (Track 2 bass, preview).

**Two related problems on the same path:**
- A track whose ROLE is OFF, or the global LOCAL OFF flag, also makes `groove_midi_local` silent. Nothing on screen says so.
- `post()` ignores failures. M-VAVE's panel retries a note-off when the queue is full. Mine drops it, which risks a stuck note.

**Fix for the final beta:**
- One helper `sendNote(track, note, vel)` that uses `groove_midi_input_channel(track)`.
- It remembers the channel each note was started on, so the note-off always matches.
- It retries on failure, the way the stock code does.
- Every call site above switches to it.
- If the track's role is OFF or local is off, the screen shows that instead of staying silent.

---

## 2. Other weak spots, ranked by risk

| # | Where | Problem | Better approach |
|---|---|---|---|
| 2 | CC 909 (`sequencer.cpp` kit909 / kitSet) | The kit is detected by reading the kick's Tune and checking it equals 80. If you tweak the kick, it "becomes" CC 808. If T01 was left on the sampler by v3.8.2, the engine switch and the 909 settings happen in the same instant, and the settings can be lost. That is the likely reason you can't select CC 909. | Store the chosen kit explicitly. After a source switch, wait until the engine reports 808 parameters, then apply the settings on a following frame. Show "CC 909" from the stored choice, not from a guess. |
| 3 | Preset grouping (seq_category_of) | It sorts voices by name substrings ("BEN", "TOM", "GAM"). This works on M-VAVE's factory bank, but your FM1's banks clearly have different names, which is why Gamalong is missing. Substrings can also misfire, since "TOM" is inside other words. | Before writing rules, read the real names from your FM1. A diagnostics page could list all 128 voice names. Then use exact rules for the known bank, a safe catch-all for the rest, and an "ALL VOICES" view so nothing can ever be lost. |
| 4 | Live recording timing (liveOn) | A note is written on the step the playhead is on when the key goes down. A note played slightly early lands one step too early, because nothing rounds to the nearest step. Every recorded note also creates its own undo point, which floods the undo history. | Measure the time inside the current step and round to the nearest one, the way the engine recorder does. Take one undo point per recording pass. |
| 5 | Hold length (seq_hold) | It reads back the cell 120 ms after release and checks two possible steps. It fails if the note was changed or overdubbed in between. | Keep the note's position from note-on and write the length directly, with no search. |
| 6 | Firmware overriding your project | `seq_perc_check()` forces T06 back to an FM voice every ~2 s. The boot unmute and the loop length are also enforced every frame. If you deliberately set T06 to another engine, the firmware fights you. | Enforce once at boot and after a project load, not continuously. Respect a choice you made on purpose. |
| 7 | Flash budget | Every build sits within 25-200 bytes of the 453,921-byte limit. Each feature has meant shortening text or cutting something else, and that is where the cryptic short texts come from. | Decide the final feature list first, then budget bytes per feature, the way you plan a mix. Candidates that save real space: one data-driven page renderer instead of hand-written pages, the text stored compressed, and the generator's 16 melodic styles described in a table instead of code. |
| 8 | Emulator vs. your unit | My tests ran on the emulator's fresh project. Your FM1 has a saved project, edited banks and different channels, so bugs like #1-#3 only show up on your unit. | Take a workbench backup of your FM1 (project + banks) and load it into the emulator (Your save > Import). Test every feature on your real state before you flash. |
| 9 | Silent failures in general | Many calls (`groove_source_set`, `groove_fm_import`, `groove_tone_edit`, `groove_midi_local`) can fail, and the code ignores the result. | Check the result and show a short message ("ENGINE BUSY", "NO TRACK ON CH 3") so problems are visible on the device. |
| 10 | Mixed responsibilities in main.cpp | One 350-line file holds keys, pages, recording, export and LEDs. Page rules ("which keys do what on this page") are spread over five functions, so a change in one place silently breaks another. That is how HOME and EDIT key modes have regressed several times. | One table per page, with three entries: white keys, black keys and OCT±. Each mode lives in one place and is easy to test. |

---

## 3. How I'll work on the final beta

1. **You write the list, I turn it into a spec first.** For each item: what you press, what you see, what you hear. I send that back before writing code, so mistakes are caught on paper. Example: "EDIT, then key C4, plays C4 on the selected track, even while stopped."
2. **I trace each feature through the SDK's own code first**, the way I did for #1, instead of assuming how a call behaves.
3. **I test on your real state.** That means your workbench backup loaded into the emulator, plus a short checklist you run on the FM1 (5 minutes) before you call it final.
4. **One byte budget for the whole release**, agreed up front, so nothing you asked for silently disappears to make room.
5. **Every report states what was verified, on what, and what was not.**

## 4. What I need from you for the final beta

- A workbench backup of the FM1 (project + DX7 banks A-D). It stays on your Mac and is only used to load into the local emulator.
- The exact name Gamalong shows on your unit, and which track list it is on.
- Your long list, with what matters most marked.
