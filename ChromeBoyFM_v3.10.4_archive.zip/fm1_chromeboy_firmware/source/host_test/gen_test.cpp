// Host test for generator v3 (tiers): in-key rules per tier, range checks, variety, repeatability, tier character.
#include "algo_styles.hpp"
#include <cstdio>
#include <set>
#include <string>
using namespace algo;
int main() {
  const int TR[6] = {0, 1, 2, 3, 5, 6}; long cells[4] = {0}, outk[4] = {0}, bad = 0, empty = 0, pats = 0; long ties[4] = {0}, hits[4] = {0}, chordExt[4] = {0}, chordN[4] = {0};
  Rng K(12345);
  for (int sc = 0; sc < 96; sc++) for (int ti = 0; ti < 6; ti++) for (int gi = 0; gi < 128; gi++) for (int v = 0; v < 2; v++) {
    const int tier = gi >> 5;
    Opts o{(uint32_t)(v * 7919 + gi * 31 + 1), sc, K.n(128), K.n(128), K.n(128), K.n(3) - 1, K.n(128), K.n(128), K.n(128), K.n(128), 4, {0, 0, 0, 0}};
    Rng P(o.seed); newProg(o.deg, K.n(5), sc, P);
    Step st[NS]; Result r; applyStyle(st, TR[ti], 0, gi, o, r); pats++; int n = 0;
    for (int s = 0; s < NS; s++) { const Step& x = st[s]; if (!x.vel) continue; n++; cells[tier]++; hits[tier]++; ties[tier] += x.tie;
      if (x.chord) { chordN[tier]++; chordExt[tier] += QTAB[x.chord - 1][0] >= 4; }
      const bool ok = x.note <= 127 && x.vel >= 1 && x.vel <= 127 && x.gate >= 1 && x.gate <= 15 && x.prob <= 7 && x.chord <= 16;
      if (!ok) { if (bad < 5) printf("BAD field sc=%d t=%d gi=%d s=%d\n", sc, TR[ti], gi, s); bad++; }
      if (!inKey(sc, x.note % 12)) { outk[tier]++; if (tier < 2 && !x.chord && bad < 5) { printf("OUT-OF-KEY tier %d sc=%d t=%d gi=%d s=%d note=%d\n", tier, sc, TR[ti], gi, s, x.note); bad++; } } }
    if (!n) empty++;
  }
  printf("patterns %ld  bad %ld  empty %ld\n", pats, bad, empty);
  for (int t = 0; t < 4; t++) printf("tier %d: cells %ld  out-of-key %.2f%%  ties %.1f%%  chord notes with 4+ tones %.1f%%\n", t, cells[t], 100.0 * outk[t] / cells[t], 100.0 * ties[t] / hits[t], chordN[t] ? 100.0 * chordExt[t] / chordN[t] : 0.0);
  for (int ti = 0; ti < 6; ti++) { std::set<std::string> pat; Opts o{1, 1 * 12 + 9, 64, 64, 30, 0, 40, 40, 30, 64, 0, {0, 5, 3, 4}};
    for (int gi = 0; gi < 128; gi++) { Step st[NS]; Result r; applyStyle(st, TR[ti], 0, gi, o, r); std::string k; for (int s = 0; s < NS; s++) { k += (char)st[s].note; k += (char)(st[s].vel ? 1 : 0); k += (char)st[s].chord; k += (char)st[s].tie; } pat.insert(k); }
    printf("track %d: %zu distinct patterns / 128 positions\n", TR[ti], pat.size()); }
  { Opts o{1, 9, 64, 64, 30, 0, 40, 40, 30, 64, 0, {0, 5, 3, 4}}; Step a[NS], b[NS]; Result ra, rb; applyStyle(a, 0, 0, 77, o, ra); applyStyle(b, 0, 0, 77, o, rb); bool same = true; for (int s = 0; s < NS; s++) same &= a[s].note == b[s].note && a[s].vel == b[s].vel; printf("same position repeats: %s\n", same ? "yes" : "NO"); }
  for (int gi : {5, 40, 70, 110}) for (int ti : {2, 0, 1}) { Opts o{5, 9, 64, 64, 30, 0, 40, 60, 40, 64, 0, {0, 5, 3, 4}}; Step st[NS]; Result r; applyStyle(st, TR[ti], 0, gi, o, r);
    printf("t%d #%3d %-26s | %s\n", TR[ti], gi, r.name, r.prog); }
  return bad ? 1 : 0;
}
// (appended) lottery check: how often two consecutive "key presses" (random seed inside the tier + new progression) give the same notes
#include <cstring>
struct LotteryCheck { LotteryCheck() {
  Rng K(99); int same = 0, tot = 0; std::set<std::string> roles[7];
  for (int t : {0, 1, 2, 3, 5, 6}) { std::string prev; for (int i = 0; i < 400; i++) { const int tier = (i / 100) & 3; const int gi = tier * 32 + K.n(32);
      Opts o{K.u(), 9, 72, 30, 24, 0, 40, 40, 30, 64, 4, {0, 0, 0, 0}}; Rng P(K.u()); newProg(o.deg, 4, 9, P); Step st[NS]; Result r; applyStyle(st, t, 0, gi, o, r);
      std::string k; for (int s = 0; s < NS; s++) { k += (char)st[s].note; k += (char)(st[s].vel ? 1 : 0); k += (char)st[s].chord; } same += k == prev; tot++; prev = k; roles[t].insert(std::string(r.name).substr(0, 5)); }
    printf("track %d roles seen:", t); for (auto& x : roles[t]) printf(" [%s]", x.c_str()); printf("\n"); }
  printf("lottery: %d identical consecutive pulls out of %d\n", same, tot);
  for (int row = 0; row < 6; row++) { std::set<std::string> v; for (int i = 0; i < 300; i++) { Opts o{K.u(), 9, 72, 30, 24, 0, 40, 40, 30, 64, 4, {0, 0, 0, 0}}; Step st[NS]; Result r; applyStyle(st, 7, 3, K.n(9), o, r, row, 36); std::string k; for (int s = 0; s < NS; s++) k += st[s].vel ? 'x' : '.'; v.insert(k); } printf("drum row %d: %zu different 16-step rows in 300 pulls\n", row, v.size()); }
} } lotteryCheck;
