/* SPDX-License-Identifier: GPL-3.0-only WITH GPL-3.0-linking-exception */
/* Chrome Boy FM: the factory demo-project builder (16 scenes) is removed to make room for the new editor.
 * Only the stock app/screen.c used it, and Chrome Boy replaces that screen. */
#include "instrument.h"
const char *groove_factory_name(unsigned index) { (void)index; return 0; }
int groove_factory_build(unsigned index, struct groove_project *p) { (void)index; (void)p; return GROOVE_PROJECT_INVALID; }
