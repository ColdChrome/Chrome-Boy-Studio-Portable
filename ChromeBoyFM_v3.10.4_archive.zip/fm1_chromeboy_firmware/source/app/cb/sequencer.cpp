// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM / M-VAVE FM1 - sequencer glue.  Every call is a documented m-vave/fm1_open `groove_*` control hook.
// 16 steps per bank = a 16-step window of the SDK's 64-step pattern (banks A..D).  Control task only.
#include "cb_core.h"
#include <string.h>

namespace cb {
namespace {
const uint8_t DRUM_ID[6] = {0, 1, 6, 10, 9, 3};            // kick, snare, clap, closed hat, open hat, mid tom  ->  groove drum ids
inline unsigned absStep(unsigned bank, unsigned s) { return bank * NS + s; }
char libNames[128][11]; uint8_t libCat[128], libOrd[128]; bool libOk = false;
void nkey(const char* a, char* o) { int n = 0; for (; *a && n < 10; a++) if (*a != ' ') o[n++] = (*a >= 'a' && *a <= 'z') ? (char)(*a - 32) : *a; o[n] = 0; }
bool libBefore(int a, int b) { if (libCat[a] != libCat[b]) return libCat[a] < libCat[b]; char x[12], y[12]; nkey(libNames[a], x); nkey(libNames[b], y); return strcmp(x, y) < 0; }   // grouped by role, then by name: BASS 1..8, then SYN BASS 1..8
bool libLoad() {                                           // all 128 DX7 voices (4 banks x 32): name + role (VMEM: 128 bytes/voice, name at +118)
  if (libOk) return true; static uint8_t raw[4096];
  for (unsigned b = 0; b < 4; b++) {
    if (groove_fm_library_read(b, raw) != 0) return false;
    for (int i = 0; i < 32; i++) { char* nm = libNames[b * 32 + i]; memcpy(nm, raw + i * 128 + 118, 10); nm[10] = 0; for (int k = 0; k < 10; k++) if (nm[k] < 32 || nm[k] > 126) nm[k] = ' '; libCat[b * 32 + i] = (uint8_t)seq_category_of(nm); }
  }
  for (int i = 0; i < 128; i++) { int j = i; while (j > 0 && libBefore(i, libOrd[j - 1])) { libOrd[j] = libOrd[j - 1]; j--; } libOrd[j] = (uint8_t)i; }
  libOk = true; return true;
}
int libCount(unsigned r) { int n = 0; for (int i = 0; i < 128; i++) n += libCat[i] == r; return n; }
int libNth(unsigned r, int k) { for (int j = 0; j < 128; j++) if (libCat[libOrd[j]] == r && !k--) return libOrd[j]; return -1; }
int libPos(unsigned r, int prog) { int k = 0; for (int j = 0; j < 128; j++) if (libCat[libOrd[j]] == r) { if (libOrd[j] == prog) return k; k++; } return -1; }
// ---- T06 PERC: DX7 percussion voices built from a small table (operators are 6 carriers, or the 6>5>4>3 + 2>1 chain; a fixed-frequency feedback operator is the noise source)
const uint8_t CARRY[32] = {5, 5, 9, 9, 21, 21, 5, 5, 5, 9, 9, 5, 5, 5, 5, 1, 1, 1, 25, 11, 27, 29, 27, 31, 31, 11, 11, 37, 23, 39, 31, 63};
struct PO { uint8_t m, f, l, d; };                               // m: bit 7 = fixed frequency, low bits = coarse; f = fine; l = output level; d = decay rate
struct PP { char n[11]; uint8_t role, a, fb, sus, msus, rr; PO o[6]; };   // role = hardware track; a = algorithm, fb = feedback, up/pr = pitch sweep; at = attack rate, sus / msus = carrier / modulator sustain, rr = release
const PP VOX[14] = {   // T06 percussion first, then the A8 voices (they open each tracks PRESETS list).  Carrier levels are matched by measured loudness.
  {"IND SNARE ", 4, 31, 7, 0, 0, 75, {{0x82, 40, 99, 72}, {}, {}, {}, {0x83, 60, 99, 75}, {0x83, 20, 99, 70}}},
  {"METAL HAT ", 4, 0, 7, 0, 0, 75, {{0x83, 66, 99, 90}, {0x83, 47, 70, 90}, {0x83, 10, 99, 90}, {0x83, 80, 85, 90}, {0x83, 55, 85, 90}, {0x83, 25, 90, 90}}},
  {"OPEN HAT  ", 4, 0, 7, 0, 0, 75, {{0x83, 66, 99, 62}, {0x83, 47, 70, 62}, {0x83, 10, 99, 62}, {0x83, 80, 85, 62}, {0x83, 55, 85, 62}, {0x83, 25, 90, 62}}},
  {"ACID 303  ", 0, 4, 7, 0, 0, 70, {{1, 0, 99, 40}, {1, 0, 85, 58}, {}, {}, {0, 0, 85, 40}, {1, 0, 75, 62}}},
  {"ACID SQR  ", 0, 4, 6, 20, 0, 65, {{1, 0, 99, 45}, {2, 0, 80, 60}, {}, {}, {1, 0, 60, 45}, {1, 0, 62, 70}}},
  {"REESE BASS", 0, 4, 6, 75, 55, 50, {{1, 0, 90, 40}, {1, 0, 70, 45}, {1, 1, 90, 40}, {1, 1, 70, 45}, {1, 2, 90, 40}, {1, 2, 70, 45}}},
  {"SYNC LEAD ", 1, 4, 5, 85, 60, 60, {{1, 0, 99, 20}, {3, 0, 70, 30}, {}, {}, {1, 3, 85, 20}, {1, 0, 70, 25}}},
  {"TINE EP   ", 2, 4, 6, 30, 0, 55, {{1, 0, 94, 35}, {14, 0, 60, 75}, {1, 0, 86, 35}, {1, 0, 70, 45}, {1, 2, 82, 35}, {1, 0, 60, 50}}},
  {"MELLOW EP ", 2, 4, 3, 35, 10, 55, {{1, 0, 99, 30}, {1, 0, 65, 50}, {1, 0, 85, 32}, {3, 0, 50, 60}, {}, {}}},
  {"BRIGHT EP ", 2, 4, 6, 25, 5, 55, {{1, 0, 99, 38}, {14, 0, 72, 80}, {1, 0, 92, 38}, {1, 0, 78, 50}, {}, {}}},
  {"GLASS BELL", 3, 4, 0, 0, 0, 40, {{1, 0, 99, 25}, {3, 50, 80, 30}, {2, 0, 80, 25}, {5, 41, 70, 35}, {}, {}}},
  {"VIBE BELL ", 3, 4, 0, 0, 0, 50, {{1, 0, 99, 35}, {4, 0, 60, 55}, {1, 0, 85, 35}, {10, 0, 45, 70}, {}, {}}},
  {"DRAWBAR   ", 6, 31, 3, 99, 99, 75, {{1, 0, 95, 10}, {2, 0, 90, 10}, {0, 0, 95, 10}, {3, 0, 80, 10}, {4, 0, 75, 10}, {1, 0, 55, 60}}},
  {"CHURCH ORG", 6, 31, 0, 99, 99, 60, {{1, 0, 97, 10}, {2, 0, 90, 10}, {4, 0, 82, 10}, {0, 0, 87, 10}, {8, 0, 62, 10}, {3, 0, 72, 10}}},
};
void voxPatch(const PP& q, uint8_t p[156]) {                     // carriers hold the carrier sustain, modulators the modulator sustain; modulators react more to velocity (accent)
  groove_fm_factory(p, 0);
  for (int k = 0; k < 6; k++) { uint8_t* o = p + (5 - k) * 21; const PO& x = q.o[k]; const bool car = (CARRY[q.a & 31] >> k) & 1; const uint8_t sl = car ? q.sus : q.msus;
    memset(o, 0, 21); o[0] = 99; o[1] = x.d; o[2] = 99; o[3] = q.rr; o[4] = 99; o[5] = sl; o[6] = sl; o[15] = car ? 2 : 6; o[16] = x.l; o[17] = x.m >> 7; o[18] = x.m & 31; o[19] = x.f; o[20] = 7; }
  p[126] = p[128] = p[129] = 99; p[127] = 0; p[130] = p[131] = p[132] = p[133] = 50; p[134] = q.a; p[135] = q.fb; p[136] = 1; p[143] = 0; p[144] = 24; memcpy(p + 145, q.n, 10);
}
unsigned voxCount(unsigned t) { unsigned n = 0; for (const PP& q : VOX) n += q.role == t; return n; }
const PP& voxNth(unsigned t, unsigned k) { for (const PP& q : VOX) if (q.role == t && !k--) return q; return VOX[0]; }
// ---- tone knobs: DX7 carrier operators per algorithm (bit n = operator n+1); the other operators are modulators = the TONE (brightness) knob
unsigned tonePart(unsigned t, unsigned type) { const unsigned p = type == GROOVE_808 ? 11U : type == GROOVE_SAMPLE ? (unsigned)(g.pad[t] & 7) : 0U; return groove_tone_count(t, p) ? p : 0U; }
uint8_t shadow[NT][4 * NS]; int snapKey = 21;               // the notes as originally written (0 = not captured) and the key they were last fitted to
int fitNote(int n, int key) {                               // nearest note (ties go down) whose pitch class is in the scale of `key` = root + 12 * scale
  const algo::ScaleDef& sc = algo::SCALES[(key / 12) & 7];
  for (int d = 0; d < 7; d++) for (int up = 0; up < 2; up++) { const int m = n + (up ? d : -d); if (m < 0 || m > 127) continue; const int rel = ((m - key % 12) % 12 + 12) % 12; for (int i = 0; i < sc.n; i++) if (sc.iv[i] == rel) return m; }
  return n;
}
}  // namespace

bool seq_is_drum(unsigned track) { return groove_pad_count(track) != 0; }
int seq_cls(unsigned track) { return seq_is_drum(track) ? 3 : track == 4 ? 1 : 0; }
unsigned seq_style_count(unsigned track) { return (unsigned)algo::styleCount(seq_cls(track)); }

void seq_init() {
  for (unsigned t = 0; t < NT; t++) groove_sequence_length_set(t, (unsigned)g.len * NS);   // default: exactly 16 steps; the control loop keeps enforcing g.len
  struct groove_sequence_options o; groove_sequence_options_copy(&o);         // install the 16 chord qualities the generator uses (SDK chord ids 1..16)
  for (int q = 0; q < 16; q++) for (int i = 0; i < 8; i++) o.chord[q][i] = i < 6 ? algo::QTAB[q][i] : 0;
  groove_sequence_options_set(&o);
}

void seq_copy_bank(unsigned track, unsigned from, unsigned first, unsigned end) {          // copy one 16-step bank over banks [first,end)
  struct groove_step c[NS]; groove_sequence_read(track, absStep(from, 0), c, NS); groove_edit_checkpoint(0x60000U + track);
  for (unsigned b = first; b < end; b++) if (b != from) groove_sequence_replace(track, absStep(b, 0), c, NS);
}
void seq_set_len(unsigned n) {
  if (n < 1) n = 1; if (n > NBANK) n = NBANK; const unsigned old = g.len; g.len = (uint8_t)n; if (g.bank >= n) g.bank = (uint8_t)(n - 1);
  for (unsigned t = 0; t < NT; t++) {
    groove_sequence_length_set(t, n * NS);
    if (n <= old) continue;                                                  // growing: the new banks start as a copy of bank A, but only where they are still empty (never overwrites hidden steps)
    struct groove_step c[NS]; bool empty = true;
    for (unsigned b = old; b < n && empty; b++) { groove_sequence_read(t, absStep(b, 0), c, NS); for (int i = 0; i < NS; i++) if (c[i].velocity || c[i].drums) { empty = false; break; } }
    if (empty) seq_copy_bank(t, 0, old, n);
  }
}

void seq_read_bank(unsigned track, unsigned bank, Snap& s) {
  struct groove_step c[NS]; groove_sequence_read(track, absStep(bank, 0), c, NS); bool drum = seq_is_drum(track); unsigned pad = g.pad[track];
  for (int i = 0; i < NS; i++) {
    s.stepOn[i] = drum ? ((c[i].drums >> pad) & 1) : (c[i].velocity > 0); s.stepVel[i] = c[i].velocity; s.stepNote[i] = drum ? 60 : c[i].note;
    s.stepChord[i] = drum ? 0 : (c[i].drums & 31) != 0;
  }
}

void seq_punch(unsigned track, unsigned bank, unsigned step) {
  struct groove_step c; unsigned a = absStep(bank, step); groove_sequence_read(track, a, &c, 1);
  if (seq_is_drum(track)) { unsigned pad = g.pad[track]; bool on = (c.drums >> pad) & 1; groove_sequence_edit(track, a, groove_pad_note(track, pad), on ? 0 : 100); return; }
  if (c.velocity > 0) { groove_edit_checkpoint(0x10000U + track * 64U + a); c.velocity = 0; groove_sequence_replace(track, a, &c, 1); return; }   // toggle off, other steps untouched
  unsigned note = c.note ? c.note : g.lastNote[track]; g.lastNote[track] = (uint8_t)note; groove_sequence_edit(track, a, note, 100);
}

// STEP-REC: write (never toggle) one step; the pressed key's note for melodic tracks, the selected pad for drums.
void seq_step_write(unsigned track, unsigned bank, unsigned step, unsigned note) {
  unsigned a = absStep(bank, step); groove_edit_checkpoint(0x20000U + track * 64U + a);
  if (seq_is_drum(track)) { const int pi = groove_pad_index(track, note); if (pi >= 0) g.pad[track] = (uint8_t)pi; groove_sequence_edit(track, a, groove_pad_note(track, g.pad[track]), 100); return; }   // the drum you played
  g.lastNote[track] = (uint8_t)note; groove_sequence_edit(track, a, note, 100);
}
bool seq_has_steps(unsigned track) {                       // any step anywhere in the 64-step pattern (EMPTY-track hint, stem plan)
  struct groove_step c[NS]; for (unsigned b = 0; b < NBANK; b++) { groove_sequence_read(track, absStep(b, 0), c, NS); for (int i = 0; i < NS; i++) if (c[i].velocity || c[i].drums) return true; }
  return false;
}

void seq_new_prog() { algo::Rng R(g.genSeed * 2654435761u + 12345u); int f = g.fam; if (f > 3) { static const uint8_t TF[3] = {0, 3, 1}; const unsigned tr = g.sty[g.track] >> 5; f = tr < 3 ? TF[tr] : 4; }   // PROG = ANY follows the ALGORITHM tier: pop, ii-V-I, modal, anything
  algo::newProg(g.prog, f, g.scale, R); g.genSeed = g.genSeed * 1664525u + 1013904223u; }
void seq_style_apply(unsigned track, unsigned bank, int idx, algo::Result& out) {
  algo::Opts o{g.genSeed, g.scale, g.dens, g.chaos, g.human, g.oct, g.hold, g.sync, g.leap, g.voice, g.fam, {g.prog[0], g.prog[1], g.prog[2], g.prog[3]}}; struct groove_step cells[NS]; const unsigned base = absStep(bank, 0); const int cl = seq_cls(track);
  groove_sequence_read(track, base, cells, NS); groove_edit_checkpoint(0x7A000U + track);              // ONE undo point for the whole regeneration
  if (cl != 3) {
    static const uint8_t PROW[5] = {0, 1, 3, 5, 2};                                                    // percussion category -> groove row: kick, snare, hat, click, clap
    algo::Step st[NS]; algo::applyStyle(st, (int)track, cl, idx, o, out, PROW[g.pcat % 5], 48);
    for (int s = 0; s < NS; s++) {
      if (!st[s].vel) { cells[s].velocity = 0; cells[s].drums = 0; continue; }
      unsigned id = st[s].chord; if (id && st[s].note + 14 > 127) id = 0;
      cells[s].note = st[s].note; cells[s].velocity = st[s].vel; cells[s].drums = (uint16_t)(id | (st[s].gate << 5) | (st[s].prob << 9) | (st[s].tie << 12)); g.lastNote[track] = st[s].note;
    }
  } else {
    for (int s = 0; s < NS; s++) { cells[s].note = 0; cells[s].velocity = 0; cells[s].drums = 0; }
    for (int row = 0; row < 6; row++) {
      algo::Step st[NS]; algo::Result r; algo::applyStyle(st, (int)track, 3, idx, o, r, row, 0); if (row == 0) out = r;
      int pad = groove_source_type(track) == GROOVE_808 ? groove_pad_index(track, groove_drum_note(DRUM_ID[row])) : row;
      if (pad < 0 || (unsigned)pad >= groove_pad_count(track)) continue;
      for (int s = 0; s < NS; s++) if (st[s].vel) { cells[s].drums |= (uint16_t)(1U << pad); if (st[s].vel > cells[s].velocity) cells[s].velocity = st[s].vel; }
    }
  }
  groove_sequence_replace(track, base, cells, NS);
}

int seq_undo() { if (g.undone) return -1; int r = groove_edit_undo(); if (r == 0) g.undone = 1; return r == 0 ? 0 : -1; }       // the SDK keeps one snapshot that swaps
int seq_redo() { if (!g.undone) return -1; int r = groove_edit_undo(); if (r == 0) g.undone = 0; return r == 0 ? 0 : -1; }

void seq_lib_reset() { libOk = false; }
// CC 909 = the 808 engine retuned (part, parameter, value): brighter clicky kick, snappier snare, higher toms, crisp short hats.  CC 808 = those same parameters back at the engine defaults.
const uint8_t K909[40][2] = {{0x01, 78}, {0x02, 52}, {0x03, 84}, {0x04, 110}, {0x05, 60}, {0x06, 1}, {0x11, 100}, {0x12, 125}, {0x13, 88}, {0x14, 70}, {0x15, 40}, {0x16, 2}, {0x10, 100}, {0x50, 46}, {0x21, 84}, {0x22, 50}, {0x31, 90}, {0x32, 46}, {0x41, 96}, {0x42, 42}, {0x51, 96}, {0x52, 28}, {0x54, 30}, {0x61, 80}, {0x62, 56}, {0x63, 18}, {0x65, 30}, {0x66, 6}, {0x81, 100}, {0x82, 104}, {0x83, 50}, {0x84, 6}, {0x91, 80}, {0x92, 100}, {0x93, 60}, {0x94, 6}, {0xa1, 96}, {0xa2, 24}, {0xa3, 70}, {0xa4, 6}};   // CC 909 = the 808 engine retuned: {part<<4 | parameter, value}.  Kick: tone / short decay / high tune / click attack / CLIP drive.  Snare: snappy + SAT.  Toms, rim, clap tighter + higher; hats and cymbal bit-crushed (CRUSH), the 909 hats' 6-bit grit.  Row 2 = kick tune (marks the kit).                                                                      // closed hat: short, crushed (the 909 hats' 6-bit grit)
uint8_t seq_kit_guess() { uint8_t v[GROOVE_TONE_PARAMS]; return groove_source_type(7) == GROOVE_808 && (groove_tone_copy(7, 0, v), v[3] == K909[2][1]); }   // boot only: which kit the saved project holds
void kitApply(bool k9) { for (const auto& e : K909) { uint8_t v[GROOVE_TONE_PARAMS]; const unsigned pt = e[0] >> 4, pr = e[0] & 15; const fm1_param_t* d = groove_tone_parameter(7, pt, pr); if (!d) continue; groove_tone_copy(7, pt, v); groove_tone_edit(7, pt, pr, (int)(k9 ? e[1] : d->def) - (int)v[pr]); } }
void kitSet(bool k9) {                                     // T01 may sit on another engine (v3.8.2 used the sampler): switch first, apply once the 808 engine reports its parameters
  g.kit = k9; if (groove_source_type(7) == GROOVE_808 && groove_tone_count(7, 0)) { kitApply(k9); g.kitPend = 0; return; }
  groove_source_set(7, GROOVE_808); g.kitPend = 30;
}
void seq_kit_tick() { if (g.kitPend && !--g.kitPend) { if (groove_source_type(7) == GROOVE_808 && groove_tone_count(7, 0)) kitApply(g.kit); else g.kitPend = 30; } }
void seq_patch_name(unsigned track, char out[12]) {
  struct groove_view v; groove_get_view(track, 0, &v); out[0] = 0;
  if (track == 7 && v.type == GROOVE_808) { strcpy(out, g.kit ? "CC 909 KIT" : "CC 808 KIT"); return; }
  if (g.cur[track] != 255 && v.type == GROOVE_DX7) { uint8_t p[156]; struct groove_fm_controls c; if (groove_fm_copy(4, p, &c) == 0) { memcpy(out, p + 145, 10); out[10] = 0; for (int i = 9; i >= 0 && out[i] == ' '; i--) out[i] = 0; return; } }
  if (v.type == GROOVE_DX7 && libLoad()) { memcpy(out, libNames[v.program & 127], 11); for (int i = 9; i >= 0 && out[i] == ' '; i--) out[i] = 0; return; }
  static const char* const src[GROOVE_SOURCES] = {"FM", "303", "808", "PSG", "PLUCK", "SMP"}; strcpy(out, v.type < GROOVE_SOURCES ? src[v.type] : "?");
}
// CLEAR PROJECT (System Nav row 9): every pattern, mute / solo and the name go; the sounds, FX and the 16 saved slots stay.
// The SDK's own undo checkpoint is taken first (same path as loading a slot), so OCT- / UNDO brings everything back.

bool seq_clear_project() {
  struct groove_project* p = groove_project_scratch(); if (groove_project_capture(p)) return false;
  memset(p->step, 0, sizeof p->step); p->mute = p->solo = 0; memset(p->name, ' ', 12); memcpy(p->name, "UNTITLED", 8);
  return groove_project_apply_edit(p, 0x85000U) == 0;
}
// Engine presets for tracks that are not FM voices: a preset is just a set of that engine's own tone parameters (303: 12, pluck: 4).
struct EP { char n[10]; uint8_t v[12]; };
const EP E303[3] = {{"ACID SQL ", {40, 110, 100, 50, 100, 0, 64, 96, 30, 1, 21, 7}}, {"SUB BASS ", {25, 10, 10, 90, 40, 0, 64, 127, 0, 1, 21, 7}}, {"DIRTY RAT", {70, 80, 70, 60, 90, 0, 64, 56, 100, 2, 21, 20}}};
const EP EPLK[3] = {{"NYLON    ", {80, 60, 24, 30}}, {"HARP     ", {110, 90, 24, 60}}, {"MARIMBA  ", {45, 40, 24, 15}}};
__attribute__((noinline)) const EP* epTab(unsigned t, unsigned& np) { const unsigned ty = groove_source_type(t); np = ty == GROOVE_303 ? 12u : 4u; return ty == GROOVE_303 ? E303 : ty == GROOVE_PLUCK ? EPLK : nullptr; }
// One list per track: Chrome Boy's own voices first (T06 percussion, the A8 voices), then that track's voices from the factory banks; T01 = the two drum kits.
unsigned itemCount(unsigned t) { unsigned np; if (t != 7 && epTab(t, np)) return 3u; return t == 7 ? 2u : voxCount(t) + (libLoad() ? (unsigned)libCount(t) : 0u); }
void itemName(unsigned t, unsigned k, char* o) { unsigned np; const EP* ep = t != 7 ? epTab(t, np) : nullptr; if (ep) { memcpy(o, ep[k % 3].n, 10); return; } const unsigned nc = voxCount(t); if (t == 7) strcpy(o, k ? "CC 909" : "CC 808"); else if (k < nc) memcpy(o, voxNth(t, k).n, 11); else { const int p = libNth(t, (int)(k - nc)); memcpy(o, libNames[p < 0 ? 0 : p], 11); } }
unsigned itemCur(unsigned t) { if (t == 7) return g.kit; unsigned np; if (epTab(t, np)) return g.cur[t] == 255 ? 0u : g.cur[t] % 3u; if (g.cur[t] != 255) return g.cur[t]; struct groove_view v; groove_get_view(t, 0, &v); const int p = libPos(t, v.program & 127); return p < 0 ? 0u : (unsigned)p + voxCount(t); }
void itemApply(unsigned t, unsigned k) {
  if (t == 7) { kitSet(k != 0); return; }
  { unsigned np; const EP* ep = epTab(t, np); if (ep) { uint8_t v[GROOVE_TONE_PARAMS]; groove_tone_copy(t, 0, v); for (unsigned j = 0; j < np; j++) groove_tone_edit(t, 0, j, (int)ep[k % 3].v[j] - (int)v[j]); g.cur[t] = (uint8_t)(k % 3); return; } }
  const unsigned nc = voxCount(t); if ((t == 4 || groove_source_type(t) == GROOVE_PSG) && groove_source_type(t) != GROOVE_DX7) groove_source_set(t, GROOVE_DX7);   // PSG tracks (no presets of their own) become FM voices
  if (k < nc) { uint8_t p[156]; voxPatch(voxNth(t, k), p); groove_fm_import(t, p); g.cur[t] = (uint8_t)k; return; }
  g.cur[t] = 255; const int p = libNth(t, (int)(k - nc)); struct groove_view v; groove_get_view(t, 0, &v); if (p < 0) return;
  int d = p - (int)(v.program & 127); if (!d) { groove_control_edit(t, 1, 0, 0); d = -1; } groove_control_edit(t, d, 0, 0);
}
void seq_perc_check() { if (groove_source_type(4) != GROOVE_DX7) itemApply(4, g.cur[4] == 255 ? 0 : g.cur[4]); }   // a loaded project may bring the old sampler back
void seq_preset_rotate(unsigned track, int delta) {         // PRESETS knob: next / previous sound of THIS track only
  struct groove_view v; groove_get_view(track, 0, &v);
  unsigned npp; if (track != 7 && track != 4 && !epTab(track, npp) && (v.type != GROOVE_DX7 && v.type != GROOVE_PSG || !libLoad())) { groove_control_edit(track, delta, 0, 0); return; }
  const int n = (int)itemCount(track); if (n > 0) itemApply(track, (unsigned)(((int)itemCur(track) + delta % n + n) % n));
}
int seq_category_of(const char* n) {           // which track a factory voice belongs on (by name): 0 BASS 1 LEAD 2 E.PNO 3 BELL 4 PERC 5 PAD 6 ORGAN
  struct K { const char* w; int c; };
  static const K tab[] = {{"BRUSH", 7}, {"PERCU", 7}, {"TOM T", 7}, {"ECHO", 7}, {"NG 8", 7}, {"COWB", 4}, {"BLOCK", 4}, {"LOG D", 4}, {"TIMP", 4}, {"TAMB", 4}, {"CONGA", 4}, {"TIMBAL", 4}, {"BASS", 0}, {"BELL", 3}, {"GONG", 3}, {"GAM", 3}, {"KALIM", 3}, {"BEN", 3}, {"STEEL", 3}, {"TIBET", 3}, {"FINGER", 3}, {"MARIM", 3}, {"VIBE", 3},
    {"PIANO", 2}, {"GUITAR", 2}, {"E.P", 2}, {"CLAV", 2}, {"RHOD", 2}, {"HARP", 2}, {"LEAD", 1}, {"BRASS", 1}, {"WOODW", 1}, {"FLUTE", 1}, {"ORG", 6}, {"VOICE", 6}, {"CHOIR", 6}};
  char up[11]; int i = 0; for (; n[i] && i < 10; i++) up[i] = (n[i] >= 'a' && n[i] <= 'z') ? (char)(n[i] - 32) : n[i]; up[i] = 0;
  for (const K& k : tab) { size_t L = strlen(k.w); for (int p = 0; up[p]; p++) if (!strncmp(up + p, k.w, L)) return k.c; }
  return 5;
}
void seq_preset_page(unsigned track, Snap& s) {
  struct groove_view v; groove_get_view(track, 0, &v); s.pcount = 0; s.psel = 0; s.pMask = 0; s.pinfo[0][0] = 0; strcpy(s.pinfo[1], "");
  unsigned npp; if (track != 7 && track != 4 && !epTab(track, npp) && (v.type != GROOVE_DX7 && v.type != GROOVE_PSG || !libLoad())) { seq_patch_name(track, s.pinfo[0]); strcat(s.pinfo[0], " PRESETS"); strcpy(s.plist[0], "-"); s.pcount = 1; s.pTot = 0; return; }
  const int n = (int)itemCount(track), cur = (int)itemCur(track); int start = cur - 5; if (start > n - 12) start = n - 12; if (start < 0) start = 0;
  for (int k = 0; k < 12 && start + k < n; k++) { itemName(track, (unsigned)(start + k), s.plist[k]); s.plist[k][16] = 0; if (start + k == cur) s.psel = (uint8_t)k; s.pcount = (uint8_t)(k + 1); }
  s.pMask = 0x3FF; s.pTot = (uint8_t)n; s.pPos = (uint8_t)cur; strcpy(s.pinfo[0], "");
}


// HOME knobs.  DX7: K1 TONE (modulator level = brightness), K2 VOLUME, K3 FEEDBK, K4 ALGO.  Every other source: K1 K3 K4 = its first three tone parameters (names from the engine), K2 VOLUME.
void seq_param_edit(unsigned t, unsigned knob, int d) {
  if (knob == 1) { groove_control_edit(t, 0, d, 0); return; }
  const unsigned type = groove_source_type(t);
  if (type != GROOVE_DX7) { const unsigned part = tonePart(t, type), idx = knob ? knob - 1 : 0; if (idx < groove_tone_count(t, part)) groove_tone_edit(t, part, idx, d); return; }
  if (knob == 2) { groove_fm_edit(t, 135, d); return; } if (knob == 3) { groove_fm_edit(t, 134, d); return; }
  uint8_t p[156]; struct groove_fm_controls c; if (groove_fm_copy(t, p, &c) == 0) for (int n = 0; n < 6; n++) if (!((CARRY[p[134] & 31] >> n) & 1)) groove_fm_edit(t, (5 - n) * 21 + 16, d);
}
void seq_param_read(unsigned t, unsigned knob, char* txt, uint8_t& pos, const char*& label) {
  struct groove_view v; groove_get_view(t, 0, &v); int val = 0, mx = 127, shown; const char* nm = 0;
  if (knob == 1) { label = "VOLUME"; val = v.volume; }
  else if (v.type != GROOVE_DX7) {
    const unsigned part = tonePart(t, v.type), idx = knob ? knob - 1 : 0; const fm1_param_t* p = idx < groove_tone_count(t, part) ? groove_tone_parameter(t, part, idx) : 0; label = p ? p->name : "";
    if (p) { uint8_t vals[GROOVE_TONE_PARAMS]; groove_tone_copy(t, part, vals); val = vals[idx]; mx = p->max; if (p->names) nm = p->names[val]; } else nm = "--";
  } else {
    uint8_t pt[156]; struct groove_fm_controls c; const bool fm = groove_fm_copy(t, pt, &c) == 0;
    if (knob == 2) { label = "FEEDBK"; val = fm ? pt[135] : 0; mx = 7; } else if (knob == 3) { label = "ALGO"; val = fm ? pt[134] + 1 : 0; mx = 32; }
    else { label = "TONE"; int n = 0, sum = 0; if (fm) for (int o = 0; o < 6; o++) if (!((CARRY[pt[134] & 31] >> o) & 1)) { sum += pt[(5 - o) * 21 + 16]; n++; } val = n ? sum / n : 0; mx = 99; if (!n) nm = "--"; }
  }
  pos = (uint8_t)(val * 127 / (mx ? mx : 1)); shown = val - ((v.type == GROOVE_PSG || v.type == GROOVE_PLUCK) && knob == 3 ? 24 : v.type == GROOVE_SAMPLE && knob == 2 ? 24 : 0);   // the stock tone page shows these two offset by 24
  if (nm) { strncpy(txt, nm, 7); txt[7] = 0; return; }
  char* e = txt; if (shown < 0) { *e++ = '-'; shown = -shown; } if (shown >= 100) *e++ = (char)('0' + shown / 100); if (shown >= 10) *e++ = (char)('0' + shown / 10 % 10); *e++ = (char)('0' + shown % 10); *e = 0;
}
}  // namespace cb

namespace cb {
// ---------------------------------------------------------------- EDIT page: piano roll / tracker data and edits
void seq_edit_fill(unsigned track, unsigned bank, Snap& s) {
  struct groove_step c[NS]; groove_sequence_read(track, absStep(bank, 0), c, NS); const bool drum = seq_is_drum(track); s.edPads = (uint8_t)groove_pad_count(track);
  for (unsigned p = 0; p < s.edPads && p < 16; p++) { const char* l = groove_pad_label(track, p); if (l) strncpy(s.padLbl[p], l, 4); }
  for (int i = 0; i < NS; i++) {                                   // melodic cell: bits 0..4 chord, 5..8 gate, 9..11 probability, 12 tie.  Drum cell: pad mask.
    if (drum) { s.edMask[i] = c[i].drums; continue; }
    s.edChord[i] = c[i].drums & 31; s.edGate[i] = (c[i].drums >> 5) & 15; s.edProb[i] = (c[i].drums >> 9) & 7; s.edTie[i] = (c[i].drums >> 12) & 1;
    if (s.edChord[i]) strncpy(s.edChordName[i], seq_chord_name(s.edChord[i]), 4);
  }
}
int seq_edit_pitch(unsigned track, unsigned a, int delta) {
  if (seq_is_drum(track)) return -1; struct groove_step c; groove_sequence_read(track, a, &c, 1);
  int n = (c.velocity ? c.note : g.lastNote[track]) + delta; n = n < 1 ? 1 : n > 127 ? 127 : n; g.lastNote[track] = (uint8_t)n;
  if (c.velocity) { groove_edit_checkpoint(0x30000U + track * 64U + a); groove_sequence_edit(track, a, (unsigned)n, c.velocity); }
  return n;
}
void seq_edit_nudge(unsigned track, unsigned a, int delta, unsigned span) {
  const unsigned b = (a + span + (unsigned)delta) % span; struct groove_step ca, cb; groove_sequence_read(track, a, &ca, 1); groove_sequence_read(track, b, &cb, 1);
  groove_edit_checkpoint(0x40000U + track * 64U + a); groove_sequence_replace(track, a, &cb, 1); groove_sequence_replace(track, b, &ca, 1);
}
void seq_edit_bank(unsigned track, unsigned bank, int semis, int vel) {
  struct groove_step c[NS]; groove_sequence_read(track, absStep(bank, 0), c, NS); const bool drum = seq_is_drum(track); groove_edit_checkpoint(0x50000U + track);
  for (int i = 0; i < NS; i++) {
    if (!c[i].velocity) continue;
    if (!drum && semis) { int n = c[i].note + semis; c[i].note = (uint8_t)(n < 0 ? 0 : n > 127 ? 127 : n); }
    if (vel) { int v = c[i].velocity + vel; c[i].velocity = (uint8_t)(v < 1 ? 1 : v > 127 ? 127 : v); }
  }
  groove_sequence_replace(track, absStep(bank, 0), c, NS);
}
const char* seq_chord_name(unsigned id) { const char* n = groove_sequence_chord_name(id); return n ? n : ""; }
bool seq_hidden_steps() { struct groove_step c[NS]; for (unsigned t = 0; t < NT; t++) for (unsigned b = g.len; b < NBANK; b++) { groove_sequence_read(t, absStep(b, 0), c, NS); for (int i = 0; i < NS; i++) if (c[i].velocity || c[i].drums) return true; } return false; }
void seq_snap(int newKey) {                                 // key change: pull every melodic note into the key; changing back restores the original notes
  groove_edit_checkpoint(0x7B000U);
  for (unsigned t = 0; t < NT; t++) {
    if (seq_is_drum(t)) continue; struct groove_step c[4 * NS]; groove_sequence_read(t, 0, c, 4 * NS); bool chg = false;
    for (int i = 0; i < 4 * NS; i++) {
      if (!c[i].velocity) { shadow[t][i] = 0; continue; }
      if (!shadow[t][i] || c[i].note != fitNote(shadow[t][i], snapKey)) shadow[t][i] = c[i].note;   // new, or edited / regenerated since the last snap: that is now the original
      const int n = fitNote(shadow[t][i], newKey); if (n != c[i].note) { c[i].note = (uint8_t)n; chg = true; }
    }
    if (chg) groove_sequence_replace(t, 0, c, 4 * NS);
  }
  snapKey = newKey;
}
// SEND: one SysEx dump of the 16-step bank, F0 7D 'C' 'B' 'P' track bank { note vel cellLo7 cellHi7 } x16 F7, to every physical MIDI output (DIN, USB).
void seq_send_dump(unsigned track, unsigned bank) {
  uint8_t m[80]; unsigned n = 0; struct groove_step c[NS]; groove_sequence_read(track, absStep(bank, 0), c, NS);
  m[n++] = 0xF0; m[n++] = 0x7D; m[n++] = 'C'; m[n++] = 'B'; m[n++] = 'P'; m[n++] = (uint8_t)track; m[n++] = (uint8_t)bank;
  for (int i = 0; i < NS; i++) { m[n++] = c[i].note & 127; m[n++] = c[i].velocity & 127; m[n++] = c[i].drums & 127; m[n++] = (uint8_t)((c[i].drums >> 7) & 127); }
  m[n++] = 0xF7; for (unsigned p = 0; p < 2; p++) if ((fm1_midi_output_ports() >> p) & 1U) (void)fm1_midi_send_port(p, m, n);
}
// REC held + K1..K4 on HOME: write the move into the engine's parameter-lock table (project-stored, 16 locks, plays back with the pattern).
int seq_lock_id(unsigned track, unsigned knob) {                           // the engine locks ENGINE parameter ids: DX7 = patch offset, 303/PSG/pluck = tone index, sampler = pad*6+index, 808 = volume only
  const unsigned type = groove_source_type(track);
  if (type == GROOVE_808) return knob == 1 ? 0 : -1;
  if (knob == 1) return -1;                                                   // VOLUME can only be locked on the 808
  if (type == GROOVE_DX7) { if (knob == 2) return 135; if (knob == 3) return 134; uint8_t p[156]; struct groove_fm_controls c; if (groove_fm_copy(track, p, &c)) return -1; for (int n = 0; n < 6; n++) if (!((CARRY[p[134] & 31] >> n) & 1)) return (5 - n) * 21 + 16; return -1; }   // TONE: output level of the first modulator
  const unsigned idx = knob ? knob - 1 : 0; return type == GROOVE_SAMPLE ? (int)((g.pad[track] & 7) * 6 + idx) : (int)idx;
}
bool seq_record_lock(unsigned track, unsigned bank, unsigned step, unsigned knob, unsigned value) {      // REC + knob: write the move into the engine's parameter-lock table (project-stored, plays back with the pattern)
  const int id = seq_lock_id(track, knob); if (id < 0) return false;
  struct groove_sequence_options o; groove_sequence_options_copy(&o); const unsigned a = bank * NS + step; int slot = -1;
  for (unsigned i = 0; i < GROOVE_LOCKS; i++) if (o.lock[i].track == track && o.lock[i].step == a) { slot = (int)i; break; }              // the engine applies ONE lock per track per step
  for (unsigned i = 0; i < GROOVE_LOCKS && slot < 0; i++) if (o.lock[i].track == 255) slot = (int)i;
  if (slot < 0) slot = g.lockNext++ & 15;                                     // all 16 locks (whole project) in use: overwrite the oldest, round-robin
  o.lock[slot].track = (uint8_t)track; o.lock[slot].step = (uint8_t)a; o.lock[slot].parameter = (uint8_t)id; o.lock[slot].value = (uint8_t)value; groove_sequence_options_set(&o); return true;
}
void seq_hold(unsigned track, unsigned pos, unsigned note, uint32_t ms, uint32_t stepMs) {   // the engine records only the note-on; this writes how long the key was held
  const unsigned len = groove_sequence_length(track); if (pos >= len || !stepMs) return; struct groove_step c; unsigned p = pos;
  groove_sequence_read(track, p, &c, 1); if (!c.velocity || (c.note != note && !(c.drums & 31))) { p = (pos + 1) % len; groove_sequence_read(track, p, &c, 1); if (!c.velocity || (c.note != note && !(c.drums & 31))) return; }   // the engine rounds to the nearest step: try both
  unsigned S = (unsigned)((uint64_t)ms * 16U / stepMs); if (S < 1) S = 1; unsigned cells = (S + 15) / 16; if (cells > len) cells = len;
  for (unsigned k = 0; k < cells; k++) {                                       // < 1 step: gate length.  Longer: a chain of tied cells of the same note (a tied note keeps sounding without retriggering)
    struct groove_step w = c; const bool last = k == cells - 1; unsigned gate = last ? S - 16 * k : 15; gate = gate < 1 ? 1 : gate > 15 ? 15 : gate;
    w.drums = (uint16_t)((c.drums & ~((15U << 5) | (1U << 12))) | (gate << 5) | (last ? 0U : 1U << 12)); groove_sequence_replace(track, (p + k) % len, &w, 1);
  }
}
}  // namespace cb
