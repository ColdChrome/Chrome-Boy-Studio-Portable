// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM / M-VAVE FM1 - FX rack.  REVERB + DELAY drive the engine's groove_effects_* / groove_sends_* hooks;
// CHORUS / OVERDRIVE / COMPRESSOR / FILTER+OUT are master inserts (fx_core.hpp) run from fm1_output_mix().
// K4 picks the effect, K1..K3 edit its parameters, REC held + knob = record the move into the bank's automation lane.
#include "cb_core.h"
#include <string.h>

namespace cb {
InsertParams insertParams = {0, 0, 0, 0, 127, 0, 127};
namespace {
InsertFx insertFx;
struct Slot { uint8_t id, val; };                 // id = unit*3 + knob + 1 (0 = empty)
Slot lane[NBANK][NS];
uint8_t laneId[NBANK];
constexpr int NK[6] = {2, 3, 2, 1, 1, 3};         // knobs used by each unit
volatile uint8_t* insertField(unsigned u, unsigned k) {
  switch (u) { case 2: return k == 0 ? &insertParams.chorusDepth : &insertParams.chorusMix; case 3: return &insertParams.drive; case 4: return &insertParams.comp;
    case 5: return k == 0 ? &insertParams.cutoff : k == 1 ? &insertParams.res : &insertParams.level; default: return nullptr; }
}
int get(unsigned u, unsigned k, unsigned track) {                       // current value 0..127 of (unit, knob)
  uint8_t e[4], sd[2];
  if (u == 0) { if (k == 0) { groove_effects_get(e); return e[0]; } groove_sends_get(track, sd); return sd[0] * 127 / 15; }
  if (u == 1) { if (k == 0) { groove_effects_get(e); return e[1]; } if (k == 1) { groove_effects_get(e); return e[2]; } groove_sends_get(track, sd); return sd[1] * 127 / 15; }
  volatile uint8_t* f = insertField(u, k); return f ? *f : 0;
}
void apply(unsigned u, unsigned k, unsigned track, int target) {        // move a parameter to an absolute value (used by lane playback)
  if (target < 0) target = 0; if (target > 127) target = 127;
  if (u >= 2) { volatile uint8_t* f = insertField(u, k); if (f) *f = (uint8_t)target; return; }
  for (int guard = 0; guard < 24; guard++) {
    int cur = get(u, k, track), d = target - cur; if (!d) return; d = d > 4 ? 4 : d < -4 ? -4 : d; int step = (u == 0 && k == 1) || (u == 1 && k == 2) ? (d > 0 ? 1 : -1) : d;
    if (u == 0 && k == 0) groove_effects_edit(0, d); else if (u == 1 && k == 0) groove_effects_edit(1, d); else if (u == 1 && k == 1) groove_effects_edit(2, d);
    else groove_sends_edit(track, u == 0 ? 0 : 1, step);
    if (get(u, k, track) == cur) return;                                // quantised parameter: stop once it no longer moves
  }
}
void pctText(char* o, int v127) { int p = (v127 * 100 + 63) / 127; int i = 0; if (p >= 100) o[i++] = '1'; if (p >= 10) o[i++] = (char)('0' + p / 10 % 10); o[i++] = (char)('0' + p % 10); o[i++] = '%'; o[i] = 0; }
}  // namespace

void fx_init() { memset(lane, 0, sizeof lane); memset(laneId, 0, sizeof laneId); insertFx.reset(); }
void fx_select(int delta) { g.fxSel = (uint8_t)((g.fxSel + delta % 6 + 6) % 6); }

void fx_knob(unsigned k, int delta, unsigned track, bool recording, unsigned bank, int playStep) {
  unsigned u = g.fxSel; if ((int)k >= NK[u]) return;
  if (u >= 2) { volatile uint8_t* f = insertField(u, k); int v = *f + delta; *f = (uint8_t)(v < 0 ? 0 : v > 127 ? 127 : v); }
  else if (u == 0) { if (k == 0) groove_effects_edit(0, delta); else groove_sends_edit(track, 0, delta); }
  else { if (k == 0) groove_effects_edit(1, delta); else if (k == 1) groove_effects_edit(2, delta); else groove_sends_edit(track, 1, delta); }
  if (recording && playStep >= 0 && bank < NBANK) {                       // REC + knob: write the value into the bank's FX lane at the playing step
    uint8_t id = (uint8_t)(u * 3 + k + 1); if (laneId[bank] != id) { memset(lane[bank], 0, sizeof lane[bank]); laneId[bank] = id; }
    lane[bank][playStep & 15] = Slot{id, (uint8_t)(get(u, k, track) | 1)};   // |1 marks "has data" even for value 0
  }
}

void fx_step_tick(unsigned bank, int playStep) {                          // called when the sequencer step changes
  if (bank >= NBANK || playStep < 0 || !laneId[bank]) return; const Slot& sl = lane[bank][playStep & 15]; if (!sl.id) return;
  unsigned u = (sl.id - 1) / 3, k = (sl.id - 1) % 3; apply(u, k, g.track, sl.val & ~1);
}

void fx_fill(Snap& s, unsigned track, unsigned bank) {
  s.fxSel = g.fxSel; for (unsigned u = 0; u < 6; u++) for (unsigned k = 0; k < 3; k++) { if ((int)k >= NK[u]) { s.fxv[u][k] = 0; s.fxtxt[u][k][0] = 0; continue; } int v = get(u, k, track); s.fxv[u][k] = (uint8_t)v; pctText(s.fxtxt[u][k], v); }
  static const char* const nm[18] = {"REV TIME", "REV MIX", "", "DLY TIME", "DLY FDBK", "DLY MIX", "CHO DEPTH", "CHO MIX", "", "DRIVE", "", "", "COMP", "", "", "CUTOFF", "RES", "LEVEL"};
  unsigned id = bank < NBANK ? laneId[bank] : 0; strcpy(s.fxLane, id ? nm[id - 1] : "-"); for (int i = 0; i < NS; i++) s.fxLaneVal[i] = (bank < NBANK && lane[bank][i].id) ? (uint8_t)(lane[bank][i].val & ~1) : 0;
}

// Audio-callback hook: add ONE call at the top of fm1_output_mix() (tools/apply_patch.py does it).
extern "C" FM1_AUDIO_CODE void cb_fx_insert(int32_t* interleaved24, unsigned frames) { insertFx.process(interleaved24, (int)frames, insertParams); }   // lives in .volatile_ram_code like the rest of the audio path
}  // namespace cb
