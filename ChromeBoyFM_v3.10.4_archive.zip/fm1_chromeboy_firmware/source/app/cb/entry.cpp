// SPDX-License-Identifier: GPL-3.0-only
// The SDK entry points that replace the stock app/screen.c.  Kept in their own tiny file because this one must NOT be link-time
// optimised (the PI32 LTO plugin can drop definitions that override weak SDK defaults); everything else in app/cb is.
#include "cb_core.h"
void cb_screen_init(); void cb_screen_tap(uint32_t t); void cb_screen_mmc(unsigned c); void cb_screen_control();
extern "C" {
void groove_screen_init(void) { cb_screen_init(); }
void groove_screen_tap(uint32_t t) { cb_screen_tap(t); }
void groove_screen_mmc(unsigned c) { cb_screen_mmc(c); }
void groove_screen_control(void) { cb_screen_control(); }
void stock_app_midi_received(unsigned source, const uint8_t* m, size_t n);          // M-VAVE's router, renamed by the build (-Dfm1_app_midi_received=stock_app_midi_received)
void fm1_app_midi_received(unsigned source, const uint8_t* m, size_t n) { stock_app_midi_received(source, m, n); }
}
