// SPDX-License-Identifier: GPL-3.0-only
// Internal API between the SDK-bound modules (main.cpp, sequencer.cpp, fx_rack.cpp).
#pragma once
#pragma GCC diagnostic ignored "-Wmisleading-indentation"   // dense one-line style used throughout the patch
#include "cb.h"
#include "algo_styles.hpp"
#include "fx_core.hpp"

extern "C" {
#include "instrument.h"          // groove_* control API (app/instrument.h)
#include "fm_patch.h"            // groove_fm_library_* (DX7 voice banks)
#include "fm1.h"                 // fm1_controls_read / fm1_led_set / fm1_screen_submit / fm1_millis
#include "fm1_engine_control.h"  // fm1_engine_output_level
}

namespace cb {
struct Core {                                    // all firmware-side state that the SDK does not store.  Zero-initialised (lives in RAM, not Flash); groove_screen_init sets the few non-zero defaults.
  uint8_t page, track, bank, rec, fxSel, undone, stepRec, recStep;
  uint16_t sty[NT];                              // ALGORITHM seed per track (melodic 0..998, drums 0..8)
  uint8_t styValid[NT];
  algo::Result info[NT];
  uint32_t genSeed; uint8_t dens, chaos, human; int8_t oct; int scale;
  uint8_t pad[NT];                               // selected drum pad per drum track (punch target)
  uint8_t lastNote[NT];
  uint8_t genFlash, algoShow, boot, master, heldStep, catSel;
  uint32_t frame;
  uint8_t svUsed[16]; char svName[16][13];                                  // cached SDK slot info (flash is only read when SAVE opens / after a save)
  uint8_t svRow, svConfirm, loops; uint32_t svConfirmAt, algoKeysUntil;   // SAVE page cursor, 2-tap confirm, ALGORITHM window key capture
  int8_t kOct; uint8_t cur[NT], unm, kit, kitPend, nmOn, nmCur; char nm[7]; uint8_t len, edView, edSet, edStep, glo, navSel, pvNote, pvTrack, homeFired;   // len = loop length in 16-step banks (project setting, default 1 = 16 steps)
  uint8_t hold, sync, leap, voice, fam, genSet, prog[4], pcat, lockKnob, genDirty, lockNext;   // generator controls (SEQ page), the shared chord progression (scale degrees), percussion category of track 7, knob last recorded
  uint8_t xs, xi, xn, xtr[8];                      // EXPORT TO DAW state machine
  uint32_t pvOffAt, homeAt, genAt, xt, xdur; bool homeDown; uint8_t xwrap, tail, cin, xpct; uint16_t xlast;   // export: loops finished, TAIL 0 RING / 1 CUT, saved count-in, % of the pass, last playhead step
  char toast[34]; uint32_t toastUntil; bool intro;                          // the HOME overlay is open (it opens at first boot)
};
extern Core g;

// ---- sequencer.cpp (16-step bank view over the SDK's 64-step pattern; chords/arp/undo/presets)
void seq_init();
bool seq_is_drum(unsigned track);
void seq_read_bank(unsigned track, unsigned bank, Snap& s);
void seq_punch(unsigned track, unsigned bank, unsigned step);
void seq_step_write(unsigned track, unsigned bank, unsigned step, unsigned note);   // step-record
bool seq_has_steps(unsigned track);
void seq_style_apply(unsigned track, unsigned bank, int styleIdx, algo::Result& out);
void seq_new_prog();                                                              // roll a new chord progression for every pitched track (shared harmony)
int  seq_cls(unsigned track);                                                     // 0 melodic, 1 percussion (track 7), 2 ear-candy FX (track 8), 3 drum kit
int  seq_undo();                                  // 0 ok, -1 nothing to undo
int  seq_redo();
void seq_preset_rotate(unsigned track, int delta);
void seq_perc_check(); bool seq_clear_project(); uint8_t seq_kit_guess(); void seq_kit_tick();
void seq_patch_name(unsigned track, char out[12]);
int  seq_category_of(const char* name);           // index into FM_CATS, 9 = FX/other
void seq_preset_page(unsigned track, Snap& s);   // fills plist/psel/pcount/pinfo for THIS track only
void seq_lib_reset();                             // re-read the 4 DX7 voice banks the next time they are needed
void seq_snap(int newKey);                        // pull every melodic note into the key (reversible: the original notes are remembered)
unsigned seq_style_count(unsigned track);   // the generator tables live in sequencer.cpp only
void seq_copy_bank(unsigned track, unsigned from, unsigned first, unsigned end);
void seq_set_len(unsigned banks);                 // loop length in 16-step banks (project setting); growing copies the first bank into empty new banks
void seq_param_edit(unsigned track, unsigned knob, int delta);   // K1..K4 on HOME
void seq_param_read(unsigned track, unsigned knob, char* txt, uint8_t& pos, const char*& label);
bool seq_record_lock(unsigned track, unsigned bank, unsigned step, unsigned knob, unsigned value);   // false = the engine cannot automate that knob
int  seq_lock_id(unsigned track, unsigned knob);                                   // engine lock-parameter id for HOME knob K1..K4 (-1: none)
void seq_hold(unsigned track, unsigned pos, unsigned note, uint32_t ms, uint32_t stepMs);   // live-recorded note was held for ms: write its length
// ---- EDIT page (sequencer.cpp)
void seq_edit_fill(unsigned track, unsigned bank, Snap& s);                       // per-step cells for the piano roll / tracker
int  seq_edit_pitch(unsigned track, unsigned step, int delta);                   // K1: pitch of the step (or the pencil when the step is empty); returns the note to audition, -1 for none
void seq_edit_nudge(unsigned track, unsigned step, int delta, unsigned span);    // K2: move the step one place in time inside the loop
void seq_edit_bank(unsigned track, unsigned bank, int semis, int vel);           // set B: transpose / scale the velocity of the whole 16-step bank
const char* seq_chord_name(unsigned id);                                         // never null
bool seq_hidden_steps();                                                         // true when a track holds steps beyond the current loop length
void seq_send_dump(unsigned track, unsigned bank);                               // SEND: one SysEx dump of the bank on USB-MIDI

// ---- fx_rack.cpp
void fx_init();
void fx_knob(unsigned k, int delta, unsigned track, bool recording, unsigned bank, int playStep);   // K1..K3 edit the selected effect, K4 is handled by the caller
void fx_select(int delta);
void fx_fill(Snap& s, unsigned track, unsigned bank);
void fx_step_tick(unsigned bank, int playStep);   // plays the recorded automation lane back
extern InsertParams insertParams;                 // read by the audio callback
extern "C" FM1_AUDIO_CODE void cb_fx_insert(int32_t* interleaved24, unsigned frames);   // called from fm1_output_mix()

// ---- main.cpp helpers
void toast(const char* msg);
unsigned disp_to_hw(unsigned pos);   // SELECT order: DRUMS first, then FM tracks 1-7
unsigned hw_to_disp(unsigned hw);

}  // namespace cb
