// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM v3.5.0 "The Sunken Shrine" - M-VAVE FM1 edition: control loop + panel mapping.
// Replaces the four app/screen.c entry points (groove_screen_init / _control / _tap / _mmc) with this implementation;
// tools/apply_patch.py renames the stock ones (-D...=stock_...) so the stock file still links.
//
// Panel map (fm1_controls):   encoders[0] SELECT  [1] ALGORITHM  [2..5] KNOB 1..4  [6] PRESETS  + MASTER pot (knob ADC)
//   buttons: OCT- OCT+ FX SCL ENV LFO EDIT GLO HOME SAVE ARP SEQ PLAY REC     keys: 27 (F3..G5), the 16 white ones = steps 01..16
#include "cb_core.h"
#include <string.h>
extern "C" {
#include "fm1_device.h"          // fm1_device_usb_connected()
}

namespace cb {
Core g;
namespace { const uint8_t DISP[NT] = {7, 0, 1, 2, 3, 4, 5, 6}; }                   // SELECT order: DRUMS first (hardware track 8), then FM 1-7
unsigned disp_to_hw(unsigned pos) { return DISP[pos & 7]; }
unsigned hw_to_disp(unsigned hw) { for (unsigned i = 0; i < NT; i++) if (DISP[i] == hw) return i; return 0; }
namespace {
const uint8_t WHITE_IDX[16] = {0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26};
const uint8_t BLACK_IDX[11] = {1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25};
const char* const NOTE[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
const char* const SCALE_NAME[8] = {"MAJOR", "MINOR", "DORIAN", "PHRYG", "LYDIAN", "MIXOLY", "PENT-m", "PENT-M"};
const char* const TRK_NAME[8] = {"BASS", "LEAD", "E.PNO", "BELL", "PERC", "PAD", "ORGAN", "DRUMS"};
const char* const SRC_NAME[6] = {"FM", "303", "808", "PSG", "PLUCK", "SMP"};

struct fm1_controls prev, now;
Snap snap; uint16_t band[FM1_SCREEN_WIDTH * 16]; unsigned bandNo = 0; uint32_t frameAt = 0, recDownAt = 0; bool recWas = false, recHeld = false; int lastStep = -1;
uint8_t heldWhite[17];

void num(char* o, int v) { int i = 0; if (v < 0) { o[i++] = '-'; v = -v; } if (v >= 100) o[i++] = (char)('0' + v / 100); if (v >= 10) o[i++] = (char)('0' + v / 10 % 10); o[i++] = (char)('0' + v % 10); o[i] = 0; }
void pct(char* o, int v127) { num(o, (v127 * 100 + 63) / 127); strcat(o, "%"); }
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
void cpy(char* d, const char* s, size_t n) { strncpy(d, s, n - 1); d[n - 1] = 0; }
// Live notes reach a track through ITS MIDI input channel (that is how groove_midi_local routes them, same as M-VAVE's panel code).
// The track number is not the channel: on a saved project they can differ, and then the note went nowhere unless the sequencer played it back.
uint8_t inCh(unsigned t) { return (uint8_t)(groove_midi_input_channel(t) & 15); }
void post(uint8_t status, uint8_t a, uint8_t b, unsigned bytes) { const uint8_t m[3] = {status, a, b}; (void)groove_midi_local(m, bytes); }

bool playing() { struct groove_view v; groove_get_view(g.track, 0, &v); return v.playing != 0; }
int playStep() { struct groove_view v; groove_get_view(g.track, 0, &v); if (!v.playing) return -1; int s = (int)v.play_step - (int)(g.bank * NS); return s >= 0 && s < NS ? s : -1; }
void toggle(uint8_t p) { if (g.intro) { g.intro = false; return; } g.page = g.page == p ? (uint8_t)P_HOME : p; }
void newProgression();
void runStyle(bool announce) {
  seq_style_apply(g.track, g.bank, g.sty[g.track], g.info[g.track]); g.styValid[g.track] = 1; if (announce) { g.page = P_HOME; } g.genFlash = 12;
}

// ---------------------------------------------------------------- EXPORT TO DAW: each track plays alone, one after the other; the DAW records ONE long file and you slice it into stems
enum { X_IDLE, X_ASK, X_LEAD, X_PLAY, X_GAP, X_DONE };
uint8_t soloWas[NT], muteWas[NT]; bool soloSaved = false;
void exSolo(int track) {
  struct groove_view v; if (!soloSaved) { for (unsigned t = 0; t < NT; t++) { groove_get_view(t, 0, &v); soloWas[t] = v.solo; muteWas[t] = v.muted; } soloSaved = true; }
  for (unsigned t = 0; t < NT; t++) { groove_get_view(t, 0, &v); const bool want = (int)t == track; if (track < 0) { if (v.solo) groove_mix_toggle(t, 1); if (v.muted) groove_mix_toggle(t, 0); } else { if ((bool)v.solo != want) groove_mix_toggle(t, 1); if (want && v.muted) groove_mix_toggle(t, 0); } }
}
void exRestore() {
  if (!soloSaved) return; struct groove_view v;
  for (unsigned t = 0; t < NT; t++) { groove_get_view(t, 0, &v); if ((bool)v.solo != (bool)soloWas[t]) groove_mix_toggle(t, 1); if ((bool)v.muted != (bool)muteWas[t]) groove_mix_toggle(t, 0); } soloSaved = false;
}
// A pass ends on a STEP, not on a timer: the playhead is watched, and the transport stops the moment it wraps after the last loop.
// (v3.9.0 stopped on a wall-clock timer with a fixed +1.5 s tail while the sequencer kept looping, so the first steps of the pattern played again.)
// Ring-out happens in the silent gap AFTER the stop.  TAIL CUT also kills the voices at the barline.  A safety timer ends a pass that never starts.
void exPass(uint32_t ms) { exSolo(g.xtr[g.xi]); post(0xFA, 0, 0, 1); g.xs = X_PLAY; g.xt = ms; g.xwrap = 0; g.xlast = 0; g.xpct = 0; g.xdur = (uint32_t)g.loops * g.len * NS * (15000u / (groove_tempo_current() ? groove_tempo_current() : 120)) * 2 + 4000; }
void exEnd(bool done) { post(0xFC, 0, 0, 1); if (g.cin) groove_sequence_setting_edit(2, 1); g.cin = 0; exRestore(); g.xs = done ? X_DONE : X_IDLE; if (!done) toast("CANCELLED"); }
void exBegin() {
  g.xn = 0; for (unsigned p = 0; p < NT; p++) { const unsigned hw = disp_to_hw(p); if (seq_has_steps(hw)) g.xtr[g.xn++] = (uint8_t)hw; }
  if (!g.xn) { g.xs = X_IDLE; toast("NO STEPS"); return; }
  g.cin = (uint8_t)groove_sequence_setting(2); if (g.cin) groove_sequence_setting_edit(2, -1);        // the count-in bar must not be recorded
  if (playing()) post(0xFC, 0, 0, 1); g.xi = 0; g.xs = X_LEAD; g.xt = fm1_millis();                    // 4 s lead-in: start your DAW recording now
}
void exportTick(uint32_t ms) {
  if (g.xs < X_LEAD || g.xs == X_DONE) return; const uint32_t el = ms - g.xt;
  if (g.xs == X_LEAD) { if (el > 4000) exPass(ms); }
  else if (g.xs == X_PLAY) {
    struct groove_view v; groove_get_view(g.xtr[g.xi], 0, &v); const unsigned span = (unsigned)g.len * NS;
    if (v.playing) { if (v.play_step < g.xlast) g.xwrap++; g.xlast = v.play_step; g.xpct = (uint8_t)clampi((int)((g.xwrap * span + v.play_step) * 100u / (g.loops * span)), 0, 100); }
    if (g.xwrap >= g.loops || el >= g.xdur) { post(0xFC, 0, 0, 1); if (g.tail) groove_midi_panic(); g.xs = X_GAP; g.xt = ms; }   // 2 s of silence between stems makes them easy to slice
  }
  else if (el > 2000) { if (++g.xi >= g.xn) exEnd(true); else exPass(ms); }
}
void refreshSlots() { for (unsigned i = 0; i < GROOVE_PROJECT_SLOTS; i++) { char nm[13]; g.svUsed[i] = groove_project_info(i, nm) == 0; memcpy(g.svName[i], nm, 13); } }

void setScale(int sc) { if (sc == g.scale) return; g.scale = sc; seq_snap(sc); toast("KEY SNAP"); }                    // root / scale change: every melodic track follows, live and reversible
void noteTxt(char* o, int n) { strcpy(o, NOTE[n % 12]); num(o + strlen(o), n / 12 - 1); }
void probTxt(char* o, unsigned p) { if (!p) strcpy(o, "ALWAYS"); else { o[0] = (char)('0' + p); o[1] = '/'; o[2] = '8'; o[3] = 0; } }
void preview(unsigned t, unsigned n) {                                       // audition the pitch you just changed (released by the control loop)
  if (g.pvNote) post((uint8_t)(0x80 | g.pvTrack), g.pvNote, 0, 3);
  g.pvNote = (uint8_t)n; g.pvTrack = inCh(t); g.pvOffAt = fm1_millis() + 160; post((uint8_t)(0x90 | g.pvTrack), (uint8_t)n, 90, 3);   // pvTrack holds the channel the note was started on
}
void panic() {
  for (unsigned t = 0; t < NT; t++) { post((uint8_t)(0xB0 | inCh(t)), 123, 0, 3); post((uint8_t)(0xB0 | inCh(t)), 120, 0, 3); }
  g.pvNote = 0; groove_midi_panic(); toast("PANIC");
}

const char NAMECH[] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_/!{}|~";
// ---------------------------------------------------------------- knob maps (the same table drives the footer and the encoders)
struct KnobDef { const char* label; char txt[8]; uint8_t pos, used; };
void K(KnobDef& k, const char* l, int v, int pos, int used = 1) { k.label = l; num(k.txt, v); k.pos = (uint8_t)clampi(pos, 0, 127); k.used = (uint8_t)used; }
void Kx(KnobDef& k, const char* l, const char* t, int pos, int used = 1) { k.label = l; cpy(k.txt, t, 8); k.pos = (uint8_t)clampi(pos, 0, 127); k.used = (uint8_t)used; }
__attribute__((noinline)) void knobsFor(KnobDef kd[4]) {
  for (int i = 0; i < 4; i++) { kd[i].label = ""; kd[i].txt[0] = 0; kd[i].pos = 0; kd[i].used = 0; }
  const unsigned t = g.track; struct groove_view v; groove_get_view(t, 0, &v); uint8_t patch[156]; struct groove_fm_controls fc; memset(&fc, 0, sizeof fc); bool fm = v.type == GROOVE_DX7 && groove_fm_copy(t, patch, &fc) == 0;
  switch (g.page) {
    case P_HOME: for (int i = 0; i < 4; i++) { const char* lb = ""; seq_param_read(t, (unsigned)i, kd[i].txt, kd[i].pos, lb); kd[i].label = lb; kd[i].used = 1; } break;
    case P_FXM: { fx_fill(snap, t, g.bank); static const char* const L[6][3] = {{"TIME", "MIX", ""}, {"TIME", "FDBK", "MIX"}, {"DEPTH", "MIX", ""}, {"DRIVE", "", ""}, {"AMOUNT", "", ""}, {"CUTOFF", "RES", "LEVEL"}};
      for (int k = 0; k < 3; k++) if (L[g.fxSel][k][0]) { kd[k].label = L[g.fxSel][k]; cpy(kd[k].txt, snap.fxtxt[g.fxSel][k], 8); kd[k].pos = snap.fxv[g.fxSel][k]; kd[k].used = 1; }
      kd[3].label = "EFFECT"; cpy(kd[3].txt, FX_NAMES[g.fxSel], 8); kd[3].pos = (uint8_t)(g.fxSel * 127 / 5); kd[3].used = 1; break; }
    case P_MIX: { uint8_t sd[2]; groove_sends_get(t, sd); K(kd[0], "VOL", v.volume, v.volume); K(kd[1], "REV", sd[0], sd[0] * 127 / 15); K(kd[2], "DLY", sd[1], sd[1] * 127 / 15); K(kd[3], "TRACK", (int)hw_to_disp(t) + 1, hw_to_disp(t) * 127 / 7); break; }
    case P_SAVE: K(kd[0], "LOOPS", g.loops, g.loops * 127 / 8); K(kd[1], "SLOT", g.svRow, g.svRow ? (g.svRow - 1) * 127 / 15 : 0, g.svRow != 0); break;
    case P_GEN: { static const char* const L[3][4] = {{"DENS", "CHAOS", "HOLD", "SYNC"}, {"LEAP", "VOICE", "PROG", "OCT"}, {"HUMAN", "SWING", "BANK", ""}};
      const int v[3][4] = {{g.dens, g.chaos, g.hold, g.sync}, {g.leap, g.voice, g.fam * 127 / 4, 64 + g.oct * 20}, {g.human, (int)groove_sequence_setting(0) * 127 / 50, g.len > 1 ? g.bank * 127 / (g.len - 1) : 0, 0}};
      for (int i = 0; i < 4; i++) { K(kd[i], L[g.genSet][i], 0, v[g.genSet][i]); pct(kd[i].txt, v[g.genSet][i]); }
      if (g.genSet == 1) { static const char* const F[5] = {"POP", "MODAL", "CIRCLE", "JAZZ", "ANY"}; cpy(kd[2].txt, F[g.fam % 5], 8); num(kd[3].txt, g.oct); }
      if (g.genSet == 2) { num(kd[1].txt, (int)groove_sequence_setting(0)); strcat(kd[1].txt, "%"); kd[2].txt[0] = (char)('A' + g.bank); kd[2].txt[1] = 0; kd[2].used = g.len > 1; kd[3].used = 0; }
      break; }
    case P_SCL: Kx(kd[0], "ROOT", NOTE[g.scale % 12], (g.scale % 12) * 127 / 11); Kx(kd[1], "SCALE", SCALE_NAME[g.scale / 12 % 8], (g.scale / 12 % 8) * 127 / 7); K(kd[3], "OCT", g.oct, 64 + g.oct * 20); break;
    case P_ENV: for (int i = 0; i < 4; i++) { static const char* const L[4] = {"ATTACK", "DECAY", "SUSTN", "RELEAS"}; K(kd[i], L[i], fc.envelope[i], fc.envelope[i], fm); } break;
    case P_LFO: { uint8_t lv[4]; groove_lfo_copy(t, lv); static const char* const L[4] = {"RATE", "DEPTH", "TARGET", "WAVE"}; for (int i = 0; i < 4; i++) { K(kd[i], L[i], lv[i], lv[i] * 127 / 100); } break; }
    case P_EDIT: { const unsigned a = g.bank * NS + g.edStep; struct groove_step c; groove_sequence_read(t, a, &c, 1); const bool dr = seq_is_drum(t), on = c.velocity != 0; const unsigned dw = c.drums;
      static const char* const LA[2][4] = {{"NOTE", "NUDGE", "VEL", "GATE"}, {"PROB", "CHORD", "TRANSP", "VELSCL"}};
      for (int i = 0; i < 4; i++) { kd[i].label = LA[g.edSet][i]; kd[i].used = 1; }
      if (!g.edSet) {
        if (dr) { kd[0].label = "PAD"; { const char* pl = groove_pad_label(t, g.pad[t]); cpy(kd[0].txt, pl ? pl : "", 8); } kd[0].pos = (uint8_t)(g.pad[t] * 127 / 15); } else { const int n = on ? c.note : g.lastNote[t]; noteTxt(kd[0].txt, n); kd[0].pos = (uint8_t)n; }
        cpy(kd[1].txt, "< >", 8); kd[1].pos = 64; kd[1].used = on; num(kd[2].txt, c.velocity); kd[2].pos = c.velocity; kd[2].used = on;
        if (dr) { const unsigned p = groove_step_setting(t, a, 2); kd[3].label = "PROB"; probTxt(kd[3].txt, p); kd[3].pos = (uint8_t)(p * 127 / 7); }
        else { const unsigned v = (dw >> 5) & 15; num(kd[3].txt, v ? v == 15 ? 100 : (int)(v * 100 + 8) / 16 : 50); strcat(kd[3].txt, "%"); kd[3].pos = (uint8_t)(v * 127 / 15); }
        kd[3].used = on;
      } else {
        const unsigned p = groove_step_setting(t, a, 2); probTxt(kd[0].txt, p); kd[0].pos = (uint8_t)(p * 127 / 7); kd[0].used = on;
        if (!dr) { cpy(kd[1].txt, seq_chord_name(dw & 31), 8); kd[1].pos = (uint8_t)((dw & 31) * 127 / 16); kd[1].used = on; } else kd[1].used = 0;
        cpy(kd[2].txt, "BANK", 8); kd[2].pos = 64; kd[2].used = !dr; cpy(kd[3].txt, "BANK", 8); kd[3].pos = 64;
      }
      break; }
    case P_ARP: { static const char* const L[4] = {"RATE", "DIR", "RANGE", "GATE"}; for (int i = 0; i < 4; i++) { int a = (int)groove_arp_setting(t, (unsigned)i); K(kd[i], L[i], a, a * 127 / 3); } break; }
    case P_GLO: if (!g.glo) { { const int tp = groove_tempo_current() ? (int)groove_tempo_current() : v.tempo; K(kd[0], "TEMPO", tp, tp - 30); } K(kd[1], "SWING", (int)groove_sequence_setting(0), (int)groove_sequence_setting(0) * 127 / 50); Kx(kd[2], "CLOCK", groove_clock_mode() ? "MIDI" : "INT", groove_clock_mode() * 127); K(kd[3], "METRO", (int)groove_sequence_setting(1), (int)groove_sequence_setting(1) * 63); } else if (g.glo == 1) {
      K(kd[0], "LENGTH", g.len * NS, g.len * 127 / 4); Kx(kd[1], "COUNTIN", groove_sequence_setting(2) ? "1 BAR" : "OFF", groove_sequence_setting(2) * 127);
      static const char* const R[3] = {"NORM", "PLAY", "OFF"}; Kx(kd[2], "ROLE", R[groove_track_role(t) % 3], groove_track_role(t) * 63);
      K(kd[3], "IN CH", (int)groove_midi_input_channel(t) + 1, groove_midi_input_channel(t) * 127 / 15);
    }
    break;
    default: break;
  }
}
// Encoder ballistics: slow turns = 1 step per click.  A fast spin (about 10 clicks with < 70 ms gaps) ramps to 4x, then 8x, then 16x.
// SELECT / PRESETS / ALGORITHM stop at 2x so tracks and presets are never skipped; knobs that pick from short lists (key, slot, note, track) never accelerate.
uint32_t encAt[7]; uint8_t encRun[7];
int accel(unsigned e, int d, uint32_t ms) {
  encRun[e] = ms - encAt[e] < 70 ? (uint8_t)clampi(encRun[e] + (d < 0 ? -d : d), 0, 60) : 0; encAt[e] = ms;
  const bool knob = e >= E_K1 && e <= E_K4; const int cap = !knob ? 2 : (g.page == P_SCL || g.page == P_SAVE || g.page == P_EDIT || (g.page == P_MIX && e == E_K4)) ? 1 : 16;
  const int r = encRun[e], m = r < 10 ? 1 : r < 20 ? 4 : r < 30 ? 8 : 16; return d * (m < cap ? m : cap);
}
// Mixer meters on a dB scale: 80 px = -48..0 dBFS, 10 px per 6 dB (one halving of the level), so normal mixes sit in the middle of the strip.
uint8_t pkPx[NT]; uint32_t pkAt[NT];
uint8_t meterPx(unsigned l) { if (!l) return 0; int h = 0; while (l < 64 && h < 8) { l <<= 1; h++; } return (uint8_t)clampi(80 - h * 10 - (int)(127 - l) * 10 / 63, 0, 80); }
void turnKnob(unsigned i, int d) {
  if (g.intro || !d) return; const unsigned t = g.track;
  switch (g.page) {
    case P_HOME: {
      seq_param_edit(t, i, d);
      if (g.rec && playing()) { int ps = playStep(); if (ps >= 0) { KnobDef kd[4]; knobsFor(kd); { g.lockKnob = (uint8_t)i; if (!seq_record_lock(t, g.bank, (unsigned)ps, i, kd[i].pos)) toast("NO AUTO"); } } }
      break; }
    case P_FXM: if (i == 3) fx_select(d); else fx_knob(i, d, t, g.rec && playing(), g.bank, playStep()); break;
    case P_MIX: if (i == 0) groove_control_edit(t, 0, d, 0); else if (i == 1) groove_sends_edit(t, 0, d); else if (i == 2) groove_sends_edit(t, 1, d); else g.track = (uint8_t)disp_to_hw((hw_to_disp(g.track) + (unsigned)(d % 8 + 8)) % 8); break;
    case P_SAVE: if (g.nmOn) { if (i == 0) { const int n = (int)sizeof NAMECH - 1, c = (int)(strchr(NAMECH, g.nm[g.nmCur]) - NAMECH); g.nm[g.nmCur] = NAMECH[((c + d) % n + n) % n]; } else if (i == 1) g.nmCur = (uint8_t)clampi(g.nmCur + d, 0, 5); break; }
      if (i == 0) g.loops = (uint8_t)clampi(g.loops + d, 1, 8); else if (i == 1 && g.svRow) g.svRow = (uint8_t)clampi(g.svRow + d * 4, 1, 16); break;
    case P_GEN: {
      auto bump = [&](uint8_t& v) { v = (uint8_t)clampi(v + d, 0, 127); g.genDirty = 1; g.genAt = fm1_millis(); };            // the pattern re-renders live 0.25 s after the last turn
      if (g.genSet == 0) { if (i == 0) bump(g.dens); else if (i == 1) bump(g.chaos); else if (i == 2) bump(g.hold); else bump(g.sync); }
      else if (g.genSet == 1) { if (i == 0) bump(g.leap); else if (i == 1) bump(g.voice); else if (i == 2) { g.fam = (uint8_t)clampi(g.fam + (d > 0 ? 1 : -1), 0, 4); toast("FAMILY"); } else { g.oct = (int8_t)clampi(g.oct + d, -2, 2); g.genDirty = 1; g.genAt = fm1_millis(); } }
      else { if (i == 0) bump(g.human); else if (i == 1) groove_sequence_setting_edit(0, d); else if (i == 2) { if (g.len > 1) g.bank = (uint8_t)clampi(g.bank + d, 0, g.len - 1); } }   // (NEW PRG knob removed: every variation key already pulls a new progression)
      break; }
    case P_SCL: if (i == 0) setScale(g.scale / 12 * 12 + ((g.scale % 12 + d) % 12 + 12) % 12); else if (i == 1) setScale((((g.scale / 12 + d) % 8 + 8) % 8) * 12 + g.scale % 12); else if (i == 3) g.oct = (int8_t)clampi(g.oct + d, -2, 2); break;
    case P_ENV: groove_adsr_edit(t, i, d); break;
    case P_LFO: groove_lfo_edit(t, i, d); break;
    case P_EDIT: { const unsigned a = g.bank * NS + g.edStep, span = (unsigned)g.len * NS; struct groove_step c; groove_sequence_read(t, a, &c, 1); const bool dr = seq_is_drum(t), on = c.velocity != 0;
      if (!g.edSet) {
        if (i == 0) { if (dr) g.pad[t] = (uint8_t)clampi(g.pad[t] + d, 0, (int)groove_pad_count(t) - 1); else { const int n = seq_edit_pitch(t, a, d); if (n >= 0) preview(t, (unsigned)n); } }
        else if (i == 1 && on) { const int dd = d > 0 ? 1 : -1; seq_edit_nudge(t, a, dd, span); const unsigned b = (a + span + (unsigned)dd) % span; g.bank = (uint8_t)(b / NS); g.edStep = (uint8_t)(b % NS); }
        else if (i == 2 && on) groove_step_setting_edit(t, a, 0, d);
        else if (i == 3 && on) groove_step_setting_edit(t, a, dr ? 2 : 1, d);
      } else if (i == 0) { if (on) groove_step_setting_edit(t, a, 2, d); }
      else if (i == 1) { if (on && !dr) groove_step_setting_edit(t, a, 3, d); }
      else if (i == 2) { if (!dr) seq_edit_bank(t, g.bank, d, 0); }
      else seq_edit_bank(t, g.bank, 0, d * 4);
      break; }
    case P_ARP: groove_arp_edit(t, i, d); break;
    case P_GLO: if (!g.glo) { if (i == 0) groove_tempo_edit(d); else if (i == 1) groove_sequence_setting_edit(0, d); else if (i == 2) groove_clock_set(d > 0 ? GROOVE_CLOCK_MIDI : GROOVE_CLOCK_INTERNAL); else groove_sequence_setting_edit(1, d); }
      else if (g.glo == 1) { if (i == 0) { seq_set_len((unsigned)g.len + (d > 0 ? 1 : -1)); toast(g.len == 1 ? "16 STEPS" : "LOOP SET"); } else if (i == 1) groove_sequence_setting_edit(2, d); else if (groove_settings_track(t, i - 2, d)) toast("NOT AVAILABLE"); }
      break;
    default: break;
  }
}

// ---------------------------------------------------------------- white keys 01..16 (step punch, or page action) and black keys (live notes)
// ---------------------------------------------------------------- SAVE page: row 0 = EXPORT STEMS TO DAW, rows 1..16 = the SDK's 16 project slots
bool ask(uint8_t what, const char* msg, uint32_t ms) { if (g.svConfirm == what && ms - g.svConfirmAt < 3500) { g.svConfirm = 0; return true; } g.svConfirm = what; g.svConfirmAt = ms; toast(msg); return false; }
// Project names: 6 characters, K1 = character, K2 = cursor, SAVE = write, PLAY = cancel.  { } | ~ are drawn as note / heart / star / pad icons.
void nameCommit() { for (unsigned i = 0; i < 12; i++) groove_project_rename(i, i < 6 ? g.nm[i] : ' '); const int r = groove_project_save_slot(g.svRow - 1u); g.nmOn = 0; refreshSlots(); toast(r == 0 ? "SAVED" : "FAILED"); }
__attribute__((noinline)) void saveKey(unsigned n) {
  const uint32_t ms = fm1_millis(); if (g.svRow == 0) {                                                                 // the EXPORT TO DAW row
    if (g.xs == X_IDLE) { if (n == 1) g.xs = X_ASK; } else if (g.xs == X_ASK) { if (n == 1) exBegin(); else if (n == 2) g.xs = X_IDLE; else if (n == 3) g.tail ^= 1; } else if (g.xs == X_DONE) g.xs = X_IDLE; else if (n == 2) exEnd(false);
    return; }
  const unsigned slot = g.svRow - 1; bool used = g.svUsed[slot];
  if (n == 1) { char b[13]; groove_project_name(b); for (int i = 0; i < 6; i++) g.nm[i] = strchr(NAMECH, b[i]) && b[i] ? b[i] : ' '; g.nm[6] = 0; g.nmOn = 1; g.nmCur = 0; }   // key 1 opens the naming screen; SAVE writes
  else if (n == 2) { if (!used) { toast("SLOT IS EMPTY"); return; } int r = groove_project_load_slot(slot); memset(g.cur, 255, NT); g.bank = 0; toast(r != 0 ? "FAILED" : "LOADED"); }
  else if (n == 4) { for (unsigned i = 0; i < GROOVE_PROJECT_SLOTS; i++) if (!g.svUsed[i]) { g.svRow = (uint8_t)(i + 1); toast("FREE SLOT"); return; } toast("SLOTS FULL"); }
}

void newProgression() { seq_new_prog(); for (unsigned t = 0; t < 7; t++) if (seq_cls(t) == 0 && (t == g.track || seq_has_steps(t))) { seq_style_apply(t, g.bank, g.sty[t], g.info[t]); g.styValid[t] = 1; } g.genFlash = 12; toast("NEW PROG"); }
// Every variation key is a "lottery pull": a new chord progression AND a new pattern (another seed inside the same complexity tier of the ALGORITHM knob).
void newVariation() { g.genSeed = g.genSeed * 1664525u + 1013904223u; const unsigned n = seq_style_count(g.track), r = g.genSeed >> 16; g.sty[g.track] = (uint16_t)(n == 128 ? (g.sty[g.track] & 96u) | (r & 31u) : r % n); newProgression(); if (seq_cls(g.track)) runStyle(false); }
bool stepRecKey(unsigned note) {                                              // REC while stopped: each key writes the cursor step and advances
  if (!g.stepRec || playing()) return false;
  seq_step_write(g.track, g.bank, g.recStep, note); g.undone = 0;
  if (++g.recStep >= NS) { g.recStep = 0; g.stepRec = 0; toast("DONE"); } return true;
}
const uint8_t KIT[11] = {0, 10, 9, 6, 1, 5, 2, 3, 4, 7, 8};                 // drum keys: kick, closed hat, open hat, clap, snare, rim, toms, cowbell, cymbal
uint8_t liveOf[27], liveTr[27];                                              // note + 1 and MIDI channel of every key that is sounding, so its note-off always matches
uint8_t hPos[27], hNote[27], hTrk[27]; uint32_t hAt[27], hDue[27], hDur[27]; bool hRec[27];                 // live-record bookkeeping: where the engine stamped each key and how long it was held
void liveOff(unsigned key) { if (liveOf[key]) { post((uint8_t)(0x80 | liveTr[key]), (uint8_t)(liveOf[key] - 1), 0, 3); liveOf[key] = 0; if (hRec[key]) { hRec[key] = false; hDur[key] = fm1_millis() - hAt[key]; hDue[key] = fm1_millis() + 120; } } }   // the engine writes the note a moment later: fix its length then
void holdTick(uint32_t ms) { for (unsigned k = 0; k < 27; k++) if (hDue[k] && ms >= hDue[k]) { hDue[k] = 0; struct groove_view v; groove_get_view(hTrk[k], 0, &v); const unsigned bpm = groove_tempo_current() ? groove_tempo_current() : v.tempo; seq_hold(hTrk[k], hPos[k], hNote[k], hDur[k], 15000u / (bpm ? bpm : 120)); } }
bool edLive() { return g.page == P_EDIT && !g.edView; }   // piano roll (1st EDIT press): every key plays chromatically; REC + PLAY records.  EDIT again = step mode (punch keys + command row)
void liveOn(unsigned key, unsigned note) {
  liveOff(key); liveOf[key] = (uint8_t)(note + 1); liveTr[key] = inCh(g.track); const bool rec = g.rec && edLive() && playing(); unsigned pos = 0;
  if (rec) { struct groove_view pv; groove_get_view(g.track, 0, &pv); const unsigned len = groove_sequence_length(g.track); pos = len ? pv.play_step % len : 0; seq_step_write(g.track, pos / NS, pos % NS, note); g.undone = 0; }   // the key is written on the playhead step
  post((uint8_t)(0x90 | liveTr[key]), (uint8_t)note, 100, 3); if (rec && !seq_is_drum(g.track)) { hRec[key] = true; hAt[key] = fm1_millis(); hNote[key] = (uint8_t)note; hPos[key] = (uint8_t)pos; hTrk[key] = g.track; hDue[key] = 0; } }
unsigned noteOf(unsigned key, unsigned slot) { return groove_source_type(g.track) == GROOVE_808 ? groove_drum_note(KIT[slot % 11]) : (unsigned)clampi((int)groove_key_note(g.track, key, 0) + 12 * g.kOct, 0, 127); }
void playKey(unsigned key, unsigned slot) { const unsigned note = noteOf(key, slot); if (g.page == P_EDIT && stepRecKey(note)) return; liveOn(key, note); }   // live play; REC records it (engine) or step-records it
void whiteKey(unsigned n) {                                                  // n = 1..16.  White AND black keys play notes; white keys only change the generator while its window is open
  switch (g.page) {
    case P_HOME: newVariation(); return;                                   // HOME: every key (white or black) is a new algorithm
    case P_GEN: newVariation(); return;     // the SEQ page IS the algorithm window: keys 1-15 = new variation, key 16 = new chord progression
    case P_PRE: liveOn(WHITE_IDX[n - 1], noteOf(WHITE_IDX[n - 1], n - 1)); return;      // preview the sound on the whole keybed
    case P_MIX: if (n <= 8) { const unsigned hw = disp_to_hw(n - 1); if (g.track == hw) groove_mix_toggle(hw, 0); else g.track = (uint8_t)hw; } else groove_mix_toggle(disp_to_hw(n - 9), 1); return;   // keys 1-8: pick, 2nd tap = mute.  keys 9-16: solo for tracks 1-8
    case P_SCL: if (n <= 12) setScale(g.scale / 12 * 12 + (int)n - 1); return;
    case P_ARP: if (n == 16) { groove_arp_set(g.track, !groove_arp_enabled(g.track)); toast(groove_arp_enabled(g.track) ? "ARP ON" : "ARP OFF"); } return;
    case P_EDIT: if (edLive()) { playKey(WHITE_IDX[n - 1], n - 1); return; } g.edStep = (uint8_t)(n - 1); seq_punch(g.track, g.bank, n - 1); g.undone = 0; return;                  // punch + select: the cursor follows the key
    case P_FXM: if (n == 16) { groove_effects_edit(4, 1); toast("DLY SYNC"); } else if (n <= 6) g.fxSel = (uint8_t)(n - 1); return;
    case P_SAVE: saveKey(n); return;
    default: return;
  }
}
void editCmd(unsigned i) {                                                   // EDIT page: the 11 black keys are a labelled command row
  const unsigned t = g.track, a = g.bank * NS + g.edStep, ms = fm1_millis(); g.undone = 0;
  switch (i) {
    case 0: g.edSet ^= 1; toast(g.edSet ? "SET B" : "SET A"); break;
    case 1: toast(groove_edit_copy(t, a, 0) == 0 ? "COPIED" : "FAILED"); break;
    case 2: toast(groove_edit_paste(t, a, 0) == 0 ? "PASTED" : "COPY FIRST"); break;
    case 3: (void)groove_edit_clear(t, a, 0); toast("CLEARED"); break;
    case 4: { const unsigned md = groove_midi_setting(t, 0); groove_settings_midi(t, 0, md ? -(int)md : 1); toast(md ? "OUT: LOCAL" : "OUT: BOTH"); break; }          // LOCAL <-> BOTH only; MIDI-only (no local sound) is set on GLO > MIDI OUT
    default: break;
  }
}
__attribute__((noinline)) void navGo(unsigned i) {                                                     // HOME overlay quick-launch
  g.intro = false;
  switch (i) { case 0: g.page = P_HOME; break; case 1: g.page = P_MIX; break; case 2: g.page = P_EDIT; g.edView = 0; break; case 3: g.page = P_EDIT; g.edView = 1; break; case 4: g.page = P_GLO; g.glo = 0; break; case 5: g.page = P_GEN; break; case 6: g.page = P_FXM; break;
    case 8: if (!ask(0x70, "AGAIN: CLEAR", fm1_millis())) { g.intro = true; break; } toast(seq_clear_project() ? "CLEARED" : "FAILED"); g.page = P_HOME; break;   // 2nd press within 3.5 s
    default: g.page = P_SAVE; g.svRow = 0; g.svConfirm = 0; refreshSlots(); break; }
}
void navKey(unsigned n) { if (n < 9) navGo(n); else if (n == 15) navGo(g.navSel); else g.intro = false; }   // keys 1-8 jump, key 16 = enter the highlighted item
void blackKey(unsigned idx, bool on) {                                       // black keys always play (EDIT: they are the labelled command row)
  if (!on) { liveOff(BLACK_IDX[idx]); return; }
  if (g.page == P_HOME) { newVariation(); return; }
  if (g.page == P_EDIT && !edLive()) { editCmd(idx); return; }
  playKey(BLACK_IDX[idx], idx);
}

// ---------------------------------------------------------------- buttons
void pressButton(unsigned b) {
  if (g.intro && b != B_PLAY && b != B_OCT_DOWN && b != B_OCT_UP) g.intro = false;           // a page button closes the HOME overlay and still does its job
  switch (b) {
    case B_FX: if (g.intro) g.intro = false; else g.page = g.page == P_FXM ? (uint8_t)P_MIX : g.page == P_MIX ? (uint8_t)P_HOME : (uint8_t)P_FXM; break;   // 1st master FX, 2nd mixer + sends, 3rd back
    case B_SCL: toggle(P_SCL); break; case B_ENV: toggle(P_ENV); break; case B_LFO: toggle(P_LFO); break; case B_EDIT: if (g.page == P_EDIT) g.edView ^= 1; else { g.page = P_EDIT; g.edView = 0; } break; case B_GLO: if (g.page == P_GLO) g.glo = (g.glo + 1) & 1; else g.page = P_GLO; break; case B_ARP: toggle(P_ARP); break;
    case B_SEQ: if (g.page == P_GEN) g.genSet = (uint8_t)((g.genSet + 1) % 3); else g.page = P_GEN; break;     // SEQ again = next knob set
    case B_SAVE: if (g.page == P_SAVE && g.nmOn) { nameCommit(); break; } g.nmOn = 0; if (g.intro) { g.intro = false; break; } if (g.page == P_SAVE) { g.page = P_HOME; break; } g.page = P_SAVE; g.svRow = 0; g.svConfirm = 0; refreshSlots(); break;   // SAVE opens the list; nothing is written until you press a key
    case B_PLAY: if (g.nmOn) { g.nmOn = 0; toast("NOT SAVED"); break; } if (g.xs >= X_LEAD && g.xs != X_DONE) { exEnd(false); break; }        // PLAY cancels a running export
      if (!playing() && g.stepRec) g.rec = 1;                                       // REC armed while stopped: PLAY starts recording (notes in the piano roll, knob automation everywhere)
      g.stepRec = 0; if (playing()) post(0xFC, 0, 0, 1); else post(0xFA, 0, 0, 1); break;
    case B_OCT_DOWN: if (edLive()) { g.kOct = (int8_t)clampi(g.kOct - 1, -3, 3); toast("OCT-"); break; } if (seq_undo() == 0) toast("UNDO"); else toast("NO UNDO"); break;
    case B_OCT_UP: if (edLive()) { g.kOct = (int8_t)clampi(g.kOct + 1, -3, 3); toast("OCT+"); break; } if (seq_redo() == 0) toast("REDO"); else toast("NO REDO"); break;
    default: break;
  }
}

// ---------------------------------------------------------------- snapshot for the renderer
void fillSnap(uint32_t ms) {
  Snap& s = snap; memset(&s, 0, sizeof s); s.tick = g.frame; s.boot = g.boot; s.page = g.page; s.track = (uint8_t)hw_to_disp(g.track); s.bank = g.bank; s.rec = g.rec; s.stepRec = g.stepRec; s.master = (uint8_t)(groove_master_state() >> 16 & 127); s.undoN = !g.undone; s.redoN = g.undone;
  struct groove_view v; groove_get_view(g.track, 0, &v); s.playing = v.playing; s.bpm = groove_tempo_current() ? (uint16_t)groove_tempo_current() : v.tempo; s.playStep = (int8_t)playStep(); s.heldStep = 255;
  for (unsigned p = 0; p < NT; p++) { const unsigned t = DISP[p]; s.hw[p] = (uint8_t)t; struct groove_view tv; groove_get_view(t, 0, &tv); s.src[p] = tv.type; s.mute[p] = tv.muted; s.solo[p] = tv.solo; s.vol[p] = tv.volume; s.level[p] = meterPx(tv.audible ? tv.level : 0); if (s.level[p] >= pkPx[p]) { pkPx[p] = s.level[p]; pkAt[p] = g.frame; } else if (g.frame - pkAt[p] > 9) pkPx[p] = (uint8_t)(pkPx[p] > 3 ? pkPx[p] - (pkPx[p] >> 3) - 1 : 0); s.peak[p] = pkPx[p]; s.active[p] = tv.level > 3; uint8_t sd[2]; groove_sends_get(t, sd); s.send1[p] = (uint8_t)(sd[0] * 127 / 15); s.send2[p] = (uint8_t)(sd[1] * 127 / 15); cpy(s.trackName[p], TRK_NAME[t], 8);
    struct groove_step c[NS]; groove_sequence_read(t, g.bank * NS, c, NS); s.has[p] = 0; for (int i = 0; i < NS; i++) if (c[i].velocity || c[i].drums) { s.has[p] = 1; break; } }
  seq_read_bank(g.track, g.bank, s); for (int i = 0; i < NS; i++) s.laneVal[i] = 0;
  const unsigned dp = hw_to_disp(g.track); char tl[16] = "T0"; tl[2] = (char)('1' + dp); tl[3] = ' '; tl[4] = 0; strcat(tl, TRK_NAME[g.track]); strcat(tl, " "); strcat(tl, SRC_NAME[v.type < 6 ? v.type : 0]); cpy(s.trackLong, tl, 16); seq_patch_name(g.track, s.patch);
  KnobDef kd[4]; knobsFor(kd); for (int i = 0; i < 4; i++) { cpy(s.k[i].label, kd[i].label, 9); cpy(s.k[i].txt, kd[i].txt, 8); s.k[i].pos = kd[i].pos; s.k[i].used = kd[i].used; }
  cpy(s.selTag, "TRK", 8); cpy(s.selVal, s.trackLong, 12); cpy(s.laneName, s.k[g.lockKnob & 3].label, 10);
  s.styValid = g.styValid[g.track]; if (s.styValid) { cpy(s.styName, g.info[g.track].name, 26); cpy(s.prog, g.info[g.track].prog, 72); }
  fx_fill(s, g.track, g.bank);
  if (g.page == P_PRE) seq_preset_page(g.track, s);
  s.genFlash = g.genFlash;
  static const char* const T[P_COUNT] = {"", "", "", "SCALE", "ENVELOPE", "LFO", "", "", "", "ARPEGGIATOR", "", ""}; static const char* const GT[4] = {"GLOBAL", "PROJECT", "MIDI OUT", "MIDI"};
  cpy(s.gtitle, g.page == P_GLO ? GT[g.glo] : T[g.page], 24); for (int i = 0; i < 4; i++) { cpy(s.grow[i].label, kd[i].label, 10); cpy(s.grow[i].txt, kd[i].txt, 9); s.grow[i].pos = kd[i].pos; }
  s.trackEmpty = !s.has[dp];
  cpy(s.hint, g.page == P_HOME ? (g.stepRec ? "STEP REC" : "") : "", 41);
  if (g.stepRec && !playing()) { s.heldStep = g.recStep; cpy(s.heldInfo, "STEP REC", 34); }
  s.nmOn = g.nmOn; s.nmCur = g.nmCur; memcpy(s.nm, g.nm, 7); s.navSel = g.navSel; s.len = g.len; s.engLen = (uint8_t)groove_sequence_length(g.track); s.glo = g.glo; s.edView = g.edView; s.edSet = g.edSet; s.edStep = g.edStep; s.ext = (uint8_t)groove_clock_mode(); s.pencil = seq_is_drum(g.track) ? g.pad[g.track] : g.lastNote[g.track];
  s.panicPct = g.homeDown && g.homeFired == 1 ? (uint8_t)clampi((int)((ms - g.homeAt - 400) * 100 / 1600), 0, 100) : 0; if (g.page == P_EDIT || g.page == P_HOME) seq_edit_fill(g.track, g.bank, s);
  s.lk = g.lockKnob; s.genSet = g.genSet; s.mOnly = groove_midi_setting(g.track, 0) == 2 || !groove_midi_setting(0, 3);   // MIDI-only track, or LOCAL off: keys would be silent
  { const uint8_t v[12] = {g.dens, g.chaos, g.hold, g.sync, g.leap, g.voice, (uint8_t)(g.fam * 127 / 4), (uint8_t)clampi(64 + g.oct * 20, 0, 127), g.human, (uint8_t)(groove_sequence_setting(0) * 127 / 50), (uint8_t)(g.len > 1 ? g.bank * 127 / (g.len - 1) : 0), 0}; memcpy(s.gv, v, 12); }
  if (g.page == P_HOME) { struct groove_sequence_options lo; groove_sequence_options_copy(&lo); const int lid = seq_lock_id(g.track, g.lockKnob); for (unsigned k = 0; k < GROOVE_LOCKS; k++) if (lo.lock[k].track == g.track && (int)lo.lock[k].parameter == lid && lo.lock[k].step / NS == g.bank) s.laneVal[lo.lock[k].step % NS] = lo.lock[k].value; }
  s.intro = g.intro; s.svRow = g.svRow; s.exLoops = g.loops; s.usb = (uint8_t)(fm1_device_usb_connected() != 0);
  for (unsigned i = 0; i < 16; i++) { s.svUsed[i] = g.svUsed[i]; memcpy(s.svName[i], g.svName[i], 13); }
  s.exState = g.xs; s.exPass = g.xi; s.exPasses = g.xn; memcpy(s.exTr, g.xtr, sizeof s.exTr);
  if (g.xs == X_LEAD) s.exPct = (uint8_t)clampi((int)((ms - g.xt) * 100 / 4000), 0, 100); else if (g.xs == X_PLAY) s.exPct = g.xpct; else s.exPct = 0; s.exTail = g.tail;
  if (ms < g.toastUntil) { s.toastOn = 1; cpy(s.toast, g.toast, 34); } 
}
void paintOne() {                                                            // nonblocking: one 16-row band per call, like app/screen.c
  if (fm1_screen_pending() != 0) return;
  if (bandNo == 0) { fillSnap(fm1_millis()); }
  ui_paint_band(snap, band, (int)bandNo * 16, 16);
  if (fm1_screen_submit(0, bandNo * 16, FM1_SCREEN_WIDTH, 16, band, FM1_SCREEN_WIDTH * 16) == 0) bandNo = (bandNo + 1) % (FM1_SCREEN_HEIGHT / 16);
}
void leds() {
  for (unsigned b = 0; b < 14; b++) { bool on = false; switch (b) { case B_FX: on = g.page == P_FXM || g.page == P_MIX; break; case B_SCL: on = g.page == P_SCL; break; case B_ENV: on = g.page == P_ENV; break; case B_LFO: on = g.page == P_LFO; break; case B_EDIT: on = g.page == P_EDIT; break; case B_GLO: on = g.page == P_GLO; break; case B_HOME: on = g.page == P_HOME; break; case B_SAVE: on = g.page == P_SAVE; break; case B_ARP: on = g.page == P_ARP || groove_arp_enabled(g.track); break; case B_SEQ: on = g.page == P_GEN; break; case B_PLAY: on = snap.playing; break; case B_REC: on = g.rec && ((g.frame >> 3) & 1 || recHeld); break; default: break; } fm1_led_set(b, on); }
  for (unsigned n = 0; n < 16; n++) fm1_led_set(14 + WHITE_IDX[n], (g.page == P_HOME || g.page == P_GEN || g.page == P_EDIT) ? (snap.stepOn[n] || snap.playStep == (int)n || (g.page == P_EDIT && n == g.edStep && ((g.frame >> 3) & 1))) : (g.page == P_MIX && (n & 7) == hw_to_disp(g.track)));   // mixer: key N = track N (display order, so DRUMS = key 1), key N+8 mirrors it
}
}  // namespace

void toast(const char* m) { cpy(g.toast, m, 34); g.toastUntil = fm1_millis() + 1200; }
}  // namespace cb

// =====================================================================================================  stock entry points, replaced
using namespace cb;
void cb_screen_init() {
  fm1_controls_init(); for (unsigned i = 0; i < 41; i++) fm1_led_set(i, 0); fm1_screen_init();   // same order as stock app/screen.c: start the panel scanner first
  memset(&g, 0, sizeof g); memset(g.cur, 255, NT); g.cur[4] = 0; g.genSeed = 1; g.dens = 72; g.chaos = 30; g.human = 24; g.scale = 21; memset(g.lastNote, 60, sizeof g.lastNote); g.master = 108; g.heldStep = 255; g.loops = 4; g.len = 1; g.hold = 40; g.sync = 40; g.leap = 30; g.voice = 64; g.fam = 4; seq_init(); fx_init(); memset(&prev, 0, sizeof prev); memset(heldWhite, 0, sizeof heldWhite);
  for (unsigned t = 0; t < NT; t++) g.sty[t] = (uint16_t)(t * 37 % 9); seq_new_prog();      // track 8 (FX) starts on RISER BUILD; every track starts on the same chord progression
  g.track = (uint8_t)disp_to_hw(0);                                                    // boot on the first track in SELECT order (DRUMS); the sequencer is the first page
}
void cb_screen_tap(uint32_t t) { (void)groove_tempo_tap(t); }
void cb_screen_mmc(unsigned c) { unsigned tr = c == 1 || c == 9 ? 0xfc : c == 2 || c == 3 || c == 6 ? 0xfb : 0; if (tr) post((uint8_t)tr, 0, 0, 1); }
void cb_screen_control() {
  fm1_controls_read(&now); const uint32_t ms = fm1_millis(); g.frame = ms / 33;
  for (unsigned e = 0; e < 7; e++) if (now.encoders[e]) now.encoders[e] = (int16_t)accel(e, now.encoders[e], ms);
  (void)groove_master_update(now.knob); if (g.boot < BOOT_FRAMES && (g.frame != frameAt)) g.boot++;
  for (unsigned t = 0; t < NT; t++) if (groove_sequence_length(t) != (unsigned)g.len * NS) groove_sequence_length_set(t, (unsigned)g.len * NS);   // the loop is 16 steps unless the project settings say otherwise; the SDK restores the saved project after boot, so keep enforcing it
  const uint32_t pressed = now.buttons & ~prev.buttons, keyDown = now.keys & ~prev.keys, keyUp = ~now.keys & prev.keys;
  bool skipped = false; if (g.boot < BOOT_FRAMES && (pressed || keyDown)) { g.boot = BOOT_FRAMES; skipped = true; }   // any key skips the boot sequence
  if (g.boot >= BOOT_FRAMES && !skipped) {
    for (unsigned b = 0; b < 14; b++) if ((pressed >> b) & 1u && b != B_REC && b != B_HOME) pressButton(b);
    if (pressed & (1u << B_HOME)) { g.homeDown = true; g.homeFired = 0; g.homeAt = ms; }          // HOME: tap = matrix / menu, hold = menu on any page, hold 2 s = panic
    if (g.homeDown) {
      if ((now.buttons >> B_HOME) & 1u) {
        const uint32_t held = ms - g.homeAt;
        if (held > 400 && !g.homeFired) { g.homeFired = 1; g.intro = true; g.navSel = 0; }
        if (held > 2000 && g.homeFired == 1) { g.homeFired = 2; g.intro = false; panic(); }
      } else {
        g.homeDown = false;
        if (!g.homeFired) { if (g.intro) g.intro = false; else if (g.page != P_HOME) g.page = P_HOME; else { g.intro = true; g.navSel = 0; } }
      }
    }
    if (pressed & (1u << B_REC)) {
      if (g.intro) g.intro = false;
      else if (!playing()) { g.stepRec = !g.stepRec; g.recStep = 0; g.rec = 0; toast(g.stepRec ? "STEP REC" : "STEP REC OFF"); if (g.stepRec) g.page = P_EDIT; }   // REC while stopped = step record
      else { recWas = g.rec; g.rec = !g.rec; recDownAt = ms; recHeld = true; toast(g.rec ? g.page == P_EDIT ? "REC" : "REC" : "REC OFF"); }                                               // REC while playing = automation record
    }
    if ((~now.buttons & prev.buttons) & (1u << B_REC)) { recHeld = false; if (!recWas && ms - recDownAt > 450) g.rec = 0; }                // hold REC to punch automation, release to stop
    for (unsigned n = 0; n < 16; n++) { uint32_t m = 1u << WHITE_IDX[n]; if (keyDown & m) { if (g.intro) navKey(n); else whiteKey(n + 1); }
      if (keyUp & m) liveOff(WHITE_IDX[n]);
    }
    for (unsigned i = 0; i < 11; i++) { uint32_t m = 1u << BLACK_IDX[i]; if (keyDown & m) { if (g.intro) g.intro = false; else blackKey(i, true); } if (keyUp & m) blackKey(i, false); }
    if (now.encoders[E_SELECT]) { const int d = now.encoders[E_SELECT]; if (g.intro) g.navSel = (uint8_t)((g.navSel + d % 9 + 9) % 9); else if (g.page == P_FXM) fx_select(d);
      else if (g.page == P_EDIT) { const int span = g.len * NS, c = ((int)g.bank * NS + g.edStep + d % span + span) % span; g.bank = (uint8_t)(c / NS); g.edStep = (uint8_t)(c % NS); } else if (g.page == P_SAVE) g.svRow = (uint8_t)clampi(g.svRow + d, 0, 16); else g.track = (uint8_t)disp_to_hw((hw_to_disp(g.track) + (unsigned)(d % 8 + 8)) % 8); }
    if (now.encoders[E_ALGO] && !g.intro) { unsigned n = seq_style_count(g.track); g.sty[g.track] = (uint16_t)((g.sty[g.track] + now.encoders[E_ALGO] % (int)n + (int)n) % (int)n); runStyle(g.page != P_GEN); g.stepRec = 0; }
    if (now.encoders[E_PRESETS] && !g.intro) { if (g.page != P_PRE) seq_lib_reset(); seq_preset_rotate(g.track, now.encoders[E_PRESETS]); g.page = P_PRE; }
    for (unsigned k = 0; k < 4; k++) if (now.encoders[E_K1 + k]) turnKnob(k, now.encoders[E_K1 + k]);
    exportTick(ms); holdTick(ms); seq_kit_tick(); if (!(g.frame & 63)) seq_perc_check();
    if (!g.unm && g.frame > 150) { g.unm = 1; g.kit = seq_kit_guess(); if (!groove_midi_setting(0, 3)) { groove_settings_midi(0, 3, 1); toast("LOCAL IS ON"); }   // LOCAL off = the engine ignores the keys (the sequencer still plays)
      struct groove_view mv; for (unsigned t = 0; t < NT; t++) { groove_get_view(t, 0, &mv); if (mv.solo) groove_mix_toggle(t, 1); if (mv.muted) groove_mix_toggle(t, 0); } }   // every boot starts with every track audible
    if (g.page != P_GEN) g.genDirty = 0; else if (g.genDirty && ms - g.genAt > 250) { g.genDirty = 0; runStyle(false); }
    if (g.pvNote && ms > g.pvOffAt) { post((uint8_t)(0x80 | g.pvTrack), g.pvNote, 0, 3); g.pvNote = 0; }
    if (g.len > 1 && g.page == P_HOME && playing()) { struct groove_view pv; groove_get_view(g.track, 0, &pv); if (pv.play_step / NS < g.len) g.bank = (uint8_t)(pv.play_step / NS); }   // HOME follows the playhead through the banks
    const int ps = playStep(); if (ps != lastStep) { lastStep = ps; fx_step_tick(g.bank, ps); }
  }
  if (g.genFlash) g.genFlash--; prev = now; frameAt = g.frame;
  paintOne(); leds();
}
