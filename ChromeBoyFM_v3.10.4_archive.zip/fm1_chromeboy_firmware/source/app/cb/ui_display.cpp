// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM / M-VAVE FM1 - LCD renderer.  240x240 RGB565, painted in 16-row bands (like app/screen.c) so it
// fits the AC791N RAM budget and feeds fm1_screen_submit().  Pure code: draws from a cb::Snap, no SDK calls.
// Morning edition: blue sky + sparse clouds, pixel water, Greco-Roman marble columns, footer key-map on EVERY page.
#include "cb.h"
#include <string.h>

namespace cb {
#include "ui_font.inc"

const char* const FM_CATS[10] = {"LEAD", "E.PIANO", "BELL", "MALLET", "PLUCK", "BASS", "BRASS", "PAD", "ORGAN", "FX"};
const char* const FX_NAMES[6] = {"REVERB", "DELAY", "CHORUS", "OVERDRIVE", "COMPRESS", "FILTER"};
const char* const PAGE_TITLE[P_COUNT] = {"HOME", "MASTER FX RACK", "MIXER", "SCALE / KEY", "ENVELOPE", "LFO ROUTING", "PIANO ROLL", "GLOBAL", "SAVE", "ARPEGGIATOR", "SEQ", "PRESETS"};

namespace {
constexpr int W = 240, H = 240;
typedef uint32_t rgb;                                                   // 0xRRGGBB
inline uint16_t q565(rgb c) { return (uint16_t)(((c >> 8) & 0xF800) | ((c >> 5) & 0x07E0) | ((c >> 3) & 0x001F)); }
inline rgb lerp(rgb a, rgb b, int t) {                                  // t 0..255
  int r = (a >> 16 & 255) + (((int)(b >> 16 & 255) - (int)(a >> 16 & 255)) * t >> 8), g = (a >> 8 & 255) + (((int)(b >> 8 & 255) - (int)(a >> 8 & 255)) * t >> 8), bl = (a & 255) + (((int)(b & 255) - (int)(a & 255)) * t >> 8);
  return (rgb)(r << 16 | g << 8 | bl);
}
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
static int16_t SINT[256]; static bool sinInit = false;
inline int isin(int x) {                                                // 256-step circle, -32767..32767 (Bhaskara approximation, integer only)
  if (!sinInit) { for (int i = 0; i < 256; i++) { int p = i < 128 ? i : i - 128; long num = 16L * p * (128 - p), den = 5L * 128 * 128 - 4L * p * (128 - p); int v = (int)(32767L * num / den); SINT[i] = (int16_t)(i < 128 ? v : -v); } sinInit = true; }
  return SINT[x & 255];
}
inline uint32_t hash32(uint32_t n) { n = (n ^ 61u) ^ (n >> 16); n += n << 3; n ^= n >> 4; n *= 0x27d4eb2du; n ^= n >> 15; return n; }

char* putn(char* o, int v) { if (v >= 100) *o++ = (char)('0' + v / 100); if (v >= 10) *o++ = (char)('0' + v / 10 % 10); *o++ = (char)('0' + v % 10); *o = 0; return o; }
const char NN[] = "C C#D D#E F F#G G#A A#B ";
char* putNote(char* o, int n) { const int m = n % 12; *o++ = NN[m * 2]; if (NN[m * 2 + 1] == '#') *o++ = '#'; int oc = n / 12 - 1; if (oc < 0) { *o++ = '-'; oc = 1; } *o++ = (char)('0' + oc); *o = 0; return o; }
const bool BLK[12] = {false, true, false, true, false, false, true, false, true, false, true, false};

const rgb C_BG = 0x060818, C_ACC = 0x8ff0e6, C_ACCD = 0x2f8f8a, C_GRN = 0x7cf8a0, C_RED = 0xff5b6b, C_TXT = 0xcfe9e4, C_DIM = 0x7d8c8a, C_DIM2 = 0x44525a, C_WHT = 0xffffff,
          C_PNK = 0xff4fb4, C_CYN = 0x38f2ff, C_PUR = 0x7a3cff, C_YEL = 0xffe14a, C_VIO = 0xe05bb8;
const rgb KCOL[4] = {0x38f2ff, 0xff7ad9, 0xffe14a, 0x7cf8a0};
const rgb TRKCOL[8] = {0xffe07a, 0xffa07a, 0x7fd4ff, 0xc9fff8, 0x9dff6e, 0xb98cff, 0xe8c46a, 0xf4a95c};

struct Gfx {                                                            // clipped band canvas
  uint16_t* b; int y0, rows;
  void px(int x, int y, rgb c) { if ((unsigned)x < (unsigned)W && y >= y0 && y < y0 + rows) b[(y - y0) * W + x] = q565(c); }
  void blendPx(int x, int y, rgb c, int a) { if ((unsigned)x >= (unsigned)W || y < y0 || y >= y0 + rows) return; uint16_t d = b[(y - y0) * W + x]; rgb dc = ((d & 0xF800u) << 8) | ((d & 0x07E0u) << 5) | ((d & 0x1Fu) << 3); b[(y - y0) * W + x] = q565(lerp(dc, c, a)); }
  void rect(int x, int y, int w, int h, rgb c) { int xa = x < 0 ? 0 : x, xb = x + w > W ? W : x + w, ya = y < y0 ? y0 : y, yb = y + h > y0 + rows ? y0 + rows : y + h; uint16_t v = q565(c); for (int j = ya; j < yb; j++) for (int i = xa; i < xb; i++) b[(j - y0) * W + i] = v; }
  void blendRect(int x, int y, int w, int h, rgb c, int a) { int xa = x < 0 ? 0 : x, xb = x + w > W ? W : x + w, ya = y < y0 ? y0 : y, yb = y + h > y0 + rows ? y0 + rows : y + h; for (int j = ya; j < yb; j++) for (int i = xa; i < xb; i++) blendPx(i, j, c, a); }
  void hline(int x, int y, int w, rgb c) { rect(x, y, w, 1, c); }
  void vline(int x, int y, int h, rgb c) { rect(x, y, 1, h, c); }
  void frame(int x, int y, int w, int h, rgb c) { hline(x, y, w, c); hline(x, y + h - 1, w, c); vline(x, y, h, c); vline(x + w - 1, y, h, c); }
  void line(int x0, int y0_, int x1, int y1, rgb c) { int dx = x1 > x0 ? x1 - x0 : x0 - x1, sx = x0 < x1 ? 1 : -1, dy = -(y1 > y0_ ? y1 - y0_ : y0_ - y1), sy = y0_ < y1 ? 1 : -1, e = dx + dy; for (;;) { px(x0, y0_, c); if (x0 == x1 && y0_ == y1) break; int e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0_ += sy; } } }
  void glyph(int x, int y, char ch, rgb c) { if (y > y0 + rows - 1 || y + 8 <= y0) return; int code = (unsigned char)ch; if (code >= 97 && code <= 122) code -= 32; if (code < 32 || code > 126) code = 63; const uint8_t* g = FONT5X8[code > 96 ? code - 58 : code - 32]; for (int r = 0; r < 8; r++) for (int bt = 0; bt < 5; bt++) if (g[r] & (16 >> bt)) px(x + bt, y + r, c); }
  void text(int x, int y, const char* s, rgb c) { for (; *s; s++, x += 6) glyph(x, y, *s, c); }
  static int tw(const char* s) { return (int)strlen(s) * 6; }
  void textR(int xr, int y, const char* s, rgb c) { text(xr - tw(s), y, s, c); }
  void textC(int xc, int y, const char* s, rgb c) { text(xc - (tw(s) >> 1), y, s, c); }
  void title(int x, int y, const char* s) { for (int i = 0; s[i]; i++) glyph(x + i * 6 + 1, y + 1, s[i], C_PUR); for (int i = 0; s[i]; i++) glyph(x + i * 6, y, s[i], lerp(0xff7ad9, 0x38f2ff, 80)); }
  void panel(int x, int y, int w, int h, int a = 178) { blendRect(x, y, w, h, 0x050a18, a); frame(x, y, w, h, 0x2a5a66); }
  void bar(int x, int y, int w, int h, int v, int mx, rgb c) { rect(x, y, w, h, 0x14202c); int f = clampi(w * v / (mx ? mx : 1), 0, w); rect(x, y, f, h, c); }
  void wrap(int x, int y, int w, const char* s, rgb c, int maxLines) {   // word wrap
    int cpl = w / 6, n = 0; const char* p = s;
    while (*p && n < maxLines) { int len = (int)strlen(p); if (len <= cpl) { text(x, y + n * 10, p, c); return; } int cut = cpl; while (cut > 0 && p[cut] != ' ') cut--; if (!cut) cut = cpl;
      char tmp[48]; int m = cut > 47 ? 47 : cut; memcpy(tmp, p, m); tmp[m] = 0; text(x, y + n * 10, tmp, c); n++; p += cut; while (*p == ' ') p++; }
  }
};

// --------------------------------------------------------------------------- "The Sunken Shrine", morning edition
const int HORIZON = 96;
const int16_t CLOUD[4][5] = {{20, 22, 17, 5, 5}, {118, 12, 24, 6, 3}, {190, 40, 14, 4, 7}, {70, 58, 19, 5, 4}};
int isqrt(int v) { int r = 0; while ((r + 1) * (r + 1) <= v) r++; return r; }
void drawCloud(Gfx& g, int cx, int cy, int w, int h) {
  for (int dy = -h; dy <= h; dy++) { int f = 1000 - dy * dy * 1000 / (h * h + 1); int half = f <= 0 ? 0 : isqrt(w * w * f / 1000); rgb c = dy > h * 4 / 10 ? 0xd3e4f4 : dy > 0 ? 0xeaf3fb : 0xffffff; g.rect(cx - half, cy + dy, half * 2, 1, c); }
  int w2 = w * 6 / 10, h2 = h * 8 / 10; for (int dy = -h2; dy <= h2; dy++) { int f = 1000 - dy * dy * 1000 / (h2 * h2 + 1); int half = f <= 0 ? 0 : isqrt(w2 * w2 * f / 1000); g.rect(cx + (w >> 1) - half, cy + dy - 3, half * 2, 1, dy > h2 * 4 / 10 ? 0xdbe9f6 : 0xffffff); }
}
__attribute__((noinline)) void drawShrine(Gfx& g, uint32_t tick) {
  const int ya = g.y0, yb = g.y0 + g.rows;
  for (int y = ya; y < yb && y < HORIZON; y++) { int t = y * 255 / HORIZON; rgb c = t < 150 ? lerp(0x3d8ee0, 0x86c4f2, t * 255 / 150) : lerp(0x86c4f2, 0xe1f2fc, (t - 150) * 255 / 105); g.rect(0, y, W, 1, c); }
  if (ya < HORIZON) {
    for (int i = 0; i < 4; i++) { int w = CLOUD[i][2], span = W + 2 * w + 40, cx = (int)((CLOUD[i][0] + (tick * CLOUD[i][4] >> 4)) % span) - w - 20; if (CLOUD[i][1] + CLOUD[i][3] + 4 >= ya && CLOUD[i][1] - CLOUD[i][3] - 4 < yb) drawCloud(g, cx, CLOUD[i][1], w, CLOUD[i][3]); }
    const rgb mar = 0xece7d8, shd = 0xa9bccd; g.rect(86, 82, 68, 3, mar); g.rect(86, 85, 68, 1, shd);
    for (int i = 0; i < 6; i++) { g.rect(90 + i * 11, 86, 4, 9, mar); g.rect(93 + i * 11, 86, 1, 9, shd); }
    for (int r = 0; r < 7; r++) g.rect(92 + r, 75 + r, 56 - r * 2, 1, r & 1 ? mar : 0xf6f2e6);
    g.rect(86, HORIZON - 1, 68, 1, 0x7fb6d4);
  }
  for (int by = HORIZON; by < H; by += 2) {
    if (by + 2 <= ya || by >= yb) continue;
    int t = clampi((by - HORIZON) * 255 / 130, 0, 255); rgb base = lerp(0x5fcbe2, 0x0c4f88, t);
    for (int bx = 0; bx < W; bx += 2) {
      int w = (isin(((bx * (3 + (t >> 6))) + (int)tick * 3 + (isin(by * 9 + (int)tick * 2) >> 11)) & 255) + isin((by * 5 - (int)tick * 2 + bx) & 255)) >> 1; rgb c = base;
      if (w > 21000) c = lerp(base, 0xf0ffff, 150); else if (w > 14000) c = lerp(base, 0x9fe6f2, 90); else if (w < -22000) c = lerp(base, 0x062a52, 90);
      if ((((bx >> 1) + (by >> 1)) & 1) && w > 9000 && w <= 14000) c = lerp(base, 0x7fd8ea, 60);
      g.rect(bx, by, 2, 2, c);
    }
  }
  for (int y = HORIZON + 1; y < HORIZON + 24; y += 3) { int w = isin(y * 11 + (int)tick * 5), len = 120 - ((y - HORIZON) * 3) + (w >> 10); if (len > 6 && y >= ya && y < yb) g.rect(120 - (len >> 1), y, len, 1, lerp(0xe9f8ff, 0x7fd0e8, clampi((y - HORIZON) * 8, 0, 255))); }
}
__attribute__((noinline)) void drawColumn(Gfx& g, int x, int w, uint32_t tick) {
  const int top = 18; if (top < g.y0 + g.rows) { g.rect(x - 2, top, w + 4, 4, 0xf6f1e4); g.rect(x - 1, top + 4, w + 2, 2, 0xd9d1bd); g.rect(x, top + 6, w, 2, 0xbdb5a0); }
  for (int y = top + 8 > g.y0 ? top + 8 : g.y0; y < g.y0 + g.rows && y < 196; y++) {
    bool sub = y >= HORIZON; int ox = sub ? (isin(y * 9 + (int)tick * 4) >> 14) : 0;
    for (int i = 0; i < w; i++) {
      int dx2 = 2 * i - (w - 1), sh = 255 - (dx2 < 0 ? -dx2 : dx2) * 255 / w; int l = 130 + sh * 125 / 255; if ((i % 4) == 0) l -= 46;
      uint32_t hv = hash32((uint32_t)(i * 131 + (y >> 2) * 17)); if ((hv & 63) == 0 && (i % 4) != 0) l -= 26; if (((i + y) & 15) == 0 && (hv & 3) == 0) l -= 18;
      rgb c = (rgb)(clampi(l + 20, 0, 255) << 16 | clampi(l + 14, 0, 255) << 8 | clampi(l - 4, 0, 255));
      if (sub) { c = lerp(c, 0x1b7fb0, clampi((y - HORIZON) * 3, 0, 190)); }
      g.px(x + i + ox, y, c);
    }
  }
  if (196 >= g.y0 && 196 < g.y0 + g.rows) g.rect(x - 3, 196, w + 6, 6, 0xb6c9c4);
}

// --------------------------------------------------------------------------- chrome
__attribute__((noinline)) void header(Gfx& g, const Snap& s) {
  g.rect(0, 0, W, 16, 0x070b1c); g.blendRect(0, 0, W, 16, 0x2a0a4a, 90); g.hline(0, 16, W, 0x2f8f8a); g.hline(0, 17, W, 0x7a3cff);
  static const char* const GLT[4] = {"GLOBAL", "PROJECT / LOOP", "MIDI OUT", "MIDI ROUTING"}; char t[20]; strncpy(t, s.page == P_EDIT && s.edView ? "STEP EDIT" : s.page == P_GLO ? GLT[s.glo & 3] : PAGE_TITLE[s.page], 16); t[16] = 0; g.title(4, 4, t);
  char bk[4] = {(char)('A' + s.bank), 0, 0, 0}; if (s.len > 1) { bk[1] = '/'; bk[2] = (char)('A' + s.len - 1); } g.text(100, 4, "BANK", C_DIM2); g.text(126, 4, bk, C_YEL);
  char bpm[10]; int v = s.bpm, i = 0; if (v >= 100) bpm[i++] = (char)('0' + v / 100); bpm[i++] = (char)('0' + v / 10 % 10); bpm[i++] = (char)('0' + v % 10); bpm[i++] = 'B'; bpm[i++] = 'P'; bpm[i++] = 'M'; bpm[i] = 0; g.textR(184, 4, bpm, C_ACC);
  if (s.playing) for (int k = 0; k < 5; k++) g.vline(188 + k, 4 + (k >> 1), 8 - (k >> 1) * 2, C_GRN); else g.rect(188, 5, 5, 6, C_DIM);
  int mv = clampi(s.master * 12 / 127, 0, 12); g.rect(199, 2, 5, 13, 0x10202a); for (int k = 0; k < mv; k++) g.rect(199, 14 - k, 5, 1, k > 10 ? C_RED : k > 8 ? C_YEL : C_GRN);
  if (s.rec) { rgb c = (s.tick & 8) ? C_RED : 0x802030; g.rect(210, 4, 8, 8, c); }
  g.text(222, 4, s.undoN ? "U" : "-", s.undoN ? C_ACC : C_DIM2); g.text(229, 4, s.redoN ? "R" : "-", s.redoN ? C_ACC : C_DIM2);
}
__attribute__((noinline)) void footer(Gfx& g, const Snap& s) {
  g.rect(0, 203, W, 37, 0x050a14); g.hline(0, 202, W, 0x2f8f8a); g.hline(0, 203, W, 0x7a3cff);
  for (int i = 0; i < 4; i++) {
    int x = 2 + i * 47; const Knob& k = s.k[i]; char tag[3] = {'K', (char)('1' + i), 0}; if (i) g.vline(x - 2, 205, 24, 0x16303a);
    if (k.used) { g.text(x, 206, tag, KCOL[i]); g.textR(x + 43, 206, k.txt, C_WHT); char lb[8]; strncpy(lb, k.label, 7); lb[7] = 0; g.text(x, 215, lb, KCOL[i]); g.rect(x, 224, 43, 3, 0x14202c); g.rect(x, 224, 43 * k.pos / 127, 3, KCOL[i]); }
    else { g.text(x, 206, tag, C_DIM2); g.text(x, 215, "--", C_DIM2); }
  }
  g.vline(189, 205, 24, 0x16303a); g.text(192, 206, "SEL", C_VIO); g.text(214, 206, s.selTag, C_VIO); g.text(192, 215, s.selVal, C_WHT);
  g.text(2, 230, s.hint, C_DIM);
}
__attribute__((noinline)) void toast(Gfx& g, const Snap& s) { if (!s.toastOn) return; int w = 12 + (int)strlen(s.toast) * 6; if (w > 228) w = 228; g.rect(120 - (w >> 1), 188, w, 12, 0x000000); g.frame(120 - (w >> 1), 188, w, 12, C_PNK); g.textC(120, 191, s.toast, C_WHT); }
__attribute__((noinline)) void intro(Gfx& g, const Snap& s) {                                       // HOME: quick start + system navigation (the sequencer keeps running underneath)
  static const char* const M[9] = {"STEP MATRIX", "MIXER", "PIANO ROLL", "STEP EDIT", "GLOBAL", "SEQ", "FX RACK", "SAVE", "CLEAR"};
  g.blendRect(0, 0, W, H, 0, 150); g.rect(6, 22, 228, 176, 0x0b0720); g.frame(6, 22, 228, 176, C_PNK); g.frame(8, 24, 224, 172, C_CYN); g.title(14, 29, "SYSTEM NAV");
  g.text(14, 41, s.ext ? "SYNC MIDI" : "SYNC INT", s.ext ? C_YEL : C_GRN); g.text(86, 41, "44.1K 24B", C_DIM); g.textR(226, 41, s.usb ? "USB OK" : "NO USB", s.usb ? C_GRN : C_DIM2);
  char t[28]; char* p = putn(t, s.bpm); strcpy(p, " BPM  LOOP "); p = putn(p + 11, s.engLen); strcpy(p, " STEPS"); g.text(14, 51, t, C_TXT); g.textR(226, 51, s.playing ? "PLAYING" : "STOPPED", s.playing ? C_GRN : C_DIM);
  for (int i = 0; i < 9; i++) { const int y = 62 + i * 11; const bool sel = i == s.navSel; if (sel) g.rect(12, y - 2, 216, 11, 0x1a3050); char d[2] = {(char)('1' + i), 0}; g.text(16, y, d, sel ? C_PNK : C_YEL); g.text(30, y, M[i], sel ? C_WHT : C_TXT); }
  g.text(14, 164, "SELECT 1-9 16=GO", C_DIM); g.text(14, 178, "HOLD HOME=PANIC", C_YEL); g.rect(140, 178, 86, 7, 0x14202c); g.rect(140, 178, 86 * s.panicPct / 100, 7, C_RED);
}

// --------------------------------------------------------------------------- pages
void noteRange(const Snap& s, int& lo, int& hi) {                          // lowest / highest note of the 16 steps (at least an octave)
  lo = 127; hi = 0; for (int i = 0; i < NS; i++) if (s.stepOn[i]) { if (s.stepNote[i] < lo) lo = s.stepNote[i]; if (s.stepNote[i] > hi) hi = s.stepNote[i]; } if (lo > hi) { lo = 48; hi = 72; } if (hi - lo < 12) hi = lo + 12;
}
__attribute__((noinline)) void pageHome(Gfx& g, const Snap& s) {
  int t = s.track; rgb col = TRKCOL[s.hw[t] & 7];
  for (int i = 0; i < NT; i++) { int x = 4 + i * 29; rgb c = s.active[i] ? TRKCOL[s.hw[i] & 7] : s.has[i] ? lerp(TRKCOL[s.hw[i] & 7], 0, 170) : 0x0f1a26; g.rect(x, 19, 25, 7, c); if (s.mute[i]) { g.line(x + 1, 20, x + 23, 24, C_RED); } if (s.solo[i]) g.rect(x + 9, 21, 7, 3, C_YEL); if (i == t) g.frame(x - 1, 18, 27, 9, C_WHT); }
  g.panel(4, 29, 232, 12); g.rect(7, 32, 6, 6, col); g.text(17, 31, s.trackLong, col); g.textR(233, 31, s.patch, C_TXT);
  int lo, hi; noteRange(s, lo, hi);
  for (int i = 0; i < NS; i++) {                                                // the 16-step bank
    int x = 4 + i * 145 / 10, on = s.stepOn[i]; rgb fill = (i & 3) == 0 ? 0x1c2a3a : 0x131e2c; if (on) fill = lerp(lerp(0, col, 110), col, s.stepVel[i] * 2);
    g.panel(x - 1, 46, 15, 62, 150); g.rect(x, 47, 13, 60, fill);
    if (on) { int h = 1 + (s.stepNote[i] - lo) * 54 / (hi - lo); g.rect(x + 1, 106 - h, 11, 2, C_WHT); if (s.stepChord[i]) g.rect(x + 9, 103, 3, 3, C_YEL);
      if (s.edPads) { char pn[3] = {s.padLbl[s.pencil & 15][0], s.padLbl[s.pencil & 15][1], 0}; g.text(x + 1, 49, pn, C_BG); }              // the exact key name at the top of every lit column: C#4 as 'C#' over '4'; drums show the pad
      else { char nm[6]; putNote(nm, s.stepNote[i]); const int sh = nm[1] == '#'; char a[3] = {nm[0], sh ? '#' : 0, 0}; g.text(x + 1, 49, a, C_BG); g.text(x + 1 + (sh ? 3 : 0), 58, nm + 1 + sh, C_BG); } }
    if (s.playStep == i) { g.frame(x - 1, 46, 15, 62, C_WHT); g.blendRect(x, 47, 13, 60, 0xffffff, 60); }
    if (s.heldStep == i) g.frame(x - 1, 46, 15, 62, C_YEL);
    char n[4]; int v = i + 1; n[0] = v >= 10 ? (char)('0' + v / 10) : ' '; n[1] = (char)('0' + v % 10); n[2] = 0; g.text(x + 1, 111, n, s.playStep == i ? C_WHT : (i & 3) == 0 ? C_ACC : C_DIM2);
  }
  g.text(6, 124, s.heldStep != 255 ? s.heldInfo : s.mOnly ? "LOCAL OFF: EDIT>OUT" : "ANY KEY=NEW ALGO", s.heldStep != 255 ? C_YEL : s.mOnly ? C_RED : C_PNK);
  g.panel(4, 136, 232, 36); char lane[34]; strcpy(lane, "AUTOMATION > "); strncat(lane, s.laneName, 10); strcat(lane, " "); strncat(lane, s.k[s.lk & 3].txt, 7); g.text(8, 139, lane, s.rec ? C_RED : C_ACC); g.textR(233, 139, s.rec ? "REC: TURN K1-K4" : "REC+KNOB", s.rec ? C_WHT : C_DIM2);
  for (int i = 0; i < NS; i++) { int h = s.laneVal[i] * 17 / 127; if (s.laneVal[i]) g.rect(7 + i * 14, 170 - h, 11, h, s.playStep == i ? C_WHT : col); else g.rect(7 + i * 14, 169, 11, 1, 0x1a3a44); }
  g.panel(4, 176, 232, 24); g.text(8, 179, "ALGORITHM", C_DIM); g.text(62, 179, s.styValid ? s.styName : "-", s.styValid ? C_PNK : C_DIM2); g.text(8, 189, s.styValid ? s.prog : "", s.styValid ? C_YEL : C_DIM2);
}
__attribute__((noinline)) void pageFx(Gfx& g, const Snap& s) {
  for (int u = 0; u < 6; u++) {
    int x = 4 + (u % 3) * 78, y = 19 + (u / 3) * 84; bool sel = u == s.fxSel; g.panel(x, y, 74, 80, sel ? 235 : 190); g.frame(x, y, 74, 80, sel ? C_YEL : 0x2a5a66);
    g.text(x + 4, y + 4, FX_NAMES[u], sel ? C_YEL : C_ACC); int nk = u == 0 ? 2 : u == 1 ? 3 : u == 5 ? 3 : 1; bool act = false; for (int k = 0; k < nk; k++) if (s.fxv[u][k]) act = true; g.rect(x + 64, y + 4, 5, 5, act ? C_GRN : C_DIM2);
    static const char* const L[6][3] = {{"TIME", "MIX", ""}, {"TIME", "FDBK", "MIX"}, {"DEPTH", "MIX", ""}, {"DRIVE", "", ""}, {"AMOUNT", "", ""}, {"CUTOFF", "RES", "LEVEL"}};
    for (int k = 0; k < nk; k++) { int yy = y + 17 + k * 20; char lb[12] = ""; if (sel) { lb[0] = 'K'; lb[1] = (char)('1' + k); lb[2] = ' '; lb[3] = 0; } strcat(lb, L[u][k]); g.text(x + 4, yy, lb, sel ? KCOL[k] : C_DIM); g.textR(x + 70, yy, s.fxtxt[u][k], sel ? C_WHT : C_DIM2); g.rect(x + 4, yy + 9, 66, 5, 0x0c141e); g.rect(x + 4, yy + 9, 66 * s.fxv[u][k] / 127, 5, sel ? KCOL[k] : 0x3a7a88); if (s.fxAuto && sel) g.frame(x + 3, yy + 8, 68, 7, C_RED); }
  }
  g.panel(4, 189, 232, 12, 200); char ln[24] = "FX LANE > "; strncat(ln, s.fxLane, 10); g.text(8, 192, ln, s.rec ? C_RED : C_DIM);
  for (int i = 0; i < NS; i++) { int h = s.fxLaneVal[i] >> 4; if (h) g.rect(100 + i * 8, 200 - h, 6, h, s.playStep == i ? C_WHT : C_CYN); }
}
__attribute__((noinline)) void pageMix(Gfx& g, const Snap& s) {
  g.panel(4, 19, 232, 150, 210);
  for (int t = 0; t < NT; t++) {
    int x = 8 + t * 28; bool sel = t == s.track; if (sel) { g.rect(x - 2, 21, 26, 146, 0x16243a); g.frame(x - 2, 21, 26, 146, C_WHT); }
    const int lv = s.level[t]; g.rect(x, 32, 5, 80, 0x0c141e); for (int i = 0; i < lv; i += 2) g.rect(x, 111 - i, 5, 2, i > 72 ? C_RED : i > 60 ? C_YEL : TRKCOL[s.hw[t] & 7]); if (s.peak[t]) g.rect(x, 111 - s.peak[t], 5, 2, C_WHT);   // -6 dB yellow, -2 dB red; white = peak hold
    int fy = 112 - s.vol[t] * 80 / 127; g.rect(x + 10, 32, 3, 80, 0x0c141e); g.rect(x + 7, fy - 2, 10, 4, 0xd9e4ea);
    g.rect(x + s.send1[t] * 14 / 127, 23, 4, 4, C_ACC); g.rect(x + s.send2[t] * 14 / 127, 28, 4, 3, C_PNK);
    g.rect(x, 116, 20, 9, s.mute[t] ? C_RED : 0x14202c); g.text(x + 7, 117, "M", s.mute[t] ? C_WHT : C_DIM2); g.rect(x, 127, 20, 9, s.solo[t] ? C_YEL : 0x14202c); g.text(x + 7, 128, "S", s.solo[t] ? C_BG : C_DIM2);
    char n[3] = {(char)('1' + t), 0, 0}; g.text(x + 7, 150, n, sel ? C_WHT : TRKCOL[s.hw[t] & 7]);
  }
  g.panel(4, 172, 232, 28, 210); g.text(8, 176, s.trackLong, TRKCOL[s.hw[s.track] & 7]);
}
__attribute__((noinline)) void pagePre(Gfx& g, const Snap& s) {                                       // left: the tracks (SELECT); right: only THIS track's sounds (PRESETS)
  g.panel(4, 19, 62, 150, 215); g.text(8, 22, "TRACK", C_DIM);
  for (int i = 0; i < NT; i++) { const int y = 34 + i * 14; const bool sel = i == s.track; if (sel) { g.rect(6, y - 2, 58, 12, 0x1a3050); g.text(8, y, ">", C_YEL); } g.text(16, y, s.trackName[i], sel ? C_PNK : TRKCOL[s.hw[i] & 7]); }
  g.panel(70, 19, 166, 150, 215); char hd[24] = ""; if (s.pMask && s.pMask != 0x3FF) for (int i = 0; i < 10; i++) if ((s.pMask >> i) & 1) { if (hd[0]) strcat(hd, "+"); strcat(hd, FM_CATS[i]); }
  g.text(74, 22, hd[0] ? hd : s.pMask ? "ALL SOUNDS" : "PRESETS", C_ACC); if (s.pTot) { char c[12]; char* e = putn(c, s.pPos + 1); *e++ = '/'; putn(e, s.pTot); g.textR(232, 22, c, C_DIM); }
  for (int i = 0; i < s.pcount && i < 12; i++) { int y = 34 + i * 11; bool sel = i == s.psel; if (sel) { g.rect(72, y - 1, 162, 11, 0x1a3050); g.text(74, y, ">", C_YEL); } g.text(84, y, s.plist[i], sel ? C_WHT : C_TXT); }
  g.panel(4, 172, 232, 28, 215); g.text(8, 176, s.pinfo[0], C_ACC); g.text(8, 187, s.pinfo[1], C_GRN);
}
__attribute__((noinline)) void pageEdit(Gfx& g, const Snap& s) {                                      // EDIT: live piano roll (EDIT again = tracker); the 11 black keys are the command row
  const int cur = s.edStep, cw = 13, gx = 30, gy = 29; const rgb col = TRKCOL[s.hw[s.track] & 7]; const bool dr = s.edPads != 0; char b[12];
  g.panel(4, 19, 232, 170, 215);
  {
    const int rows = dr ? (s.edPads > 16 ? 16 : s.edPads) : 14, rh = dr ? 10 : 11, n0 = s.stepOn[cur] ? s.stepNote[cur] : s.pencil; int lo, hi; noteRange(s, lo, hi); const int base = dr ? 0 : hi - lo <= 13 ? clampi(hi - 13, 0, 114) : clampi(n0 - 7, 0, 114);   // the whole bank when it fits, else follow the cursor
    for (int r = 0; r < rows; r++) {                                       // pitch (or pad) rows, highest on top
      const int p = base + r, y = gy + (rows - 1 - r) * rh; const bool sel = dr ? p == s.pencil : p == n0;
      g.rect(gx, y, NS * cw, rh - 1, !dr && BLK[p % 12] ? 0x0a1220 : 0x131e2e); if (sel) g.blendRect(gx, y, NS * cw, rh - 1, C_PNK, 55);
      if (dr) g.text(6, y + 1, s.padLbl[p], sel ? C_PNK : C_DIM); else if (sel || p % 12 == 0) { putNote(b, p); g.text(6, y + 1, b, sel ? C_PNK : C_DIM); }
    }
    for (int i = 0; i < NS; i++) {
      const int x = gx + i * cw; putn(b, i + 1); g.text(x + (i < 9 ? 3 : 0), 20, b, s.playStep == i ? C_WHT : (i & 3) == 0 ? C_ACC : C_DIM2);
      if ((i & 3) == 0) g.vline(x - 1, gy, rows * rh, 0x2a5a66); if (s.playStep == i) g.blendRect(x, gy, cw - 1, rows * rh, C_WHT, 50);
      if (dr) { for (int r = 0; r < rows; r++) if ((s.edMask[i] >> r) & 1) g.rect(x + 1, gy + (rows - 1 - r) * rh + 1, cw - 3, rh - 3, lerp(0x203040, col, s.stepVel[i] * 2)); }
      else if (s.stepOn[i] && s.stepNote[i] >= base && s.stepNote[i] < base + rows) {
        const int y = gy + (rows - 1 - (s.stepNote[i] - base)) * rh, gt = s.edGate[i] ? s.edGate[i] : 8, w = s.edTie[i] ? cw : 3 + gt * (cw - 4) / 15;
        g.rect(x + 1, y + 1, w - 1, rh - 3, lerp(0x203040, col, s.stepVel[i] * 2)); if (s.edChord[i]) g.rect(x + 1, y + 1, 3, 3, C_YEL);
      }
    }
    g.frame(gx + cur * cw - 1, gy - 1, cw + 1, rows * rh + 1, C_YEL);
  }
  static const char* const CL[5] = {"S:A", "CPY", "PST", "DEL", "OUT"};
  if (!s.edView) { g.text(6, 192, s.rec ? "REC ON" : "EDIT = STEPS", s.rec ? C_RED : C_ACC); return; }   // piano roll = keyboard; step mode = punch keys + this command row
  for (int i = 0; i < 5; i++) { g.rect(5 + i * 21, 191, 20, 10, 0x0c1420); g.text(8 + i * 21, 192, i == 0 ? (s.edSet ? "S:B" : "S:A") : CL[i], i == 0 ? C_YEL : C_ACC); }
}
__attribute__((noinline)) void pageGeneric(Gfx& g, const Snap& s) {
  g.panel(4, 19, 232, 100, 210); g.text(8, 23, s.gtitle, C_YEL);
  for (int i = 0; i < 4; i++) { int y = 36 + i * 20; char lb[20] = {'K', (char)('1' + i), ' ', 0}; strncat(lb, s.grow[i].label, 10); g.text(8, y, lb, KCOL[i]); g.textR(232, y, s.grow[i].txt, C_WHT); g.rect(8, y + 10, 224, 5, 0x0c141e); g.rect(8, y + 10, 224 * s.grow[i].pos / 127, 5, KCOL[i]); }
}
__attribute__((noinline)) void pageGen(Gfx& g, const Snap& s) {                                       // the algorithm window: 12 live controls in 3 sets (SEQ cycles them), shared chord progression readout
  const rgb col = TRKCOL[s.hw[s.track] & 7]; g.panel(4, 19, 232, 104, 215); g.text(8, 22, s.trackLong, col); g.textR(232, 22, s.styValid ? s.styName : "-", C_PNK);
  for (int i = 0; i < NS; i++) { int x = 8 + i * 14; g.rect(x, 33, 13, 16, s.stepOn[i] ? col : ((i & 3) == 0 ? 0x1a2838 : 0x101a26)); }
  static const char* const N[12] = {"DENS", "CHAOS", "HOLD", "SYNC", "LEAP", "VOICE", "PROG", "OCT", "HUMAN", "SWING", "BANK", ""};
  for (int a = 0; a < 3; a++) for (int i = 0; i < 4; i++) { const int x = 8 + a * 76, y = 56 + i * 15, k = a * 4 + i; const bool on = a == s.genSet;
    g.text(x, y, N[k], on ? KCOL[i] : C_DIM2); g.rect(x, y + 9, 70, 3, 0x14202c); g.rect(x, y + 9, 70 * s.gv[k] / 127, 3, on ? KCOL[i] : 0x3a5560); }
  g.panel(4, 127, 232, 73, 215); g.wrap(8, 131, 224, s.prog, C_YEL, 3); bool f = s.genFlash && (s.tick & 2);
  g.rect(8, 166, 224, 12, f ? C_PNK : 0x3a1050); g.frame(8, 166, 224, 12, C_PNK); g.textC(120, 169, f ? "NEW" : "KEYS=NEW PULL", C_WHT);
}
__attribute__((noinline)) void pageSave(Gfx& g, const Snap& s) {
  const int nRows = 17, row = s.svRow, top = clampi(row - 4, 0, nRows - 9);
  g.panel(4, 19, 232, 122, 215); g.text(8, 22, "SAVE LIST", C_ACC); int used = 0; for (int i = 0; i < 16; i++) used += s.svUsed[i]; char cnt[12] = {(char)('0' + used / 10), (char)('0' + used % 10), '/', '1', '6', ' ', 'U', 'S', 'E', 'D', 0}; if (cnt[0] == '0') cnt[0] = ' '; g.textR(232, 22, cnt, C_DIM);
  for (int i = 0; i < 9; i++) {
    const int r = top + i, y = 33 + i * 11; if (r >= nRows) break; const bool sel = r == row;
    if (sel) { g.rect(6, y - 1, 222, 11, r == 0 ? 0x0f3a50 : 0x1a3050); g.text(8, y, ">", C_YEL); }
    if (r == 0) g.text(18, y, "EXPORT TO DAW", sel ? C_WHT : C_DIM2);
    else { char n3[4] = {(char)('0' + r / 10), (char)('0' + r % 10), 0, 0}; if (n3[0] == '0') n3[0] = ' '; g.text(18, y, n3, sel ? C_YEL : C_DIM); const bool u = s.svUsed[r - 1]; g.text(42, y, u ? s.svName[r - 1] : "- EMPTY -", u ? (sel ? C_WHT : C_TXT) : C_DIM2); }
  }
  const int sbH = 12; g.rect(231, 32, 3, 100, 0x0c141e); g.rect(231, 32 + top * (100 - sbH) / (nRows - 9), 3, sbH, C_ACC);
  g.panel(4, 145, 232, 55, 215);
  if (row == 0) {
    g.text(8, 149, s.usb ? "USB OK" : "NO USB", s.usb ? C_GRN : (s.tick & 16) ? C_YEL : C_TXT); g.text(8, 160, "KEY 1 = EXPORT", C_WHT);
    g.text(8, 192, "K1 = LOOPS", C_DIM2);
  } else {
    const int i = row - 1; const bool u = s.svUsed[i]; char h[28] = "SLOT "; h[5] = (char)('0' + (i + 1) / 10); h[6] = (char)('0' + (i + 1) % 10); h[7] = 0; g.text(8, 149, h, u ? C_WHT : C_DIM); g.text(52, 149, u ? s.svName[i] : "EMPTY", u ? C_WHT : C_DIM);
    if (s.nmOn) { g.text(8, 162, "NAME", C_ACC); for (int k = 0; k < 6; k++) { const int x = 40 + k * 16; g.rect(x, 159, 14, 14, k == s.nmCur ? 0x3a1050 : 0x0c1420); g.frame(x, 159, 14, 14, k == s.nmCur ? C_PNK : C_DIM2); char c[2] = {s.nm[k], 0}; g.text(x + 4, 162, c, C_WHT); }
      g.text(8, 178, "K1 CHAR  K2 MOVE L/R", C_DIM); g.text(8, 189, "HIT SAVE AGAIN TO SAVE", C_YEL); return; }
    g.rect(8, 163, 80, 12, 0x0c1420); g.frame(8, 163, 80, 12, C_ACC); g.text(11, 166, "1 SAVE HERE", C_WHT); g.rect(94, 163, 42, 12, 0x0c1420); g.frame(94, 163, 42, 12, u ? C_ACC : C_DIM2); g.text(97, 166, "2 LOAD", u ? C_WHT : C_DIM2); g.rect(142, 163, 40, 12, 0x0c1420); g.frame(142, 163, 40, 12, C_ACC); g.text(145, 166, "4 FREE", C_WHT);
    g.text(8, 191, "", C_DIM2);
  }
}
__attribute__((noinline)) void exportPanel(Gfx& g, const Snap& s) {                                    // EXPORT TO DAW: prompt, then one progress bar per track while it plays
  g.rect(6, 22, 228, 176, 0x0b0720); g.frame(6, 22, 228, 176, C_PNK); g.title(14, 29, "EXPORT TO DAW");
  if (s.exState == 1) { g.text(14, 52, "CONNECT AS AUDIO INPUT", C_YEL); g.text(14, 64, "EXPORT? 1 YES 2 NO", C_WHT); g.text(14, 86, s.exTail ? "3=TAIL CUT" : "3=TAIL RING", C_ACC); return; }
  if (s.exState == 5) { g.text(14, 52, "DONE", C_GRN); return; }
  for (int i = 0; i < s.exPasses && i < 8; i++) {
    const int y = 56 + i * 14; int p = 0; for (int k = 0; k < NT; k++) if (s.hw[k] == s.exTr[i]) p = k;
    const bool cur = i == s.exPass && s.exState >= 3, done = i < s.exPass; g.text(14, y, s.trackName[p], cur ? C_WHT : done ? C_GRN : C_DIM);
    g.rect(70, y, 150, 8, 0x14202c); g.rect(70, y, done ? 150 : cur && s.exState == 3 ? 150 * s.exPct / 100 : 0, 8, done ? C_GRN : TRKCOL[s.hw[p] & 7]);
  }
  g.text(14, 42, s.exState == 2 ? "RECORD NOW" : "PLAY=CANCEL", s.exState == 2 ? C_RED : C_DIM);
}
__attribute__((noinline)) void boot(Gfx& g, const Snap& s) {                                         // one plain line; any key skips it
  g.rect(0, g.y0, W, g.rows, 0); g.textC(120, 112, "CHROME BOY STUDIO PORTABLE V0.9", C_PNK);
}
}  // namespace

void ui_paint_band(const Snap& s, uint16_t* band, int y0, int rows) {
  Gfx g{band, y0, rows};
  if (s.boot < BOOT_FRAMES) { boot(g, s); return; }
  drawShrine(g, s.tick); drawColumn(g, 2, 18, s.tick); drawColumn(g, 220, 18, s.tick);
  switch (s.page) { case P_HOME: pageHome(g, s); break; case P_FXM: pageFx(g, s); break; case P_MIX: pageMix(g, s); break; case P_PRE: pagePre(g, s); break; case P_GEN: pageGen(g, s); break; case P_SAVE: pageSave(g, s); break; case P_EDIT: pageEdit(g, s); break; default: pageGeneric(g, s); }
  header(g, s); footer(g, s); toast(g, s); if (s.intro) intro(g, s); if (s.exState) exportPanel(g, s);
}
}  // namespace cb
