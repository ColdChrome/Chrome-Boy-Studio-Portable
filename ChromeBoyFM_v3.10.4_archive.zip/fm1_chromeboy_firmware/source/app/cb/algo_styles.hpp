// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM  -  generative engine v3 (integer only: no float / double, so the 4 KB soft-float runtime is gone).
// Every track follows ONE shared chord progression (Opts::deg, diatonic degrees of the active key), built from the scale
// itself, so basses, pads and leads always agree and stay in key.  NEW VARIATION re-rolls rhythm / notes / holds over the same
// harmony; NEW PROGRESSION re-rolls the chords (Markov walk over scale degrees, four families).
// Dependency-free (no SDK, no heap, no libc++): compiles on the AC791N pi32 toolchain and on the host (host_test/gen_test.cpp).
#pragma once
#include <stdint.h>

namespace algo {

constexpr int NS = 16;                          // exactly 16 steps per bank
struct Step { uint8_t note, vel, gate, chord, tie, prob; };     // vel 0 = empty.  gate 1..15 sixteenths of a step.  chord = SDK chord id 0..16.  tie = hold into the following steps.  prob 0 always, 1..7 = n/8
struct Opts { uint32_t seed; int scale, density, chaos, human, oct, hold, sync, leap, voice, fam; uint8_t deg[4]; };   // scale = type*12 + root pitch class
struct Result { const char* name; char prog[72]; uint8_t kind; char nm[26]; };   // melodic names are generated into nm            // kind: 0 chord 1 arp 2 lead 3 bass 4 drum 5 perc 6 fx

static const char* const NOTE_NAMES[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
struct ScaleDef { const char* name; uint8_t n; uint8_t iv[7]; };
static const ScaleDef SCALES[8] = {{"MAJOR", 7, {0, 2, 4, 5, 7, 9, 11}}, {"MINOR", 7, {0, 2, 3, 5, 7, 8, 10}}, {"DORIAN", 7, {0, 2, 3, 5, 7, 9, 10}},
    {"PHRYG", 7, {0, 1, 3, 5, 7, 8, 10}}, {"LYDIAN", 7, {0, 2, 4, 6, 7, 9, 11}}, {"MIXOLY", 7, {0, 2, 4, 5, 7, 9, 10}}, {"PENT-m", 5, {0, 3, 5, 7, 10}}, {"PENT-M", 5, {0, 2, 4, 7, 9}}};
// chord vocabulary = the 16 SDK chord slots (id 1..16): {note count, offsets above the root}
static const char* const QN[17] = {"", "", "m", "dim", "aug", "sus2", "sus4", "maj7", "m7", "7", "m7b5", "dim7", "maj9", "m9", "9", "5", "add9"};
static const uint8_t QTAB[16][6] = {{3, 4, 7}, {3, 3, 7}, {3, 3, 6}, {3, 4, 8}, {3, 2, 7}, {3, 5, 7}, {4, 4, 7, 11}, {4, 3, 7, 10}, {4, 4, 7, 10}, {4, 3, 6, 10}, {4, 3, 6, 9},
    {5, 4, 7, 11, 14}, {5, 3, 7, 10, 14}, {5, 4, 7, 10, 14}, {3, 7, 12}, {4, 4, 7, 14}};

static const char* const ST_DRN[9] = {"HOUSE", "4/4 SYNC", "MIAMI", "ELECTRO", "DETROIT", "BREAKS", "TRAP", "DNB", "HALF"};
static const uint32_t ST_DRP[9][6] = {
  {0x03030303u, 0x00000000u, 0x03000300u, 0x62626262u, 0x30303030u, 0x00000000u},
  {0x03830303u, 0x41000100u, 0x03000300u, 0x66666666u, 0x20202020u, 0x44000000u},
  {0x03203083u, 0x03000300u, 0x42000200u, 0xa2222222u, 0x00200020u, 0x08800000u},
  {0x30033003u, 0x03000300u, 0x02000200u, 0x22222222u, 0x20002000u, 0x20020020u},
  {0x03030303u, 0x01000100u, 0x03000300u, 0x20202020u, 0x11111111u, 0x10001000u},
  {0x00a00023u, 0x03044300u, 0x00000000u, 0x22222222u, 0x20002000u, 0x80000000u},
  {0x00202003u, 0x00030000u, 0x00020000u, 0xaa22a222u, 0x20000000u, 0x00001000u},
  {0x00200003u, 0x03000300u, 0x00000000u, 0x22222222u, 0x20002000u, 0x04000000u},
  {0x03100003u, 0x00030000u, 0x00020000u, 0x22222222u, 0x20000000u, 0x00000000u}};   // 16 steps x 2 bits per row: 0 rest, 1 ghost, 2 hit, 3 accent; rows = kick, snare, clap, c.hat, o.hat, tom
static const char* const DRUM_ROW[6] = {"KICK", "SNARE", "CLAP", "C.HAT", "O.HAT", "TOM"};
static const uint8_t CH_C[8]   = {48, 60, 55, 72, 60, 55, 55, 52};
static const uint8_t BASS_C[8] = {36, 36, 36, 48, 36, 36, 36, 36};

// track classes: 0 melodic, 1 percussion (track 7), 2 ear-candy FX (track 8), 3 drum kit
inline int styleCount(int cls) { return cls == 0 ? 128 : 9; }          // melodic: ALGORITHM = position 0..127 = complexity tier (pos >> 5) + a seed inside it; the same position always grows the same pattern.  drums: 9 grooves
inline int clampi(int v, int lo, int hi) { return v < lo ? lo : v > hi ? hi : v; }
inline int mod(int a, int m) { return ((a % m) + m) % m; }
inline int pc100(int v127) { return v127 * 100 / 127; }

struct Rng {
  uint32_t s;
  explicit Rng(uint32_t seed) : s(seed ? seed : 0x9E3779B9u) {}
  uint32_t u() { uint32_t x = s; x ^= x << 13; x ^= x >> 17; x ^= x << 5; return s = x; }
  int n(int m) { return (int)(u() % (uint32_t)m); }           // 0 .. m-1
  bool p(int pct) { return n(100) < pct; }                      // true pct% of the time (always draws one number, so patterns stay stable while knobs move)
};
struct Str {                                                          // tiny fixed-capacity string builder (no heap)
  char* b; int n, cap;
  Str(char* buf, int c) : b(buf), n(0), cap(c) { b[0] = 0; }
  void add(const char* s) { while (*s && n < cap - 1) b[n++] = *s++; b[n] = 0; }
  void sp() { if (n) add(" "); }
};
inline void noteName(uint8_t note, char* out) {                       // e.g. "C#3"
  const char* nn = NOTE_NAMES[note % 12]; int o = note / 12 - 1, i = 0; while (*nn) out[i++] = *nn++;
  if (o < 0) { out[i++] = '-'; o = -o; } out[i++] = (char)('0' + o); out[i] = 0;
}
inline int scaleNotes(int scaleIdx, int lo, int hi, uint8_t* out) {
  int root = scaleIdx % 12; const ScaleDef& sd = SCALES[(scaleIdx / 12) % 8]; int n = 0;
  for (int v = lo; v <= hi; v++) { int d = mod(v % 12 - root, 12); for (int k = 0; k < sd.n; k++) if (sd.iv[k] == d) { out[n++] = (uint8_t)v; break; } }
  return n;
}
inline void scaleLabel(int i, char* out) { Str s(out, 24); s.add(NOTE_NAMES[i % 12]); s.add(" "); s.add(SCALES[(i / 12) % 8].name); }

// ---- harmony: chords are stacked thirds INSIDE the scale (pentatonic keys borrow their parent minor / major scale)
inline const ScaleDef& harmScale(int sc) { const int t = (sc / 12) & 7; return SCALES[t == 6 ? 1 : t == 7 ? 0 : t]; }
inline int degSemi(const ScaleDef& H, int d, int k) { return H.iv[(d + k) % 7] + 12 * ((d + k) / 7) - H.iv[d]; }     // semitones from degree d up k scale steps
inline int degPc(int sc, int d) { return (sc % 12 + harmScale(sc).iv[d % 7]) % 12; }
inline bool inScale(int sc, int pc) { const ScaleDef& H = harmScale(sc); const int r = mod(pc - sc % 12, 12); for (int i = 0; i < 7; i++) if (H.iv[i] == r) return true; return false; }
inline bool inKey(int sc, int pc) { const ScaleDef& S = SCALES[(sc / 12) & 7]; const int r = mod(pc - sc % 12, 12); for (int i = 0; i < S.n; i++) if (S.iv[i] == r) return true; return false; }
inline int fitKey(int n, int sc) { for (int d = 0; d < 7; d++) for (int up = 0; up < 2; up++) { const int m = n + (up ? d : -d); if (m >= 0 && m <= 127 && inKey(sc, m)) return m; } return n; }   // nearest note of the ACTUAL scale (ties go down)
inline int chordFor(int sc, int d, int ext, int sp) {                 // SDK chord id (1..16) for scale degree d.  ext 0 triad, 1 sevenths, 2 ninths.  sp 1 = suspended, 2 = power
  const ScaleDef& H = harmScale(sc); const int t3 = degSemi(H, d, 2), t5 = degSemi(H, d, 4), t7 = degSemi(H, d, 6), t9 = degSemi(H, d, 8), pc = degPc(sc, d);
  if (sp == 1 && inScale(sc, pc + 7)) { if (inScale(sc, pc + 2)) return 5; if (inScale(sc, pc + 5)) return 6; }
  if (sp == 2 && inScale(sc, pc + 7)) return 15;
  const int q = t3 == 4 ? (t5 == 8 ? 4 : 1) : (t5 == 6 ? 3 : 2);
  if (!ext || q == 4) return q;
  if (q == 1) return t7 == 11 ? (ext > 1 && t9 == 14 ? 12 : 7) : t7 == 10 ? (ext > 1 && t9 == 14 ? 14 : 9) : 1;
  if (q == 2) return t7 >= 10 ? (ext > 1 && t7 == 10 && t9 == 14 ? 13 : 8) : 2;
  return t7 == 10 ? 10 : t7 == 9 ? 11 : 3;
}
// fam: 0 pop (Markov walk), 1 modal vamp, 2 circle of fifths, 3 jazz turnarounds, 4+ = any of them
inline void newProg(uint8_t* deg, int fam, int sc, Rng& R) {
  const ScaleDef& H = harmScale(sc); const bool minor = H.iv[2] == 3;
  static const uint8_t MAJ[7][4] = {{3, 4, 5, 1}, {4, 4, 6, 3}, {5, 3, 5, 1}, {4, 0, 1, 4}, {0, 5, 0, 3}, {1, 3, 4, 2}, {0, 2, 0, 5}};
  static const uint8_t MIN[7][4] = {{3, 5, 6, 4}, {4, 4, 6, 0}, {5, 3, 6, 0}, {4, 6, 0, 5}, {0, 5, 0, 2}, {6, 2, 3, 0}, {0, 2, 5, 0}};
  static const uint8_t JZ[4][4] = {{1, 4, 0, 5}, {2, 5, 1, 4}, {0, 5, 1, 4}, {1, 4, 0, 0}};
  static const uint8_t CIR[7] = {0, 3, 6, 2, 5, 1, 4};
  if (fam > 3) fam = R.n(4);
  if (fam == 0) {
    deg[0] = (uint8_t)(R.p(70) ? 0 : R.p(50) ? 5 : 3);
    for (int i = 1; i < 4; i++) { const uint8_t* T = (minor ? MIN : MAJ)[deg[i - 1]]; int c = T[R.n(4)]; if (c == deg[i - 1]) c = T[(R.n(3) + 1) & 3]; deg[i] = (uint8_t)c; }
    if (R.p(55)) deg[3] = (uint8_t)(minor && R.p(50) ? 6 : 4);                // turnaround: a dominant-ish last chord pulls back to the top
  } else if (fam == 1) {
    const int cad = R.n(4);                                           // modal vamp, Andalusian (i VII VI V), plagal (I IV I IV), or a "borrowed" IV-V lift
    if (cad == 1) { deg[0] = 0; deg[1] = 6; deg[2] = 5; deg[3] = 4; } else if (cad == 2) { deg[0] = 0; deg[1] = 3; deg[2] = 0; deg[3] = 3; }
    else { const int a = 3 + R.n(4), b = 3 + R.n(4); deg[0] = 0; deg[1] = (uint8_t)a; deg[2] = 0; deg[3] = (uint8_t)(b == a ? (b == 6 ? 3 : b + 1) : b); }
  } else if (fam == 2) {
    const int k = R.p(60) ? 0 : R.n(7); for (int i = 0; i < 4; i++) deg[i] = CIR[(k + i) % 7];
  } else { const uint8_t* J = JZ[R.n(4)]; for (int i = 0; i < 4; i++) deg[i] = J[i]; }
  for (int i = 0; i < 4; i++) for (int k = 0; k < 7 && !inKey(sc, degPc(sc, deg[i])); k++) deg[i] = (uint8_t)((deg[i] + (k & 1 ? 6 : 1)) % 7);        // pentatonic keys: keep chord roots inside the scale
}

// ---- the generator.  t = hardware track
struct Gen {
  const Opts& o; Rng R; Step* st; Str prog; int t;
  Gen(const Opts& op, Step* s, char* pbuf, int tr, uint32_t salt) : o(op), R(op.seed ^ salt), st(s), prog(pbuf, 72), t(tr) { for (int i = 0; i < NS; i++) st[i] = Step{0, 0, 1, 0, 0, 0}; }
  int jit() { const int a = o.human * 20 / 127; return R.n(2 * a + 1) - a; }
  void put(int s, int note, int vel, int gate, int chord, int tie, int prob) { s &= 15; st[s] = Step{(uint8_t)clampi(note, 0, 127), (uint8_t)clampi(vel, 1, 127), (uint8_t)clampi(gate, 1, 15), (uint8_t)chord, (uint8_t)tie, (uint8_t)prob}; }
  int nearN(int pc, int c) const { return c - 6 + mod(pc - (c - 6), 12); }
  int root(int slot, int centre) const { return nearN(degPc(o.scale, o.deg[slot & 3]), centre + o.oct * 12); }
  int semi(int slot, int k) const { return degSemi(harmScale(o.scale), o.deg[slot & 3], k); }        // chord-tone distance above the slot's root: k 2 third, 4 fifth, 6 seventh
  void key() { char b[24]; scaleLabel(o.scale, b); prog.add(b); prog.add(":"); }
  void name(int slot, int id) { char b[10]; Str s(b, 10); s.add(NOTE_NAMES[degPc(o.scale, o.deg[slot & 3])]); s.add(QN[id]); prog.sp(); prog.add(b); }

  // ---- melodic engine v3: no fixed recipes.  Each pattern is grown from "genes" drawn from the ALGORITHM seed (G) and shaped by the SEQ knobs;
  // the variation seed (R) only changes details, so NEW VARIATION keeps the character and ALGORITHM changes it.
  //   role     from the track (bass / lead / chords / arp), with seeded alternatives on the keys tracks
  //   rhythm   Euclidean: k hits spread evenly over 16 steps (DENS sets k), rotated off the beat by SYNC
  //   harmony  the shared progression o.deg[]; chords are stacked thirds inside the key (chordFor)
  //   contour  lead = weighted walk over the scale with an A A' B A'' motif, strong beats on chord tones, last note resolves;
  //            bass = root / octave / fifth / walking vocabulary with approach notes into the next chord
  //   holds    HOLD ties notes into the next hit; otherwise the gene picks a staccato-to-legato gate
  int melodic(int gi, char* nm) {
    Rng G((uint32_t)(gi + 1) * 2654435761u ^ (uint32_t)(t + 1) * 40503u);
    const int tier = gi >> 5;                                        // 0 foundational  1 colour  2 complex / modal  3 experimental
    const int r0 = G.n(100), dn = pc100(o.density), hs = pc100(o.hold), lp = pc100(o.leap), ch = pc100(o.chaos);
    static const uint8_t PC[7] = {0, 10, 45, 20, 0, 55, 40}, PA[7] = {0, 20, 20, 35, 0, 20, 25};   // per track: % chords, % arpeggio, the rest = melody (LEAD, E.PNO, BELL, PAD, ORGAN all get all three)
    const int role = t == 0 ? 3 : r0 < PC[t] ? 0 : r0 < PC[t] + PA[t] ? 1 : 2;   // 0 chords 1 arp 2 lead 3 bass
    static const uint8_t KLO[4] = {2, 6, 4, 3}, KHI[4] = {7, 16, 11, 10};
    const int k = clampi(KLO[role] + (KHI[role] - KLO[role]) * dn / 100 + G.n(3) - 1 + (tier > 1 ? tier - 1 : 0), 1, 16);
    const int rot = G.n(100) < pc100(o.sync) / 2 + tier * 14 ? 1 + 2 * G.n(8) : 2 * G.n(8);           // odd rotations land the hits off the beat
    const int voc = G.n(7), gs = 3 + G.n(10), acc = G.n(16), bc = BASS_C[t] + (G.p(20) ? 12 : 0);   // bc: one bass in five sits an octave higher                          // vocabulary / arp order, gate style, accent offset
    const bool swell = role == 0 && G.p(t == 5 ? 65 : 15);             // held "pad" chords: few hits, every one tied to the next
    bool hit[NS]; for (int s = 0; s < NS; s++) hit[s] = ((((s + rot) & 15) * (swell ? 2 : k)) & 15) < (swell ? 2 : k);
    int iv[2][4]; for (int m = 0; m < 2; m++) for (int j = 0; j < 4; j++) iv[m][j] = G.n(100) < lp / 2 + 8 ? (G.p(50) ? 4 : -4) : G.p(12) ? 0 : G.p(50) ? 1 + G.n(2) : -1 - G.n(2);   // motif A and B, in scale steps
    // tier vocabulary: 0 triads / 1 sevenths and sus / 2 ninths + borrowed chords (modal interchange) / 3 tritone substitution on the last chord
    const int ex = clampi((tier ? tier - 1 + (tier == 1 && G.p(35)) : 0) + (o.voice > 100) - (o.voice < 28), 0, 2), sp = tier == 1 && G.p(35) ? 1 : tier == 2 && G.p(14) ? 1 : tier == 3 && G.p(10) ? 2 : 0;
    int cs[4], cr[4], ci[4]; const bool minor = harmScale(o.scale).iv[2] == 3; key();
    for (int i = 0; i < 4; i++) {                                    // chord slot i: scale used (a parallel mode when borrowed), root and SDK chord id
      static const uint8_t BM[3] = {1, 5, 2}, BN[3] = {2, 0, 3};     // major borrows from minor / mixolydian / dorian; minor from dorian / major / phrygian
      const bool bor = tier >= 2 && i != 0 && G.p(tier == 2 ? 35 : 50), ts = tier == 3 && i == 3 && G.p(55);
      cs[i] = bor ? (minor ? BN : BM)[G.n(3)] * 12 + o.scale % 12 : o.scale; ci[i] = chordFor(cs[i], o.deg[i], ex, sp);
      cr[i] = degPc(cs[i], o.deg[i]); if (ts) { cr[i] = (cr[i] + 6) % 12; ci[i] = 9; }
      prog.sp(); char b[10]; Str n(b, 10); n.add(NOTE_NAMES[cr[i]]); n.add(QN[ci[i]]); prog.add(b);
    }
    uint8_t pool[40]; const int lo = 60 + o.oct * 12, pn = role == 2 ? scaleNotes(o.scale, lo, lo + 24, pool) : 0; int d = pn / 3, first = -1, lastN = -1, c = 0, prevSl = -1, pos = 0;
    const int span = G.n(100) < lp + tier * 10 ? 2 : 1;
    for (int s = 0; s < NS; s++) {
      if (!hit[s]) continue;
      const int sl = s >> 2; if (sl != prevSl) { prevSl = sl; pos = 0; } else pos++;
      int nx = 1; while (nx < NS && !hit[(s + nx) & 15]) nx++;                       // steps to the next hit
      const bool tie = nx > 1 && (swell || R.p(hs)); const int gate = tie ? 15 : clampi(gs + R.n(3) - 1, 1, 15);
      const int vel = 88 - tier * 3 + (((s + acc) & 3) == 0 ? 16 + tier * 4 : 0) + (s == 0 ? 8 : 0) + jit(), prob = (ch > 80 || tier == 3) && (s & 3) ? 4 + R.n(3) : 0;      // higher tiers: wider dynamics
      int note, id = 0;
      if (role == 0) { id = ci[sl]; note = nearN(cr[sl], CH_C[t] + o.oct * 12); }
      else if (role == 1) {                                                          // arpeggio: chord tones over one or two octaves
        const int cid = ci[sl], rt = nearN(cr[sl], CH_C[t] - 12 + o.oct * 12); int tone[10], n = 0;
        for (int o2 = 0; o2 < span; o2++) { tone[n++] = rt + 12 * o2; for (int q = 1; q < QTAB[cid - 1][0]; q++) tone[n++] = rt + 12 * o2 + QTAB[cid - 1][q]; }
        const int p2 = c % (2 * n - 2 > 0 ? 2 * n - 2 : 1);
        note = voc % 3 == 0 ? tone[c % n] : voc % 3 == 1 ? tone[n - 1 - c % n] : tone[p2 < n ? p2 : 2 * n - 2 - p2];
        c++;
      } else if (role == 2) {                                                        // lead: motif walk, chord tone on the first hit of each beat group
        if (pn < 4) return role;
        const int seg = s >> 2, m = seg == 2 ? 1 : 0; int ds = iv[m][pos & 3]; if ((seg & 1) && R.p(30)) ds += R.p(50) ? 1 : -1;
        if (R.n(100) < ch / 3) ds += R.n(3) - 1; d = clampi(d + ds, 0, pn - 1);
        const bool lastHit = [&] { for (int q = s + 1; q < NS; q++) if (hit[q]) return false; return true; }();
        if (pos == 0 || lastHit) {                                                   // anchor: nearest chord tone (the root on the very last note = resolution)
          const int ct = degPc(o.scale, o.deg[sl]); int best = d, bd = 99;
          for (int j = clampi(d - 4, 0, pn - 1); j <= clampi(d + 4, 0, pn - 1); j++) { const int rel = mod(pool[j] - ct, 12);
            if (rel == 0 || (!lastHit && (rel == semi(sl, 2) % 12 || rel == semi(sl, 4) % 12))) { const int dist = j > d ? j - d : d - j; if (dist < bd) { bd = dist; best = j; } } }
          d = best;
        }
        note = pool[d];
      } else {                                                                       // bass vocabulary: 0 root, 1 root/octave, 2 root-5th-octave, 3 walking, 4 root + 7th colour
        const int rt = tier == 3 && sl == 3 ? nearN(cr[3], bc + o.oct * 12) : root(sl, bc); int tone = 0; bool ap = false;   // tier 3: the last bar can sit on the tritone substitute
        if (voc == 1) tone = (pos & 1) ? 12 : 0; else if (voc == 2) tone = pos % 3 == 1 ? semi(sl, 4) : pos % 3 == 2 ? 12 : 0;
        else if (voc == 4) tone = pos == 0 ? 0 : (pos & 1) ? semi(sl, 6) : semi(sl, 4);
        else if (voc == 5) tone = (pos & 1) ? semi(sl, 4) : (pos & 2) ? 12 : 0;                      // bounce: root, fifth, octave, fifth
        else if (voc == 6) tone = pos && !hit[(s + 1) & 15] && R.p(50) ? 12 : 0;                // pedal: the root, jumping up an octave before rests
        else if (voc == 3) { const int nsl = ((s + nx) & 15) >> 2; tone = pos == 0 ? 0 : semi(sl, (pos & 1) ? 2 : 4);
          if (nsl != sl && pos > 0) { note = root(nsl & 3, bc) + (R.p(50) ? -1 : 2); if (tier < 3) note = fitKey(note, o.scale); ap = true; } }   // tier 3 keeps the chromatic approach note   // approach the next chord's root
        if (!ap) note = rt + tone + (pos > 0 && R.n(100) < lp / 3 ? 12 : 0);
      }
      if (first < 0) first = note; lastN = note;
      put(s, note, vel, gate, id, tie, prob);
    }
    // the generated name: ROLE  E<k>/16  [SYNC]  <character>
    static const char* const RL[4] = {"CHORD", "ARP", "LEAD", "BASS"};
    static const char* const W[18] = {"TRIAD", "7TH", "9TH", "SUS", "POWER", "UP", "DOWN", "UPDN", "WAVE", "CLIMB", "FALL", "ROOT", "OCT", "R-5", "WALK", "R-7", "BOUNCE", "PEDAL"};   // chords 0-4, arp 5-7, lead 8-10, bass 11-17
    Str nb(nm, 26); nb.add(RL[role]); char tb[3] = {' ', (char)('1' + tier), 0}; nb.add(tb); char kb[8] = {' ', 'E', 0}; int kk = 2; if (k >= 10) kb[kk++] = (char)('0' + k / 10); kb[kk++] = (char)('0' + k % 10); kb[kk] = 0; nb.add(kb); nb.add("/16");
    if (rot & 1) nb.add(" SYNC"); nb.sp();
    nb.add(role == 0 && swell ? "SWELL" : W[role == 0 ? (sp ? 2 + sp : ex) : role == 1 ? 5 + voc % 3 : role == 3 ? 11 + voc : 8 + (lastN > first + 2 ? 1 : lastN < first - 2 ? 2 : 0)]);
    return role;
  }
  void drumRow(int row, int idx, int base) {                          // drum / percussion row from the groove strings; ghost hits, displaced hits, fills
    uint32_t pk = ST_DRP[idx][row]; int rs = row >= 3 && R.p(45) ? 1 + R.n(3) : 0;   // hats and toms shift against the kick/snare: same groove, new feel (shifted while the string is built; a variable rotate compiled to an instruction that halts the CPU)
    // toms, and one kick in four: a Euclidean figure (tresillo 3/16, 5/16 ...)
    if ((row == 5 && R.p(40)) || (row == 0 && R.p(25))) { const int k = row ? 2 + R.n(4) : 3 + R.n(3), r = row ? R.n(16) : 2 * R.n(8); pk = 0; rs = 0; for (int s = 0; s < NS; s++) if ((((s + r) & 15) * k & 15) < k) pk |= 2u << (2 * s); } char str[17]; for (int s = 0; s < NS; s++) str[s] = ".oxX"[(pk >> (2 * ((s - rs) & 15))) & 3]; str[16] = 0; int hits[NS] = {0}; const int d = pc100(o.density), ch = pc100(o.chaos), sy = pc100(o.sync);
    for (int s = 0; s < NS; s++) {
      const char c = str[s]; const int r1 = R.n(100), r2 = R.n(100); const int h = c == 'X' ? 3 : c == 'x' ? 2 : c == 'o' ? 1 : 0;
      if (h == 0) { if (d > 50 && r1 < (d - 50) * (row == 0 ? 12 : row == 3 ? 40 : row == 5 ? 25 : 8) / 100) hits[s] = 1; continue; }
      if (h < 3 && r1 < ch / 10) continue; int dst = s; if (h < 3 && r2 < (ch + sy) / 12) dst = (s + 1) & 15; if (!hits[dst]) hits[dst] = h; else if (!hits[s]) hits[s] = h;
    }
    if (row == 1 && R.p(ch / 2)) { hits[14] = hits[14] ? hits[14] : 1; hits[15] = 1; }                // snare fill
    for (int s = 0; s < NS; s++) if (hits[s]) { const int h = hits[s]; put(s, base, (h == 3 ? 118 : h == 2 ? 100 : 62) + jit(), h == 3 ? 7 : 5, 0, 0, 0); }
    prog.add(DRUM_ROW[row]); prog.add(" "); prog.add(str);
  }
};

// Rewrites steps[0..15] of one track.  cls 0 melodic (hardware tracks 0..6), 1 percussion, 2 FX, 3 drum row (row = 0..5, base = note)
inline void applyStyle(Step* st, int t, int cls, int idx, const Opts& o, Result& res, int row = 0, int base = 48) {
  idx = mod(idx, styleCount(cls));
  Gen G(o, st, res.prog, t, (uint32_t)(t + 1) * 0x9E3779B1u ^ (uint32_t)(idx + 1) * 0x85EBCA6Bu ^ (uint32_t)(row + 1) * 0xC2B2AE35u);
  if (cls == 0) { res.kind = (uint8_t)G.melodic(idx, res.nm); res.name = res.nm; }
  else { res.name = ST_DRN[idx]; res.kind = cls == 1 ? 5 : 4; G.drumRow(row, idx, base); }
  if (((o.scale / 12) & 7) >= 6) for (int s = 0; s < NS; s++) if (st[s].vel && (st[s].chord == 0 || cls != 0)) st[s].note = (uint8_t)fitKey(st[s].note, o.scale);   // pentatonic keys: every single note stays pentatonic
  if (!res.prog[0]) { int cnt = 0; for (int s = 0; s < NS && cnt < 6; s++) if (st[s].vel) { char nb[8]; noteName(st[s].note, nb); G.prog.sp(); G.prog.add(nb); cnt++; } }
}
}  // namespace algo
