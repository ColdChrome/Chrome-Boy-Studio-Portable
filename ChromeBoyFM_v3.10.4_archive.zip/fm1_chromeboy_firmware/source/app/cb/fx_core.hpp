// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM - master insert effects that the closed libfm1_engine.a does not provide:
//   CHORUS, OVERDRIVE, COMPRESSOR, FILTER (+ output level).  (REVERB / DELAY use the engine's own groove_effects_*.)
// Integer-only, no heap, no libm: safe in the audio callback.  Operates on one FM1 output block
// (interleaved stereo int32, signed 24-bit range) and is called from fm1_output_mix() - see tools/apply_patch.py.
#pragma once
#include <stdint.h>

namespace cb {
struct InsertParams { volatile uint8_t chorusDepth, chorusMix, drive, comp, cutoff, res, level; };   // all 0..127; level 127 = unity
class InsertFx {
 public:
  void reset() { for (auto& x : dl_) x = 0; w_ = 0; ph_ = 0; env_ = 0; lp_[0] = lp_[1] = bp_[0] = bp_[1] = 0; init_f(); }
  __attribute__((always_inline)) inline void process(int32_t* io, int frames, const InsertParams& p) {
    const int depth = p.chorusDepth, cmix = p.chorusMix, drive = p.drive, comp = p.comp, cut = p.cutoff, res = p.res, level = p.level;
    if (!cmix && !drive && !comp && cut >= 125 && level >= 127) return;                          // true bypass
    const int64_t g_drive = 32768 + (int64_t)drive * 32768 * 12 / 127;                           // Q15, 1x .. 13x
    const int32_t thr = comp ? 8388607 - (int32_t)((int64_t)comp * 6700000 / 127) : 8388607;     // compressor threshold (Q23)
    const int32_t makeup = 32768 + comp * 150;                                                   // Q15 make-up gain
    const int32_t fq = cut >= 125 ? 0 : F_[cut], damp = 65536 - res * 480;                       // Q15 SVF freq, Q15 damping 2.0..0.1
    for (int i = 0; i < frames; i++) {
      int32_t in[2] = {io[2 * i], io[2 * i + 1]}, out[2];
      // ---- chorus (two tri-LFO modulated taps, one per side)
      if (cmix) {
        ph_ += 90; int tri = (int)((ph_ >> 4) & 1023); tri = tri < 512 ? tri : 1023 - tri;          // 0..511
        int base = 280 + (depth * 6), mod = (tri * depth) >> 7;                                    // delay in samples
        for (int c = 0; c < 2; c++) { dl_[c * 2048 + (w_ & 2047)] = (int16_t)(in[c] >> 8); int d = base + (c ? mod : (depth * 4 - mod)); if (d < 2) d = 2; if (d > 2000) d = 2000; int32_t wet = (int32_t)dl_[c * 2048 + ((w_ - d) & 2047)] << 8; in[c] = in[c] + (int32_t)((int64_t)(wet - in[c]) * cmix >> 8); }
        w_++;
      }
      for (int c = 0; c < 2; c++) {
        int32_t x = in[c];
        if (drive) {                                                                               // soft clip y = 1.5x - 0.5x^3
          int64_t v = x * g_drive >> 15; v = v > 8388607 ? 8388607 : v < -8388607 ? -8388607 : v;
          int64_t v3 = (((v * v) >> 23) * v) >> 23; x = (int32_t)((3 * v - v3) >> 1);
        }
        if (cut < 125) {                                                                           // Chamberlin SVF low-pass
          int64_t hp = x - lp_[c] - ((bp_[c] * damp) >> 16); int64_t bp = bp_[c] + ((hp * fq) >> 15), lp = lp_[c] + ((bp * fq) >> 15);
          bp = bp > 12000000 ? 12000000 : bp < -12000000 ? -12000000 : bp; lp = lp > 12000000 ? 12000000 : lp < -12000000 ? -12000000 : lp;
          bp_[c] = (int32_t)bp; lp_[c] = (int32_t)lp; x = (int32_t)lp;
        }
        out[c] = x;
      }
      if (comp) {                                                                                  // feed-forward peak compressor, 4:1
        int32_t pk = out[0] < 0 ? -out[0] : out[0], pr = out[1] < 0 ? -out[1] : out[1]; if (pr > pk) pk = pr;
        env_ = pk > env_ ? env_ + ((pk - env_) >> 3) : env_ - (env_ >> 11);                           // fast attack, slow release
        int32_t gain = 32768;
        if (env_ > thr) { int64_t over = env_ - thr; int64_t tgt = env_ - (over * 3 >> 2); gain = (int32_t)((tgt << 15) / env_); }
        for (int c = 0; c < 2; c++) out[c] = (int32_t)(((int64_t)out[c] * gain >> 15) * makeup >> 15);
      }
      for (int c = 0; c < 2; c++) { int64_t y = level >= 127 ? out[c] : ((int64_t)out[c] * level) >> 7; y = y > 8388607 ? 8388607 : y < -8388608 ? -8388608 : y; io[2 * i + c] = (int32_t)y; }
    }
  }
 private:
  int16_t dl_[4096] = {}; uint32_t w_ = 0, ph_ = 0; int32_t env_ = 0; int32_t lp_[2] = {0, 0}, bp_[2] = {0, 0}; int32_t F_[125] = {};
  void init_f() { int64_t f = 280 << 16; for (int c = 0; c < 125; c++) { F_[c] = (int32_t)(f >> 16); f = f * 69000 >> 16; if ((f >> 16) > 18000) f = (int64_t)18000 << 16; } }   // 60 Hz .. 8 kHz, Q15 Chamberlin coefficient
};
}  // namespace cb
