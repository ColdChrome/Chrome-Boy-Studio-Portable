// SPDX-License-Identifier: GPL-3.0-only
// Chrome Boy FM - M-VAVE FM1 edition.  Shared types between the control loop (main.cpp), the sequencer/FX
// glue (SDK-bound) and the pure renderer (ui_display.cpp).  This header has NO SDK includes so the renderer
// and the DSP can be compiled and tested on a PC.
#pragma once
#include <stdint.h>

namespace cb {
constexpr int NT = 8;            // FM1 hardware tracks
constexpr int NS = 16;           // steps per bank - exactly 16
constexpr int NBANK = 4;         // banks A..D = the SDK's 64 steps / 16

constexpr int BOOT_FRAMES = 85;      // 30 fps boot sequence; any key skips it

enum Page : uint8_t { P_HOME, P_FXM, P_MIX, P_SCL, P_ENV, P_LFO, P_EDIT, P_GLO, P_SAVE, P_ARP, P_GEN, P_PRE, P_COUNT };
// physical button bits, same order as app/screen.c  (fm1_controls.buttons)
enum Btn : uint8_t { B_OCT_DOWN, B_OCT_UP, B_FX, B_SCL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC };
// encoder indices, same order as fm1_controls.encoders[]
enum Enc : uint8_t { E_SELECT, E_ALGO, E_K1, E_K2, E_K3, E_K4, E_PRESETS };

struct Knob { char label[9]; char txt[8]; uint8_t pos; uint8_t used; };       // pos 0..127 (bar), used=0 greys it out
struct GRow { char label[10]; char txt[9]; uint8_t pos; };

struct Snap {                                                                     // everything the LCD needs for one frame
  uint32_t tick;                                                                  // 30 fps frame counter
  uint8_t page, track, bank, playing, rec, stepRec, master, undoN, redoN, boot;      // track = DISPLAY position (drums first)
  uint8_t hw[NT];                                                                 // display position -> hardware track (colour / identity)
  int8_t playStep;                                                                // -1 when stopped
  uint16_t bpm;
  Knob k[4]; char selTag[8], selVal[12];
  // ---- home / sequencer
  uint8_t src[NT], has[NT], mute[NT], solo[NT], active[NT];
  char trackName[NT][8]; char trackLong[16]; char patch[12];
  uint8_t stepOn[NS], stepVel[NS], stepNote[NS], stepChord[NS]; uint8_t heldStep; char heldInfo[34];
  char laneName[10]; uint8_t laneVal[NS];
  uint8_t styValid; char styName[26], prog[72];
  // ---- ALGORITHM banner
  uint8_t algoShow; uint16_t styIdx, styCnt; char styPrev[26], styNext[26], styKind[20];
  // ---- FX rack
  uint8_t fxSel; uint8_t fxv[6][3]; char fxtxt[6][3][8]; uint8_t fxAuto; char fxLane[10]; uint8_t fxLaneVal[NS];
  // ---- mixer
  uint8_t vol[NT], send1[NT], send2[NT], level[NT], peak[NT], nmOn, nmCur; char nm[7];   // level / peak = meter pixels (dB scale), peak holds ~300 ms
  // ---- presets
  uint8_t catSel, pcount, psel, pTot, pPos; uint16_t pMask; char plist[12][17]; char pinfo[2][36];   // pMask = FM_CATS families this track may browse (0 = not a DX7 track)
  // ---- generic parameter pages (SCL ENV LFO EDIT GLO ARP) and SEQ/GEN page
  char gtitle[24]; GRow grow[4]; uint8_t gen_dens, gen_chaos, gen_human; uint32_t gen_seed; uint8_t genFlash;
  // ---- footer / empty-track hint / quick-start
  char hint[41]; uint8_t trackEmpty;
  // ---- SAVE page: rows 0..15 = the SDK's 16 project slots, row 16 = EXPORT STEMS TO DAW
  uint8_t svRow, svCur, svConfirm, svUsed[16]; char svName[16][13];
  uint8_t usb, exState, exPass, exPasses, exPct, exLoops, exTail, exTr[8];   // EXPORT TO DAW: state (0 idle 1 ask 2 lead-in 3 playing 4 gap 5 done), pass, passes, % of this pass, the tracks
  // ---- EDIT (piano roll / tracker) + project length + MIDI routing
  uint8_t edView, edStep, edSet, edBase, edPads, pencil, len, clip;                // edView 0 roll 1 tracker; edStep = cursor inside the bank; edBase = lowest pitch row
  uint8_t edGate[NS], edProb[NS], edChord[NS], edTie[NS]; uint16_t edMask[NS];     // per-step cell fields (melodic: gate 0..15, prob 0..7, chord id, tie)
  char edChordName[NS][5], padLbl[16][5], edNote[4];
  // ---- HOME navigation overlay (intro = overlay open)
  uint8_t navSel, panicPct, ext, glo, engLen, lk, genSet, mOnly, gv[12];   // lk = knob being recorded (automation lane), genSet = SEQ knob set, mOnly = this track is MIDI-only (no local sound), gv = the 12 generator values
  // ---- overlays
  char toast[34]; uint8_t toastOn; uint8_t intro;
};

extern const char* const FM_CATS[10];
extern const char* const FX_NAMES[6];
extern const char* const PAGE_TITLE[P_COUNT];

void ui_paint_band(const Snap& s, uint16_t* band, int y0, int rows);                // paints rows [y0,y0+rows) of the 240x240 LCD
}  // namespace cb
