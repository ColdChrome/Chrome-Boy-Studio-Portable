#!/bin/bash
# Serves the FM1 flasher page on this Mac only and opens it in Chrome. Flashes the NEWEST FM1_ChromeBoy_v*.fwsc in this folder.
# Close this Terminal window when you're done flashing.
cd "$(dirname "$0")"
FW=$(ls FM1_ChromeBoy_v*.fwsc | sort -V | tail -1)
cp -f "$FW" flasher/firmware.fwsc; cp -f build-identity.json flasher/
lsof -ti tcp:8733 | xargs kill 2>/dev/null
python3 -I -m http.server 8733 --bind 127.0.0.1 --directory flasher >/dev/null 2>&1 &
sleep 1
open -a "Google Chrome" "http://127.0.0.1:8733/index.html"
echo "FM1 flasher running at http://127.0.0.1:8733 with $FW - close this window when finished."
wait
