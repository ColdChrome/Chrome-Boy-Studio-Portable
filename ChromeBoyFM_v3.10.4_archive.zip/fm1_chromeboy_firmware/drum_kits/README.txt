CC 909 and CC 626 drum kits (synthesized by me, original sounds in the style of those machines; not recordings).
Each kit = 8 mono WAVs, 32 kHz, 16-bit, about 4.1 s (909) / 1.9 s (626) in total, well inside the sampler's ~19.5 s.

HOW TO LOAD  (M-VAVE workbench, Chrome, FM1 on USB)
  1. Open the workbench's sample page, pick slot 1, choose 01_*.wav, write.  Repeat for slots 2-8 in file order.
  2. One kit at a time: the sampler only has 8 pads.  Loading the other kit replaces it.
  3. On the FM1 the sampler pads sit on the 8 white keys 1-8 (slot order = key order).
  Slot order 909: KICK SNARE CLAP CL HAT OP HAT LO TOM HI TOM CRASH
  Slot order 626: KICK SNARE RIM CLAP CL HAT OP HAT TOM TAMB
I could not listen to them here (no audio on my side). If a sound is too loud, quiet or harsh, tell me which and I will retune it.
