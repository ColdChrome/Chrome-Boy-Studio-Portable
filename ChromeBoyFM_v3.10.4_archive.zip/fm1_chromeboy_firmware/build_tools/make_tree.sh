#!/bin/bash
# Recreates the build tree: M-VAVE's fm1_open SDK (~/Downloads/fm1_open-main.zip) + the Chrome Boy source in ../source.
# Order for a rebuild:  ./setup.sh (downloads the tools, one OK click)  ->  ./make_tree.sh  ->  ./build.sh
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; W=~/FM1-ChromeBoy/work
rm -rf "$W"; mkdir -p "$W"
unzip -q ~/Downloads/fm1_open-main.zip -d "$W/x"; mv "$W/x/fm1_open-main" "$W/sdk"; rmdir "$W/x"
cp -R "$HERE/../source/." "$W/sdk/"
cp "$HERE/build.sh" ~/FM1-ChromeBoy/build.sh; chmod +x ~/FM1-ChromeBoy/build.sh
echo "tree ready: $W/sdk"
