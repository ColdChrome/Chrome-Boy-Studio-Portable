#!/bin/bash
# Downloads and unpacks the build tools, then starts the (GUI) toolchain installer, which needs one OK click.
set -e
cd ~/FM1-ChromeBoy/tools
curl -fL -sS -o downloads/2.5.3.exe https://jl-update.oss-cn-shenzhen.aliyuncs.com/2.5.3.exe &
curl -fL -sS -o downloads/wine.tar.xz https://github.com/Gcenx/macOS_Wine_builds/releases/download/11.18/wine-devel-11.18-osx64.tar.xz &
curl -fL -sS -o downloads/pwsh.tar.gz https://github.com/PowerShell/PowerShell/releases/download/v7.6.9/powershell-7.6.9-osx-arm64.tar.gz &
wait
mkdir -p pwsh && tar -xzf downloads/pwsh.tar.gz -C pwsh && chmod +x pwsh/pwsh && tar -xJf downloads/wine.tar.xz
export WINEPREFIX=$PWD/wineprefix WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml="
B="$PWD/Wine Devel.app/Contents/Resources/wine/bin"
"$B/wine" wineboot -i >/dev/null 2>&1; "$B/wineserver" -w
mkdir -p "wineprefix/drive_c/Program Files/CodeBlocks" "wineprefix/drive_c/users/$USER/AppData/Roaming/CodeBlocks"
printf '<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>\n<CodeBlocksConfig version="1">\n</CodeBlocksConfig>\n' > "wineprefix/drive_c/users/$USER/AppData/Roaming/CodeBlocks/default.conf"
for K in 'HKCU\Software\CodeBlocks' 'HKLM\Software\CodeBlocks' 'HKLM\Software\Wow6432Node\CodeBlocks'; do "$B/wine" reg add "$K" /v Path /d 'C:\Program Files\CodeBlocks' /f >/dev/null 2>&1; "$B/wine" reg add "$K" /ve /d 'C:\Program Files\CodeBlocks' /f >/dev/null 2>&1; done
echo "TOOLS READY - starting toolchain installer (click OK on the Wine pop-up)"
"$B/wine" downloads/2.5.3.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP- '/LOG=C:\jlinstall.log' '/DIR=C:\JL' >/dev/null 2>&1 || true
"$B/wineserver" -w
ls wineprefix/drive_c/JL/pi32/bin/clang.exe && echo INSTALL DONE
