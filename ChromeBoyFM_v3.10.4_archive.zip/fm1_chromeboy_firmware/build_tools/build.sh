#!/bin/bash
# Builds the firmware in ~/FM1-ChromeBoy/work/sdk through Wine; prints the useful lines only.
cd ~/FM1-ChromeBoy/work/sdk || exit 1
export WINEPREFIX=~/FM1-ChromeBoy/tools/wineprefix WINEDEBUG=-all WINEDLLOVERRIDES="mscoree,mshtml=" FM1_WINE=~/FM1-ChromeBoy/tools/"Wine Devel.app/Contents/Resources/wine/bin/wine"
~/FM1-ChromeBoy/tools/pwsh/pwsh -NoProfile -File tools/Build-Mac.ps1 -FirmwareOnly -Toolchain ~/FM1-ChromeBoy/tools/wineprefix/drive_c/JL/pi32 2>&1 \
 | grep -v -E '^\s*(\[mvk|VK_|Read-Write|Vulkan)|Wmisleading|misleading-indentation|^\s*\^\s*$|^In file included|^Compile |warning generated|Using-1' 
ls -la build/dx7/generated/FM1_OFFICIAL_OPEN.fwsc 2>&1 | sed 's/^/OUT: /'
