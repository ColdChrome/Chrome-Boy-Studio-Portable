#!/usr/bin/env python3
"""Builds the Shopify version of the FM1 emulator + flasher from this release folder.

Output: ../shopify/assets/*  (upload to the theme's Assets)
        ../shopify/templates/page.fm1-emulator.liquid, page.fm1-flasher.liquid  (add to Templates)
Run again after every firmware build: it always packs the newest FM1_ChromeBoy_v*.fwsc.

Shopify's asset uploader only takes web file types, so the two binaries (the emulator core .wasm and
the firmware .fwsc) are shipped inside .js files as base64. The emulator worklet is started from a
Blob, so nothing depends on the CDN's CORS headers.
"""
import base64, hashlib, json, re, shutil, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REL = HERE.parent
EMU, FLASH = REL / "emulator", REL / "flasher"
OUT = REL / "shopify"


def ver_key(p):
    return [int(x) for x in re.findall(r"\d+", p.stem)]


def must_replace(src, old, new, what):
    if src.count(old) != 1:
        sys.exit(f"make_shopify: could not patch {what} (the emulator files changed?)")
    return src.replace(old, new)


def main():
    fws = sorted(REL.glob("FM1_ChromeBoy_v*.fwsc"), key=ver_key)
    if not fws:
        sys.exit("make_shopify: no FM1_ChromeBoy_v*.fwsc in the release folder")
    fw = fws[-1]
    version = re.search(r"v([\d.]+)\.fwsc$", fw.name).group(1)
    fw_bytes = fw.read_bytes()
    ident = json.loads((REL / "build-identity.json").read_text())

    if OUT.exists():
        shutil.rmtree(OUT)
    (OUT / "assets").mkdir(parents=True)
    (OUT / "templates").mkdir()
    A = OUT / "assets"

    # --- emulator code (MIT, github.com/joakimeriksson/fm1-emu), renamed with an fm1emu- prefix (the theme's assets folder is flat)
    main_js = (EMU / "main.js").read_text()
    main_js = must_replace(main_js, 'from "./fwsc.js"', 'from "./fm1emu-fwsc.js"', "fwsc import")
    main_js = must_replace(main_js, 'from "./persistence.js"', 'from "./fm1emu-persistence.js"', "persistence import")
    main_js = must_replace(main_js, 'from "./tryout.js"', 'from "./fm1emu-tryout.js"', "tryout import")
    main_js = must_replace(main_js, 'const catalog = await (await fetch("firmwares.json")).json();',
                           'const catalog = (await import("./fm1emu-catalog.js")).default;', "catalog fetch")
    main_js = must_replace(main_js, 'const wasm = await (await fetch("fm1_web.wasm")).arrayBuffer();',
                           'const wasm = await (await fetch("data:application/wasm;base64," + (await import("./fm1emu-wasm.js")).default)).arrayBuffer();',
                           "wasm fetch")
    main_js = must_replace(main_js, 'await ac.audioWorklet.addModule("worklet.js");',
                           'await ac.audioWorklet.addModule(URL.createObjectURL(new Blob([(await import("./fm1emu-worklet.js")).default], { type: "text/javascript" })));',
                           "worklet module")
    main_js = must_replace(main_js, 'stage.addEventListener("dragover",',
                           'setTimeout(() => { window.fm1emuReady = true; dispatchEvent(new Event("fm1emu-ready")); });   // (Shopify page: the drop handler below is attached; Chrome Boy can be loaded)\nstage.addEventListener("dragover",',
                           "ready signal")
    (A / "fm1emu-main.js").write_text(main_js)
    (A / "fm1emu-fwsc.js").write_text((EMU / "fwsc.js").read_text())
    (A / "fm1emu-persistence.js").write_text((EMU / "persistence.js").read_text())
    tryout = must_replace((EMU / "tryout.js").read_text(), "from './persistence.js'", "from './fm1emu-persistence.js'", "tryout's persistence import")
    (A / "fm1emu-tryout.js").write_text(tryout)
    (A / "fm1emu-worklet.js").write_text("export default " + json.dumps((EMU / "worklet.js").read_text()) + ";\n")
    (A / "fm1emu-wasm.js").write_text('export default "' + base64.b64encode((EMU / "fm1_web.wasm").read_bytes()).decode() + '";\n')
    shutil.copy(EMU / "style.css", A / "fm1emu-style.css")

    # firmware catalog: one Chrome Boy entry (the page drops the bundled package in, so it runs as "your file").
    # No M-VAVE stock entry: with a "bring your own" entry selected, the emulator files any dropped package as M-VAVE's.
    entry = {"id": "chromeboy", "name": "Chrome Boy Studio Portable", "version": version, "author": "Chrome Boy",
             "license": "", "about": "Custom firmware for the M-VAVE FM1.", "repo": ""}
    (A / "fm1emu-catalog.js").write_text("export default " + json.dumps({"default": "chromeboy", "firmwares": [entry]}) + ";\n")

    # --- the firmware, shared by both pages
    fwinfo = {"name": "Chrome Boy Studio Portable", "version": version, "file": fw.name,
              "sha256": hashlib.sha256(fw_bytes).hexdigest(), "build_id": ident["build_id"],
              "release_version": ident["release_version"], "b64": base64.b64encode(fw_bytes).decode()}
    (A / "chromeboy-firmware.js").write_text("window.CHROMEBOY_FW = " + json.dumps(fwinfo) + ";\n")

    # --- flasher library (M-VAVE, GPL-3.0-only WITH GPL-3.0-linking-exception), unchanged
    shutil.copy(FLASH / "WebUpdate.js", A / "fm1flash-webupdate.js")

    for t in ("page.fm1-emulator.liquid", "page.fm1-flasher.liquid"):
        src = (HERE / "shopify_templates" / t).read_text()
        (OUT / "templates" / t).write_text(src)
    shutil.copy(HERE / "shopify_templates" / "INSTALL_SHOPIFY.txt", OUT / "INSTALL_SHOPIFY.txt")

    total = sum(p.stat().st_size for p in A.iterdir())
    print(f"shopify/: firmware v{version} ({fwinfo['sha256'][:8]}), {len(list(A.iterdir()))} assets, {total / 1e6:.1f} MB")


if __name__ == "__main__":
    main()
